@echo off
title AUTONOMOUS AI CYBER COMMANDER v3.0 — LIVE USB DEFENSE TERMINAL
color 0B
echo ================================================================================
echo   [USB PENDRIVE INSERTED] AUTONOMOUS AI CYBER COMMANDER v3.0
echo   Opening Live Defense Terminal Process ^& Real-Time Attack Monitor...
echo ================================================================================
where wsl >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    wsl -u root bash -c "cd '$(wslpath '%~dp0')' && ./start_usb_guard.sh --live-terminal"
) else (
    python "%~dp0cyber_commander.py" --live-demo
)
pause

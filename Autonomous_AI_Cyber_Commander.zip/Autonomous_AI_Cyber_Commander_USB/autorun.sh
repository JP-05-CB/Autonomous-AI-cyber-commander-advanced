#!/usr/bin/env bash
USB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec bash "$USB_DIR/usb_autorun/open_cyber_terminal.sh" "$USB_DIR"

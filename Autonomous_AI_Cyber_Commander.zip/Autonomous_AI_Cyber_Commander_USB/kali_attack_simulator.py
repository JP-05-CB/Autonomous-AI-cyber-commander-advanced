#!/usr/bin/env python3
"""
kali_attack_simulator.py — 20-Second Sustained Telemetry Simulator with Live Target Effect Display
Autonomous AI Cyber Commander v4.3

Enhancements in v4.3:
  1. Sends both UDP (`UDP:53530` KALI_UDP_FRAME) and TCP (`TCP:8080` KALI_SIM_FRAME) telemetry
     waves so Cyber Commander detects every attack regardless of which sensor port is active.
  2. Directly detects Cyber Commander's UDP/TCP block response AND queries `target_effect_monitor.py`
     (`UDP:9090`) so the simulator progress bar immediately switches to:
       `[STOPPED BY CYBER COMMANDER: <RULE>] Target CPU: 6% | Latency: 3ms (HEALTHY)`
     the moment the Cyber Commander USB pendrive is inserted!
"""

import os
import sys
import time
import json
import socket
import argparse
from typing import Dict, Any, Tuple

BOLD = "\033[1m"
DIM = "\033[2m"
CYAN = "\033[36m"
GREEN = "\033[32m"
AMBER = "\033[33m"
RED = "\033[31m"
RESET = "\033[0m"

ACTION_BY_ATTACK: Dict[str, str] = {
    "SQL_INJECTION": "WAF_AND_FIREWALL_SQLI_DROP",
    "XSS_AND_WEB_INJECTION": "WAF_AND_FIREWALL_RCE_DROP",
    "PATH_TRAVERSAL_LFI": "WAF_AND_FIREWALL_LFI_DROP",
    "SLOW_HTTP": "FIREWALL_CONN_LIMIT_AND_DROP",
    "BRUTE_FORCE": "FIREWALL_AUTH_DROP",
    "ICMP_PING_FLOOD": "FIREWALL_ICMP_ECHO_DROP",
    "DNS_TUNNELING": "FIREWALL_DNS_BLOCK",
    "PORT_SCAN": "FIREWALL_SCAN_DROP",
    "SYN_FLOOD_DDOS": "XDP_EARLY_SYN_DROP",
    "ZERO_DAY_ANOMALY": "XDP_AND_FIREWALL_DROP",
}


def get_local_kali_ip(target_ip: str) -> str:
    """Detects the Kali IP address; if run on the same host as target_ip, uses 10.10.14.99."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.5)
        s.connect((target_ip, 80))
        ip = s.getsockname()[0]
        s.close()
        if ip and not ip.startswith("127.") and ip != target_ip:
            return ip
    except Exception:
        pass
    return "10.10.14.99"


def send_telemetry_to_commander(target_ip: str, http_port: int, udp_port: int, frame: Dict[str, Any]) -> bool:
    """
    Delivers the telemetry wave to Cyber Commander via UDP:53530 AND TCP:8080.
    Returns True if Cyber Commander actively replied that it intercepted/blocked the wave!
    """
    commander_replied = False

    # 1. Send via UDP:53530 (and check for instant ack from Cyber Commander v4.3)
    s_udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s_udp.settimeout(0.15)
    try:
        payload = ("KALI_UDP_FRAME:" + json.dumps(frame) + "\n").encode("utf-8")
        s_udp.sendto(payload, (target_ip, udp_port))
        try:
            ack_raw, _ = s_udp.recvfrom(2048)
            if b"BLOCKED_BY_CYBER_COMMANDER" in ack_raw:
                commander_replied = True
        except Exception:
            pass
    except Exception:
        pass
    finally:
        s_udp.close()

    # 2. Also send via TCP:8080 (`KALI_SIM_FRAME:`) for 100% compatibility with all sensor versions
    if not commander_replied:
        s_tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s_tcp.settimeout(0.20)
        try:
            s_tcp.connect((target_ip, http_port))
            tcp_payload = ("KALI_SIM_FRAME:" + json.dumps(frame) + "\n").encode("utf-8")
            s_tcp.sendall(tcp_payload)
            resp = s_tcp.recv(512)
            if b"CYBER_COMMANDER" in resp or b"403 Forbidden" in resp:
                commander_replied = True
        except Exception:
            pass
        finally:
            s_tcp.close()

    return commander_replied


def query_target_effect_monitor(
    target_ip: str,
    effect_port: int,
    src_ip: str,
    attack_type: str,
    wave: int,
    elapsed_sec: int,
    duration_sec: int,
    commander_replied: bool,
) -> Dict[str, Any]:
    """
    Sends the current simulation wave to `target_effect_monitor.py` (UDP port 9090)
    and receives back the live simulated impact metrics on the target system.
    """
    # cyber_commander.py directly broadcasts CYBER_CMD_SHIELD with its real PID to target_effect_monitor.py

    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.settimeout(0.35)
    req = {
        "src_ip": src_ip,
        "attack_type": attack_type,
        "wave": wave,
        "elapsed_sec": elapsed_sec,
        "duration_sec": duration_sec,
    }
    try:
        raw = ("SIM_EFFECT_FRAME:" + json.dumps(req) + "\n").encode("utf-8")
        s.sendto(raw, (target_ip, effect_port))
        resp_data, _ = s.recvfrom(4096)
        return json.loads(resp_data.decode("utf-8", errors="ignore"))
    except Exception:
        if commander_replied:
            return {
                "ip_blocked": True,
                "mitigation_action": ACTION_BY_ATTACK.get(attack_type, "FIREWALL_DROP"),
                "cpu_pct": 6,
                "latency_ms": 3,
            }
        return {}
    finally:
        s.close()


def format_target_effect_line(effect_resp: Dict[str, Any], wave: int, default_cpu: int, default_lat: int, default_state: str) -> str:
    if effect_resp:
        if effect_resp.get("ip_blocked"):
            act = effect_resp.get("mitigation_action", "FIREWALL_DROP")
            cpu = effect_resp.get("cpu_pct", 6)
            lat = effect_resp.get("latency_ms", 3)
            return f"{GREEN}[STOPPED BY CYBER COMMANDER: {act}] Target CPU: {cpu}% | Latency: {lat}ms (HEALTHY){RESET}"
        else:
            cpu = effect_resp.get("cpu_pct", default_cpu)
            lat = effect_resp.get("latency_ms", default_lat)
            st = effect_resp.get("service_state", default_state)
            return f"{RED}[TARGET EFFECT ACTIVE] CPU: {cpu}% | Latency: {lat}ms | {st[:34]}{RESET}"
    return f"{RED}[TARGET EFFECT ACTIVE] CPU: {default_cpu}% | Latency: {default_lat}ms | {default_state[:34]}{RESET}"


def run_sustained_20s_attack(
    idx: int,
    total_attacks: int,
    title: str,
    attack_code: str,
    wave_fn,
    duration_sec: int = 20,
) -> None:
    print(f"\n{DIM}" + "-" * 96 + f"{RESET}")
    print(f"{BOLD}{AMBER}[Simulated Attack #{idx}/{total_attacks}] Running {duration_sec}-Second Sustained Scenario:{RESET} {BOLD}{CYAN}{title}{RESET}")
    print(f"{DIM}" + "-" * 96 + f"{RESET}")

    t_start = time.time()
    wave_num = 0
    total_packets_sent = 0

    while True:
        elapsed = time.time() - t_start
        if elapsed >= duration_sec:
            break

        wave_num += 1
        t_wave = time.time()
        effect_str, pkts_in_wave = wave_fn(wave_num, int(elapsed) + 1, duration_sec)
        total_packets_sent += pkts_in_wave

        now_elapsed = min(duration_sec, int(time.time() - t_start) + 1)
        bar_len = 16
        filled = int((now_elapsed / duration_sec) * bar_len)
        bar = "█" * filled + "░" * (bar_len - filled)

        print(
            f"  [{bar}] {BOLD}{now_elapsed:02d}s/{duration_sec:02d}s{RESET} | "
            f"Wave #{wave_num:02d} | Pkts: {BOLD}{total_packets_sent:<4}{RESET} | {effect_str}",
            flush=True,
        )

        spent = time.time() - t_wave
        rem = max(0.0, min(1.0 - spent, duration_sec - (time.time() - t_start)))
        if rem > 0:
            time.sleep(rem)

    total_actual_sec = time.time() - t_start
    print(
        f"  {BOLD}{GREEN}[✓ Completed {total_actual_sec:.1f}s Sustained {attack_code} Simulation]{RESET} "
        f"Waves: {wave_num} | Total Simulated Packets: {total_packets_sent}"
    )


def run_kali_attacks(
    target_ip: str,
    http_port: int = 8080,
    ssh_port: int = 2222,
    udp_port: int = 53530,
    effect_port: int = 9090,
    kali_ip: str = "",
    selected: str = "all",
    duration_per_attack: int = 20,
):
    if not kali_ip:
        kali_ip = get_local_kali_ip(target_ip)

    print(f"{DIM}" + "=" * 96 + f"{RESET}")
    print(f"{BOLD}{CYAN}  KALI LINUX 20-SECOND SUSTAINED SIMULATOR WITH TARGET EFFECT MONITOR (v4.3) -> {target_ip}{RESET}")
    print(f"  Simulated Source IP    : {BOLD}{AMBER}{kali_ip}{RESET}")
    print(f"  Duration Per Scenario  : {BOLD}{GREEN}{duration_per_attack} seconds (Continuous 1-Second Telemetry Waves){RESET}")
    print(f"  Target Ports           : UDP/{udp_port} & TCP/{http_port} (Cyber Commander) | UDP/{effect_port} (Target Effect Monitor)")
    print(f"{DIM}" + "=" * 96 + f"{RESET}")

    scenarios = [
        (
            "sqli",
            "SQL Injection (Database Query Anomaly Simulation)",
            "SQL_INJECTION",
            {
                "attack_type": "SQL_INJECTION",
                "attack_hint": "SQL_INJECTION",
                "dst_port": http_port,
                "protocol": "TCP",
                "packets_per_sec": 45.0,
                "bytes_per_pkt": 640.0,
                "conn_rate_per_sec": 12.0,
                "l7_payload_sig_score": 9.5,
            },
            84,
            1850,
            "DATABASE ALERT — UNAUTHORIZED QUERY",
            15,
        ),
        (
            "rce",
            "Web Script & Command Injection Simulation",
            "XSS_AND_WEB_INJECTION",
            {
                "attack_type": "XSS_AND_WEB_INJECTION",
                "attack_hint": "XSS_AND_WEB_INJECTION",
                "dst_port": http_port,
                "protocol": "TCP",
                "packets_per_sec": 38.0,
                "bytes_per_pkt": 590.0,
                "conn_rate_per_sec": 10.0,
                "l7_payload_sig_score": 9.6,
            },
            89,
            2120,
            "APPLICATION WORKER STALL",
            12,
        ),
        (
            "lfi",
            "Directory Path Traversal (LFI Simulation)",
            "PATH_TRAVERSAL_LFI",
            {
                "attack_type": "PATH_TRAVERSAL_LFI",
                "attack_hint": "PATH_TRAVERSAL_LFI",
                "dst_port": http_port,
                "protocol": "TCP",
                "packets_per_sec": 32.0,
                "bytes_per_pkt": 420.0,
                "conn_rate_per_sec": 9.0,
                "l7_payload_sig_score": 9.1,
            },
            78,
            1490,
            "RESTRICTED FILE PATH PROBE",
            10,
        ),
        (
            "slowloris",
            "Slow HTTP (Slowloris Socket Exhaustion Simulation)",
            "SLOW_HTTP",
            {
                "attack_type": "SLOW_HTTP",
                "dst_port": http_port,
                "concurrent_conns": 80.0,
                "avg_conn_duration_sec": 42.0,
                "request_completion_ratio": 0.08,
                "bytes_per_pkt": 72.0,
                "packets_per_sec": 42.0,
            },
            92,
            3420,
            "HTTP 503 SOCKET POOL EXHAUSTED",
            25,
        ),
        (
            "bruteforce",
            "SSH / Login Password Brute-Force Simulation",
            "BRUTE_FORCE",
            {
                "attack_type": "BRUTE_FORCE",
                "dst_port": ssh_port,
                "auth_failures_per_min": 55.0,
                "unique_usernames_tried": 14.0,
                "packets_per_sec": 35.0,
            },
            86,
            1980,
            "AUTH QUEUE SATURATED",
            18,
        ),
        (
            "icmp",
            "ICMP Ping Flood (Bandwidth Saturation Simulation)",
            "ICMP_PING_FLOOD",
            {
                "attack_type": "ICMP_PING_FLOOD",
                "attack_hint": "ICMP_PING_FLOOD",
                "dst_port": 0,
                "protocol": "ICMP",
                "packets_per_sec": 1350.0,
                "icmp_pps": 1300.0,
                "bytes_per_pkt": 1472.0,
                "payload_byte_entropy": 2.6,
            },
            95,
            2890,
            "NETWORK PACKET QUEUE OVERFLOW",
            65,
        ),
        (
            "dns",
            "DNS Tunneling (Covert Exfiltration Simulation)",
            "DNS_TUNNELING",
            {
                "attack_type": "DNS_TUNNELING",
                "dst_port": 53,
                "query_name": "a9f8k7m6x5p4q3z2w1e0r9t8y7u6i5o4p3a2s1d0f9g8h7j6k5l4.sim-tunnel.example",
                "dns_qps": 45.0,
                "packets_per_sec": 55.0,
            },
            81,
            1640,
            "DNS HIGH-ENTROPY STREAM",
            45,
        ),
        (
            "portscan",
            "Network Port Scanning (85-Port Sweep Simulation)",
            "PORT_SCAN",
            {
                "attack_type": "PORT_SCAN",
                "dst_port": 0,
                "unique_dst_ports": 85.0,
                "conn_rate_per_sec": 120.0,
                "syn_to_ack_ratio": 9.5,
                "avg_conn_duration_sec": 0.03,
                "packets_per_sec": 175.0,
            },
            83,
            1720,
            "85 PORTS PROBED",
            40,
        ),
        (
            "synflood",
            "TCP SYN Flood (Handshake Backlog Simulation)",
            "SYN_FLOOD_DDOS",
            {
                "attack_type": "SYN_FLOOD_DDOS",
                "attack_hint": "SYN_FLOOD_DDOS",
                "dst_port": 80,
                "protocol": "TCP",
                "packets_per_sec": 2500.0,
                "bytes_per_pkt": 56.0,
                "conn_rate_per_sec": 2100.0,
                "concurrent_conns": 550.0,
                "syn_to_ack_ratio": 42.0,
                "request_completion_ratio": 0.01,
                "payload_byte_entropy": 1.8,
            },
            97,
            3850,
            "SYN_RECV BACKLOG FULL",
            120,
        ),
        (
            "zeroday",
            "Novel Zero-Day Polymorphic High-Entropy Flood Simulation",
            "ZERO_DAY_ANOMALY",
            {
                "attack_type": "ZERO_DAY_ANOMALY",
                "attack_hint": "ZERO_DAY_ANOMALY",
                "dst_port": udp_port,
                "protocol": "UDP",
                "packets_per_sec": 1950.0,
                "bytes_per_pkt": 1350.0,
                "conn_rate_per_sec": 450.0,
                "concurrent_conns": 220.0,
                "request_completion_ratio": 0.05,
                "unique_dst_ports": 8.0,
                "syn_to_ack_ratio": 16.0,
                "payload_byte_entropy": 7.85,
            },
            96,
            3560,
            "ZERO-DAY ENTROPY OVERLOAD",
            90,
        ),
    ]

    active_list = [
        s for s in scenarios if selected in ("all", s[0]) or (selected == "xss" and s[0] == "rce")
    ]
    if not active_list:
        active_list = scenarios

    total = len(active_list)
    for idx, (short_key, title, code, base_frame, def_cpu, def_lat, def_state, pkts_per_wave) in enumerate(active_list, start=1):
        def _make_wave_fn(b_frame, a_code, d_cpu, d_lat, d_state, p_wave):
            def _wave(w: int, el: int, dur: int) -> Tuple[str, int]:
                frame = dict(b_frame)
                frame["src_ip"] = kali_ip
                frame["process_details"] = f"Simulated {a_code} wave #{w} ({el}s/{dur}s) from {kali_ip}"
                # 1. Send telemetry to Cyber Commander (UDP 53530 + TCP 8080)
                cmd_replied = send_telemetry_to_commander(target_ip, http_port, udp_port, frame)
                time.sleep(0.15)
                # 2. Query Target System Effect Monitor (UDP 9090)
                eff = query_target_effect_monitor(target_ip, effect_port, kali_ip, a_code, w, el, dur, cmd_replied)
                line_str = format_target_effect_line(eff, w, d_cpu, d_lat, d_state)
                return line_str, p_wave
            return _wave

        run_sustained_20s_attack(
            idx,
            total,
            title,
            code,
            _make_wave_fn(base_frame, code, def_cpu, def_lat, def_state, pkts_per_wave),
            duration_sec=duration_per_attack,
        )

    print(f"\n{DIM}" + "=" * 96 + f"{RESET}")
    print(f"{BOLD}{GREEN}  [SIMULATION COMPLETE] All {total} scenarios executed ({duration_per_attack}s each) against {target_ip}!{RESET}")
    print(f"{DIM}" + "=" * 96 + f"{RESET}")


def interactive_menu(target_ip: str, http_port: int, ssh_port: int, udp_port: int, effect_port: int, kali_ip: str, duration_per_attack: int):
    options = {
        "1": ("icmp", "ICMP Ping Flood Simulation (20+ sec)"),
        "2": ("sqli", "SQL Injection Simulation (20+ sec)"),
        "3": ("rce", "Web Script / Command Injection Simulation (20+ sec)"),
        "4": ("lfi", "Directory Path Traversal Simulation (20+ sec)"),
        "5": ("slowloris", "Slow HTTP Socket Exhaustion Simulation (20+ sec)"),
        "6": ("bruteforce", "SSH / Login Brute-Force Simulation (20+ sec)"),
        "7": ("dns", "DNS Tunneling Simulation (20+ sec)"),
        "8": ("portscan", "Multi-Port Scan Simulation (20+ sec)"),
        "9": ("synflood", "TCP SYN Flood Simulation (20+ sec)"),
        "10": ("zeroday", "Novel Zero-Day High-Entropy Simulation (20+ sec)"),
        "a": ("all", "Run ALL Simulated Scenarios Sequentially (20+ seconds each)"),
    }
    while True:
        print(f"\n{BOLD}{CYAN}--- 20-SECOND SUSTAINED SIMULATION MENU (Target: {target_ip}) ---{RESET}")
        for k, (_, desc) in options.items():
            print(f"  [{BOLD}{k}{RESET}] {desc}")
        print(f"  [{BOLD}q{RESET}] Quit")
        choice = input("Select scenario > ").strip().lower()
        if choice == "q":
            break
        if choice in options:
            run_kali_attacks(
                target_ip,
                http_port,
                ssh_port,
                udp_port,
                effect_port,
                kali_ip,
                selected=options[choice][0],
                duration_per_attack=duration_per_attack,
            )


def main():
    parser = argparse.ArgumentParser(description="20-Second Sustained Network Simulation with Target Effect Monitor (v4.3)")
    parser.add_argument("--target", default="127.0.0.1", help="IP address of the Target Host (e.g. 192.168.56.105)")
    parser.add_argument("--http-port", type=int, default=8080, help="Cyber Commander HTTP sensor port (default: 8080)")
    parser.add_argument("--ssh-port", type=int, default=2222, help="Cyber Commander SSH sensor port (default: 2222)")
    parser.add_argument("--udp-port", type=int, default=53530, help="Cyber Commander UDP sensor port (default: 53530)")
    parser.add_argument("--effect-port", type=int, default=9090, help="Target Effect Monitor UDP port (default: 9090)")
    parser.add_argument("--kali-ip", default="", help="Simulated source IP (auto-detected if omitted)")
    parser.add_argument(
        "--attack",
        default="all",
        help="Scenario to run: all, icmp, sqli, rce, lfi, slowloris, bruteforce, dns, portscan, synflood, zeroday",
    )
    parser.add_argument(
        "--duration",
        type=int,
        default=20,
        help="Duration in seconds per scenario (default: 20 seconds; minimum 20s unless --fast-test)",
    )
    parser.add_argument("--fast-test", action="store_true", help="Allow shorter duration for quick automated checks")
    parser.add_argument("--interactive", action="store_true", help="Launch interactive menu")
    args = parser.parse_args()

    dur = args.duration if args.fast_test else max(20, args.duration)

    if args.interactive:
        interactive_menu(args.target, args.http_port, args.ssh_port, args.udp_port, args.effect_port, args.kali_ip, dur)
    else:
        run_kali_attacks(
            args.target,
            args.http_port,
            args.ssh_port,
            args.udp_port,
            args.effect_port,
            args.kali_ip,
            selected=args.attack,
            duration_per_attack=dur,
        )


if __name__ == "__main__":
    main()
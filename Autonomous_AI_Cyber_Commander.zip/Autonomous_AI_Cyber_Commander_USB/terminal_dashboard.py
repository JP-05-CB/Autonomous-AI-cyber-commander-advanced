#!/usr/bin/env python3
"""
terminal_dashboard.py — Low-Glare Muted Terminal Console & Plain-English Attack Narrator
Autonomous AI Cyber Commander v4.0

Enhancements (User Requirements #3 & #5):
- Uses soft, muted, low-glare terminal colors (no bright neon backgrounds or rainbow lines).
- Displays a clear, easy-to-read human-understandable passage whenever an attack is detected,
  explicitly naming the Attacker's IP address, the type of attack initiated, what the attack
  is attempting to do, and the exact protection action taken.
"""

import os
import sys
import time
import threading
from typing import Dict, Any, List
from event_schema import (
    DetectorEvent,
    CAT_BENIGN,
    CAT_SLOW_HTTP,
    CAT_DNS_TUNNELING,
    CAT_PORT_SCAN,
    CAT_BRUTE_FORCE,
    CAT_SYN_FLOOD_DDOS,
    CAT_UDP_AMPLIFICATION_DDOS,
    CAT_ICMP_PING_FLOOD,
    CAT_HTTP_L7_FLOOD,
    CAT_SQL_INJECTION,
    CAT_XSS_AND_WEB_INJECTION,
    CAT_PATH_TRAVERSAL_LFI,
    CAT_ARP_MITM_SPOOFING,
    CAT_SMB_RANSOMWARE_WORM,
    CAT_C2_BOTNET_BEACONING,
    CAT_TLS_SSL_EXPLOIT,
    CAT_LAND_AND_IP_FRAGMENT_ATTACK,
    CAT_ZERO_DAY_ANOMALY,
)

# Subtle, Low-Glare Standard ANSI Palette (No bright 90-97 neon codes or background blocks)
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
MUTED_CYAN = "\033[36m"
MUTED_GREEN = "\033[32m"
MUTED_AMBER = "\033[33m"
MUTED_RED = "\033[31m"


HUMAN_ATTACK_DESCRIPTIONS = {
    CAT_ICMP_PING_FLOOD: (
        "ICMP Ping Flood (Denial-of-Service)",
        "flooding your system with rapid ICMP Echo (ping) requests to exhaust network bandwidth",
    ),
    CAT_SYN_FLOOD_DDOS: (
        "TCP SYN Flood (DDoS Attack)",
        "sending a high-speed flood of half-open TCP SYN packets to exhaust your system's connection table",
    ),
    CAT_UDP_AMPLIFICATION_DDOS: (
        "UDP Amplification / Flood Attack",
        "bombarding your network interface with high-volume UDP packets to saturate link capacity",
    ),
    CAT_HTTP_L7_FLOOD: (
        "HTTP Web Request Flood (Layer-7 DDoS)",
        "overwhelming your web service with hundreds of rapid HTTP GET/POST requests per second",
    ),
    CAT_SLOW_HTTP: (
        "Slow HTTP (Slowloris) Connection Hold Attack",
        "opening many simultaneous connections and sending incomplete HTTP headers slowly to tie up server sockets",
    ),
    CAT_DNS_TUNNELING: (
        "DNS Tunneling & Covert Data Exfiltration",
        "hiding encoded data inside abnormally long, high-entropy DNS queries to smuggle data out of the network",
    ),
    CAT_PORT_SCAN: (
        "Network Port Scanning (Reconnaissance)",
        "probing multiple TCP/UDP ports on your system to discover open services and vulnerabilities",
    ),
    CAT_BRUTE_FORCE: (
        "Password Brute-Force & Credential Guessing",
        "repeatedly attempting unauthorized logins with different usernames and passwords to break into an account",
    ),
    CAT_SQL_INJECTION: (
        "SQL Injection (Database Exploit)",
        "injecting malicious SQL database commands into web requests to steal or modify sensitive records",
    ),
    CAT_XSS_AND_WEB_INJECTION: (
        "Remote Command / Web Script Injection (RCE / XSS)",
        "sending malicious shell/script payloads (such as Log4Shell or OS commands) to execute unauthorized code",
    ),
    CAT_PATH_TRAVERSAL_LFI: (
        "Directory Path Traversal (Local File Inclusion)",
        "using '../' file path tricks to read restricted operating system files such as /etc/passwd",
    ),
    CAT_ARP_MITM_SPOOFING: (
        "ARP Spoofing (Man-in-the-Middle Attack)",
        "broadcasting fake MAC address tables on the local network to intercept your traffic",
    ),
    CAT_SMB_RANSOMWARE_WORM: (
        "SMB Ransomware / Worm Propagation Attempt",
        "probing Windows/Samba file-sharing port 445 with EternalBlue-style exploit buffers to spread malware",
    ),
    CAT_C2_BOTNET_BEACONING: (
        "Botnet Command-and-Control (C2) Beaconing",
        "communicating periodically with an external malware command server",
    ),
    CAT_TLS_SSL_EXPLOIT: (
        "TLS/SSL Handshake & Encryption Exploit",
        "sending malformed SSL/TLS handshakes to crash or downgrade encrypted connections",
    ),
    CAT_LAND_AND_IP_FRAGMENT_ATTACK: (
        "Malformed Packet / IP Fragmentation Attack",
        "sending corrupted TCP/IP headers (such as invalid SYN+FIN flags or overlapping fragments) to crash the network stack",
    ),
    CAT_ZERO_DAY_ANOMALY: (
        "Novel Zero-Day Attack (Unfamiliar High-Risk Traffic Pattern)",
        "sending an abnormal, high-entropy traffic surge that deviates sharply from normal system behavior",
    ),
}


class TerminalDashboard:
    """Renders a calm, low-glare live terminal view with plain-English attack explanations."""

    def __init__(self, use_color: bool = True):
        self.use_color = use_color and (sys.stdout.isatty() or os.environ.get("FORCE_COLOR", "1") == "1")
        self._lock = threading.Lock()
        self.start_time = time.time()
        self.events_processed = 0
        self.attacks_blocked = 0
        self.fastpath_hits = 0
        self.zero_days_contained = 0
        self._last_card_by_key: Dict[str, float] = {}
        self._wave_count_by_key: Dict[str, int] = {}

    def _c(self, code: str, text: str) -> str:
        return f"{code}{text}{RESET}" if self.use_color else text

    def print_startup_banner(
        self,
        pid: int,
        host_identity: Dict[str, Any],
        backend: str,
        memory_stats: Dict[str, Any],
        ai_metrics: Dict[str, Any],
        detector_threads: List[threading.Thread],
    ) -> None:
        with self._lock:
            line = "-" * 88
            patterns_cnt = memory_stats.get("validated_patterns_count", 0)
            history_desc = (
                "Clean New Session (0 previous attacks — learning live)"
                if patterns_cnt == 0
                else f"{patterns_cnt} learned attack patterns in current history"
            )
            print(self._c(DIM, line))
            print(self._c(BOLD + MUTED_CYAN, "  AUTONOMOUS AI CYBER COMMANDER v4.0 — LIVE USB SYSTEM PROTECTION TERMINAL"))
            print(self._c(DIM, line))
            print(f"  Running Process PID : {self._c(MUTED_GREEN, str(pid))} (Active)")
            print(f"  Protected Host IP   : {self._c(BOLD, host_identity.get('primary_ip', '127.0.0.1'))} (Interface: {host_identity.get('primary_iface', 'eth0')})")
            print(f"  Firewall Mode       : {backend}")
            print(f"  Attack History DB   : {self._c(MUTED_CYAN, history_desc)}")
            print(self._c(DIM, line))
            print("  Running Background Monitoring Processes:")
            thread_Convert = {
                "http_detector_thread": "Web & Slow HTTP Connection Monitor (Ports 80/443/8080)",
                "dns_detector_thread": "DNS Tunneling & Covert Query Monitor (Port 53)",
                "port_scan_detector_thread": "Port Scan & Reconnaissance Monitor (All TCP/UDP Ports)",
                "brute_force_detector_thread": "SSH & Login Brute-Force Monitor (Ports 22/2222)",
                "multi_vector_detector_thread": "Kernel ICMP Flood, ARP Spoof, SYN Flood & Web Exploit Monitor",
                "live_network_sensor_thread": "Live Network Wire & Socket Packet Sensor (ICMP, TCP, UDP)",
            }
            for t in detector_threads:
                status = self._c(MUTED_GREEN, "ACTIVE") if t.is_alive() else self._c(MUTED_RED, "STOPPED")
                tid = getattr(t, "native_id", None) or getattr(t, "ident", 0)
                desc = thread_Convert.get(t.name, "Network Traffic Monitor")
                print(f"    [{status}] PID/TID {str(tid):<7} - {desc}")
            print(self._c(DIM, line))
            print(self._c(MUTED_GREEN, "  System is now actively protecting your IP. Waiting for network traffic..."))
            print(self._c(DIM, line))
            sys.stdout.flush()

    def print_attack_process_card(self, event: DetectorEvent, result: Dict[str, Any]) -> None:
        """
        Prints an easy-to-understand plain-English passage explaining the attack,
        the Attacker's IP, what type of attack was initiated, and how it was stopped.
        """
        with self._lock:
            self.events_processed += 1
            cat = result["attack_category"]
            mode = result["decision_source"]
            conf = result["confidence"]
            approved = result["policy_approved"]
            action = result["mitigation_action"]
            ms = result["response_time_ms"]
            src_ip = event.src_ip
            dst_ip = event.dst_ip
            dst_port = event.dst_port
            proto = event.protocol
            ts_str = time.strftime("%H:%M:%S")

            friendly_name, what_it_does = HUMAN_ATTACK_DESCRIPTIONS.get(
                cat,
                (cat.replace("_", " ").title(), "sending suspicious network traffic to your system"),
            )

            # Case 1: Benign normal traffic
            if cat == CAT_BENIGN:
                print(f"  [{ts_str}] {self._c(MUTED_GREEN, 'NORMAL TRAFFIC ALLOWED')} | Source IP: {src_ip}")
                print(f"  Summary : Normal {proto} communication from {src_ip} to {dst_ip}:{dst_port}. No action needed.")
                print(self._c(DIM, "-" * 88))
                sys.stdout.flush()
                return

            # Case 2: Protected Host/Gateway Safeguard (preventing self-lockout)
            if not approved:
                print(f"  [{ts_str}] {self._c(MUTED_CYAN, 'SAFETY GUARDRAIL ACTIVE')} | Source IP: {src_ip}")
                print(
                    f"  Summary : Detected {friendly_name} activity from {src_ip}, but {src_ip} is your own "
                    f"protected host/gateway IP. Blocked self-lockout automatically."
                )
                print(self._c(DIM, "-" * 88))
                sys.stdout.flush()
                return

            # Case 3: Real Attack Detected & Blocked!
            self.attacks_blocked += 1
            now_t = time.time()
            dedup_key = f"{src_ip}:{cat}"
            last_shown = self._last_card_by_key.get(dedup_key, 0.0)
            wave_idx = self._wave_count_by_key.get(dedup_key, 0) + 1
            self._wave_count_by_key[dedup_key] = wave_idx

            # If this is an ongoing wave of the exact same 20-second attack within 16 seconds,
            # print a clean 1-line live wave mitigation update so the full passage stays easy to read!
            if (now_t - last_shown) < 25.0 and 1 < wave_idx <= 20:
                print(
                    self._c(
                        MUTED_AMBER,
                        f"  [{ts_str}] [Ongoing Attack Blocked — Wave #{wave_idx:02d}] "
                        f"Attacker IP {src_ip} continuing {friendly_name} -> Dropped by {action} ({ms:.1f} ms)",
                    )
                )
                sys.stdout.flush()
                return

            self._last_card_by_key[dedup_key] = now_t
            print(self._c(DIM, "\n" + "-" * 88))
            port_desc = f"port {dst_port} ({proto})" if dst_port > 0 else f"protocol {proto}"

            if mode == "STATIC_MEMORY_FASTPATH":
                self.fastpath_hits += 1
                status_label = self._c(BOLD + MUTED_AMBER, "[REPEAT ATTACK BLOCKED FROM ATTACK HISTORY]")
                history_sentence = (
                    "Because this attack pattern was already recorded in your current Attack History, "
                    "Cyber Commander recognized it immediately without needing to re-run AI analysis."
                )
            elif mode == "NOVEL_ZERO_DAY":
                self.zero_days_contained += 1
                status_label = self._c(BOLD + MUTED_RED, "[ZERO-DAY ATTACK DETECTED & BLOCKED]")
                history_sentence = (
                    "This unfamiliar zero-day attack pattern has now been saved into your Attack History "
                    "so any future repeat attempt will be blocked instantly."
                )
            else:
                status_label = self._c(BOLD + MUTED_RED, "[CYBER ATTACK DETECTED & BLOCKED]")
                history_sentence = (
                    "This attack signature has now been saved into your new Attack History database "
                    "for instant recognition if it happens again."
                )

            print(f"  {status_label}  (Time: {ts_str})")
            print(f"  • {self._c(BOLD, 'Attacker IP Address')} : {self._c(BOLD + MUTED_AMBER, src_ip)}")
            print(f"  • {self._c(BOLD, 'Attack Initiated')}    : {self._c(BOLD, friendly_name)} [{cat}]")
            print(f"  • {self._c(BOLD, 'Target on Your Host')} : {dst_ip} on {port_desc}")
            print()
            print(f"  {self._c(BOLD, 'What Happened (Plain-English Summary):')}")
            print(
                f"    An external system at IP address {self._c(BOLD, src_ip)} initiated a "
                f"{self._c(BOLD, friendly_name)} attack against your host ({dst_ip}) by {what_it_does}."
            )
            print(
                f"    {history_sentence} Cyber Commander automatically blocked attacker IP {self._c(BOLD, src_ip)} "
                f"in the firewall ({action}) in {ms:.1f} ms."
            )
            print()
            print(
                self._c(
                    DIM,
                    f"  [Process Details] Detector: {event.detector_name} (PID {os.getpid()}) | "
                    f"Confidence: {conf*100:.1f}% | Rate: {event.features.get('packets_per_sec', 0):.0f} pkt/s | "
                    f"Fingerprint: {result['fingerprint']}",
                )
            )
            print(self._c(DIM, "-" * 88))
            sys.stdout.flush()

    def print_heartbeat(self, protected_ip: str, active_rules_count: int, validated_patterns_count: int) -> None:
        with self._lock:
            uptime = int(time.time() - self.start_time)
            msg = (
                f"  [{time.strftime('%H:%M:%S')}] [Monitoring Active] PID {os.getpid()} | Uptime: {uptime}s | "
                f"Protected IP: {protected_ip} | Attacks Blocked: {self.attacks_blocked} | "
                f"Attack History Entries: {validated_patterns_count}"
            )
            print(self._c(DIM, msg))
            sys.stdout.flush()
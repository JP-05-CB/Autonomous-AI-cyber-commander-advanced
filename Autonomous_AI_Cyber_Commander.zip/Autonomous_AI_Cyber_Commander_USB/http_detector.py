#!/usr/bin/env python3
"""
http_detector.py — Slow HTTP (Slowloris / Slow POST) & HTTP Anomaly Detector
Autonomous AI Cyber Commander

Monitors active HTTP connections (via /proc/net/tcp socket telemetry and application flow feeds)
for Slow HTTP attacks (Section 4.1):
- High connection duration with minimal request progress (low request_completion_ratio)
- Excessive concurrent open connections from a single source IP holding sockets in ESTABLISHED/SYN_RECV
- Exports start_detector(event_queue, stop_event, config) for the central Cyber Commander controller.
"""

import time
import threading
import queue
from typing import Dict, Any, Optional
from event_schema import DetectorEvent, CAT_SLOW_HTTP, CAT_BENIGN


class SlowHTTPDetector:
    """Evaluates HTTP connection telemetry for Slowloris / Slow POST resource exhaustion."""

    def __init__(self, target_ip: str = "127.0.0.1", http_ports=(80, 443, 8080, 8000, 8443)):
        self.target_ip = target_ip
        self.http_ports = set(http_ports)

    def analyze_flow(self, flow: Dict[str, Any]) -> Optional[DetectorEvent]:
        """
        Inspects an HTTP flow record and emits a DetectorEvent if suspicious or requested.
        """
        src_ip = flow.get("src_ip", "0.0.0.0")
        dst_ip = flow.get("dst_ip", self.target_ip)
        dst_port = int(flow.get("dst_port", 80))
        concurrent = float(flow.get("concurrent_conns", 1.0))
        duration = float(flow.get("avg_conn_duration_sec", 1.0))
        completion_ratio = float(flow.get("request_completion_ratio", 1.0))
        pps = float(flow.get("packets_per_sec", 10.0))
        bytes_per_pkt = float(flow.get("bytes_per_pkt", 450.0))
        conn_rate = float(flow.get("conn_rate_per_sec", 2.0))

        # Calculate Slow HTTP suspicion score based on Section 4.1 signals:
        # 1) Long connection hold duration (>20s)
        # 2) Very low request completion progress (<0.30)
        # 3) High per-source concurrent connections (>=25)
        # 4) Small drip-feed packets (<180 bytes/pkt)
        score = 0.0
        reasons = []

        if duration >= 25.0:
            score += 0.35
            reasons.append(f"prolonged connection hold ({duration:.1f}s)")
        elif duration >= 12.0:
            score += 0.15

        if completion_ratio <= 0.25:
            score += 0.35
            reasons.append(f"stalled HTTP request progress ({completion_ratio*100:.1f}% completed)")
        elif completion_ratio <= 0.50:
            score += 0.15

        if concurrent >= 35:
            score += 0.25
            reasons.append(f"high concurrent open sockets ({int(concurrent)} connections)")
        elif concurrent >= 15:
            score += 0.10

        if bytes_per_pkt <= 160.0 and duration >= 15.0:
            score += 0.15
            reasons.append(f"drip-feed header bytes ({bytes_per_pkt:.0f} B/pkt)")

        confidence = min(0.99, round(score, 3))
        is_attack = confidence >= 0.55

        if not is_attack and not flow.get("force_emit", False):
            return None

        severity = "CRITICAL" if confidence >= 0.85 else ("HIGH" if confidence >= 0.65 else "LOW")
        cat = CAT_SLOW_HTTP if is_attack else CAT_BENIGN
        evidence = (
            f"Slow HTTP signature from {src_ip}->{dst_ip}:{dst_port}: " + ", ".join(reasons)
            if reasons
            else f"Normal HTTP traffic from {src_ip}->{dst_ip}:{dst_port}"
        )

        return DetectorEvent(
            detector_name="http_detector",
            src_ip=src_ip,
            dst_ip=dst_ip,
            dst_port=dst_port,
            protocol="TCP",
            suspected_category=cat,
            detector_confidence=confidence if is_attack else (1.0 - confidence),
            severity=severity,
            features={
                "packets_per_sec": pps,
                "bytes_per_pkt": bytes_per_pkt,
                "conn_rate_per_sec": conn_rate,
                "concurrent_conns": concurrent,
                "avg_conn_duration_sec": duration,
                "request_completion_ratio": completion_ratio,
                "unique_dst_ports": float(flow.get("unique_dst_ports", 1.0)),
                "syn_to_ack_ratio": float(flow.get("syn_to_ack_ratio", 1.1)),
                "auth_failures_per_min": float(flow.get("auth_failures_per_min", 0.0)),
                "unique_usernames_tried": float(flow.get("unique_usernames_tried", 0.0)),
                "dns_query_len": float(flow.get("dns_query_len", 14.0)),
                "dns_shannon_entropy": float(flow.get("dns_shannon_entropy", 2.2)),
                "dns_qps": float(flow.get("dns_qps", 0.2)),
                "payload_byte_entropy": float(flow.get("payload_byte_entropy", 4.1)),
            },
            evidence_summary=evidence,
            process_details="Socket table /proc/net/tcp inspection: high concurrent ESTABLISHED sockets holding incomplete HTTP headers",
            raw_metadata={"detector": "SlowHTTPDetector", "reasons": reasons},
        )

    def poll_proc_net_tcp(self) -> Dict[str, Dict[str, Any]]:
        """
        Reads live Linux /proc/net/tcp socket table to count per-source-IP concurrent HTTP sockets.
        """
        per_ip: Dict[str, Dict[str, Any]] = {}
        try:
            with open("/proc/net/tcp", "r") as f:
                lines = f.readlines()[1:]
            for line in lines:
                parts = line.strip().split()
                if len(parts) < 4:
                    continue
                local_hex, rem_hex, state_hex = parts[1], parts[2], parts[3]
                local_port = int(local_hex.split(":")[1], 16)
                if local_port not in self.http_ports:
                    continue
                rem_ip_hex = rem_hex.split(":")[0]
                if len(rem_ip_hex) == 8:
                    ip_bytes = [str(int(rem_ip_hex[i:i+2], 16)) for i in range(6, -1, -2)]
                    rem_ip = ".".join(ip_bytes)
                    if rem_ip.startswith("127.") or rem_ip == "0.0.0.0":
                        continue
                    entry = per_ip.setdefault(rem_ip, {"concurrent_conns": 0, "dst_port": local_port, "half_open": 0})
                    entry["concurrent_conns"] += 1
                    if state_hex in ("02", "03"):  # SYN_SENT / SYN_RECV
                        entry["half_open"] += 1
        except Exception:
            pass
        return per_ip


def start_detector(
    event_queue: queue.Queue,
    stop_event: threading.Event,
    config: Optional[Dict[str, Any]] = None,
) -> threading.Thread:
    """
    Standardized entry point required by Cyber Commander (Section 5).
    Starts background monitoring of HTTP socket telemetry and processes injected test flows.
    """
    cfg = config or {}
    target_ip = cfg.get("protected_ip", "127.0.0.1")
    poll_interval = float(cfg.get("poll_interval", 2.0))
    detector = SlowHTTPDetector(target_ip=target_ip)

    def _worker():
        while not stop_event.is_set():
            live_sockets = detector.poll_proc_net_tcp()
            for src_ip, stats in live_sockets.items():
                if stats["concurrent_conns"] >= 30:
                    evt = detector.analyze_flow({
                        "src_ip": src_ip,
                        "dst_ip": target_ip,
                        "dst_port": stats["dst_port"],
                        "concurrent_conns": stats["concurrent_conns"],
                        "avg_conn_duration_sec": 35.0,
                        "request_completion_ratio": 0.15,
                        "bytes_per_pkt": 96.0,
                        "packets_per_sec": stats["concurrent_conns"] * 1.2,
                    })
                    if evt:
                        event_queue.put(evt)
            stop_event.wait(poll_interval)

    t = threading.Thread(target=_worker, name="http_detector_thread", daemon=True)
    t.start()
    return t

#!/usr/bin/env python3
"""
detectors/dns_tunnel_detector.py — DNS Tunneling (`dns_tunnel_sim.py`) & DNS Rebinding (`dns_rebind_sim.py`) Detector
Autonomous AI Cyber Commander
"""

import math
import time
from collections import Counter, defaultdict, deque
from security_event import SecurityEvent

try:
    from scapy.all import sniff, IP, UDP, DNS, DNSQR, DNSRR
    HAS_SCAPY = True
except Exception:
    HAS_SCAPY = False

TARGET_IP = "192.168.56.105"
INTERFACE = "enp0s8"
SUBDOMAIN_LEN_THRESHOLD = 35
QUERY_THRESHOLD = 5
WINDOW_SECONDS = 10

dns_queries = defaultdict(deque)
rebind_answers = defaultdict(set)


def shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    counts = Counter(s)
    n = len(s)
    return round(-sum((c / n) * math.log2(c / n) for c in counts.values()), 3)


def inspect_dns_packet(packet, commander, target_ip: str):
    if not HAS_SCAPY or not packet.haslayer(IP) or not packet.haslayer(UDP):
        return

    src_ip = packet[IP].src
    now = time.time()

    # 1. Detect DNS Tunneling (`Attacks/dns_tunnel_sim.py` -> 45-char random subdomain labels on port 53)
    if packet.haslayer(DNSQR):
        try:
            qname = packet[DNSQR].qname.decode("utf-8", errors="ignore").rstrip(".")
        except Exception:
            return
        first_label = qname.split(".")[0] if "." in qname else qname
        ent = shannon_entropy(first_label)

        if len(first_label) >= SUBDOMAIN_LEN_THRESHOLD or ent >= 3.7:
            dq = dns_queries[src_ip]
            while dq and (now - dq[0] > WINDOW_SECONDS):
                dq.popleft()
            dq.append(now)
            if len(dq) >= QUERY_THRESHOLD:
                dq.clear()
                evt = SecurityEvent(
                    event_type="DNS_TUNNELING",
                    source_ip=src_ip,
                    target_ip=target_ip,
                    service_port=53,
                    failed_attempts=QUERY_THRESHOLD,
                    window_seconds=WINDOW_SECONDS,
                    confidence=0.96,
                    protocol="UDP",
                    evidence={"query_name": qname, "label_len": len(first_label), "entropy": ent},
                    process_details=f"DNS Tunneling Detector caught high-entropy subdomain ({len(first_label)} chars, H={ent}) from {src_ip}",
                    timestamp=now,
                )
                print("\n[ALERT] DNS TUNNELING DETECTED")
                print(evt.to_json())
                commander.publish_event(evt)

    # 2. Detect DNS Rebinding (`Attacks/dns_rebind_sim.py` -> TTL<=1 alternating public/private IP answers)
    if packet.haslayer(DNSRR):
        try:
            rr = packet[DNSRR]
            rrname = rr.rrname.decode("utf-8", errors="ignore").rstrip(".")
            rdata = str(rr.rdata)
            ttl = int(getattr(rr, "ttl", 60))
            if ttl <= 5:
                rebind_answers[rrname].add(rdata)
                if len(rebind_answers[rrname]) >= 2:
                    rebind_answers[rrname].clear()
                    evt = SecurityEvent(
                        event_type="DNS_REBINDING",
                        source_ip=src_ip,
                        target_ip=target_ip,
                        service_port=5353,
                        failed_attempts=2,
                        window_seconds=WINDOW_SECONDS,
                        confidence=0.94,
                        protocol="UDP",
                        evidence={"domain": rrname, "ttl": ttl, "alternating_ip": rdata},
                        process_details=f"DNS Rebinding Detector caught low-TTL ({ttl}s) alternating IP answer for {rrname} from {src_ip}",
                        timestamp=now,
                    )
                    print("\n[ALERT] DNS REBINDING ATTACK DETECTED")
                    print(evt.to_json())
                    commander.publish_event(evt)
        except Exception:
            pass


def start_detector(commander):
    target_ip = getattr(commander, "protected_ip", TARGET_IP)
    iface = getattr(commander, "primary_iface", INTERFACE)
    print("[+] DNS Tunneling & Rebinding Detector started.")
    if HAS_SCAPY and hasattr(os, "geteuid") and os.geteuid() == 0:
        try:
            sniff(
                iface=iface,
                filter="udp port 53 or udp port 5353",
                prn=lambda pkt: inspect_dns_packet(pkt, commander, target_ip),
                store=False,
            )
        except Exception:
            pass

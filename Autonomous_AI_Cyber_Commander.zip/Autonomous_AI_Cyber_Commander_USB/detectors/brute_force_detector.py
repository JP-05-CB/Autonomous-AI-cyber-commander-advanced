#!/usr/bin/env python3
"""
detectors/brute_force_detector.py — Fixed & Enhanced HTTP Basic Auth (8081) + SSH (22/2222) Brute-Force Detector
Autonomous AI Cyber Commander

Fixes the bug in the original prototype where `brute_force_detector.py` was accidentally a copy of
`icmp_flood_detector.py`. Now detects:
1. `Attacks/bruteforce_sim.py` (HTTP Basic Auth brute-force against port 8081 `/login`)
2. SSH / TCP port 22 & 2222 credential brute-force bursts
3. Scapy packet capture for HTTP `Authorization: Basic` and SSH handshake floods
"""

import time
import socket
import threading
from collections import defaultdict, deque
from security_event import SecurityEvent

try:
    from scapy.all import sniff, IP, TCP, Raw
    HAS_SCAPY = True
except Exception:
    HAS_SCAPY = False

TARGET_IP = "192.168.56.105"
HTTP_AUTH_PORT = 8081
SSH_TRAP_PORT = 2222
INTERFACE = "enp0s8"

ATTEMPT_THRESHOLD = 5
WINDOW_SECONDS = 10

auth_history = defaultdict(deque)
_lock = threading.Lock()


def _record_auth_attempt(source_ip: str, target_ip: str, port: int, commander) -> None:
    now = time.time()
    with _lock:
        attempts = auth_history[source_ip]
        while attempts and (now - attempts[0] > WINDOW_SECONDS):
            attempts.popleft()
        attempts.append(now)
        count = len(attempts)

    print(f"[BRUTE FORCE] {source_ip} -> {target_ip}:{port} failed_attempts={count}")

    if count >= ATTEMPT_THRESHOLD:
        with _lock:
            auth_history[source_ip].clear()
        event = SecurityEvent(
            event_type="BRUTE_FORCE",
            source_ip=source_ip,
            target_ip=target_ip,
            service_port=port,
            failed_attempts=count,
            window_seconds=WINDOW_SECONDS,
            confidence=0.95,
            protocol="TCP",
            evidence={"failed_attempts": count, "service_port": port, "window_seconds": WINDOW_SECONDS},
            process_details=f"Brute-Force Detector captured {count} rapid login failures on port {port} from {source_ip}",
            timestamp=time.time(),
        )
        print("\n[ALERT] BRUTE FORCE ATTACK DETECTED")
        print("\n[SECURITY EVENT]")
        print(event.to_json())
        commander.publish_event(event)


def _run_http_auth_trap_8081(commander, target_ip: str) -> None:
    """Listens on TCP port 8081 so `Attacks/bruteforce_sim.py` connects and triggers 401 brute-force alerts."""
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.settimeout(1.0)
    try:
        srv.bind(("0.0.0.0", HTTP_AUTH_PORT))
        srv.listen(64)
    except Exception:
        return

    stop_ev = getattr(commander, "stop_event", None)
    while not (stop_ev and stop_ev.is_set()):
        try:
            conn, addr = srv.accept()
        except socket.timeout:
            continue
        except Exception:
            break
        try:
            conn.settimeout(1.5)
            data = conn.recv(2048).decode("utf-8", errors="ignore")
            peer_ip = addr[0]
            if "Authorization: Basic" in data or "/login" in data:
                _record_auth_attempt(peer_ip, target_ip, HTTP_AUTH_PORT, commander)
            resp = (
                "HTTP/1.1 401 Unauthorized\r\n"
                'WWW-Authenticate: Basic realm="CyberCommanderLab"\r\n'
                "Content-Length: 12\r\n\r\nUnauthorized"
            )
            conn.sendall(resp.encode("utf-8"))
        except Exception:
            pass
        finally:
            conn.close()
    srv.close()


def detect_brute_force_packet(packet, commander, target_ip: str):
    if not HAS_SCAPY or not packet.haslayer(IP) or not packet.haslayer(TCP):
        return
    dport = packet[TCP].dport
    if dport not in (HTTP_AUTH_PORT, 22, 2222):
        return
    if packet.haslayer(Raw):
        payload = packet[Raw].load.decode("utf-8", errors="ignore")
        if "Authorization: Basic" in payload or "SSH-" in payload:
            _record_auth_attempt(packet[IP].src, target_ip, dport, commander)


def start_detector(commander, stop_event=None, config=None):
    # Support both prototype signature `start_detector(commander)` and queue signature
    if hasattr(commander, "put"):
        import brute_force_detector_legacy
        return brute_force_detector_legacy.start_detector(commander, stop_event, config)

    target_ip = getattr(commander, "protected_ip", TARGET_IP)
    iface = getattr(commander, "primary_iface", INTERFACE)
    print(f"[+] Brute Force Detector started (Monitoring TCP/{HTTP_AUTH_PORT} & TCP/22).")

    t_8081 = threading.Thread(target=_run_http_auth_trap_8081, args=(commander, target_ip), daemon=True)
    t_8081.start()

    if HAS_SCAPY and hasattr(os, "geteuid") and os.geteuid() == 0:
        try:
            sniff(
                iface=iface,
                filter=f"tcp dst port {HTTP_AUTH_PORT} or tcp dst port 22",
                prn=lambda pkt: detect_brute_force_packet(pkt, commander, target_ip),
                store=False,
            )
        except Exception:
            pass
    return t_8081

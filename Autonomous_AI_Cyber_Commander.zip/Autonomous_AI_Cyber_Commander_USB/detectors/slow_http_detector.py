#!/usr/bin/env python3
"""
detectors/slow_http_detector.py — Slow HTTP (`slow_http.py`), HTTP Request Smuggling (`http_smug.py`),
TCP FIN Scan (`fin_scan_sim.py`), and IP Fragmentation (`tcp_frag.py`) Detector
Autonomous AI Cyber Commander
"""

import os
import time
from collections import defaultdict, deque
from security_event import SecurityEvent

try:
    from scapy.all import sniff, IP, TCP, Raw
    HAS_SCAPY = True
except Exception:
    HAS_SCAPY = False

TARGET_IP = "192.168.56.105"
INTERFACE = "enp0s8"

fin_scan_ports = defaultdict(set)
frag_counts = defaultdict(deque)
slow_http_conns = defaultdict(deque)


def inspect_advanced_packet(packet, commander, target_ip: str):
    if not HAS_SCAPY or not packet.haslayer(IP):
        return

    ip_layer = packet[IP]
    src_ip = ip_layer.src
    if src_ip in ("127.0.0.1", target_ip):
        return
    now = time.time()

    # 1. Detect IP Fragmentation Flood (`Attacks/tcp_frag.py`: flags MF=1 or frag > 0)
    if (ip_layer.flags & 0x1) or ip_layer.frag > 0:
        fq = frag_counts[src_ip]
        while fq and (now - fq[0] > 5.0):
            fq.popleft()
        fq.append(now)
        if len(fq) >= 10:
            fq.clear()
            evt = SecurityEvent(
                event_type="IP_FRAGMENTATION",
                source_ip=src_ip,
                target_ip=target_ip,
                service_port=0,
                failed_attempts=10,
                window_seconds=5.0,
                confidence=0.95,
                protocol="ICMP",
                evidence={"fragment_offset": ip_layer.frag, "fragments_in_5s": 10},
                process_details=f"IP Fragmentation Detector caught fragmented packet flood from {src_ip}",
                timestamp=now,
            )
            print("\n[ALERT] IP FRAGMENTATION ATTACK DETECTED")
            print(evt.to_json())
            commander.publish_event(evt)
        return

    if not packet.haslayer(TCP):
        return

    tcp = packet[TCP]
    dport = tcp.dport

    # 2. Detect Stealth TCP FIN Scan (`Attacks/fin_scan_sim.py`: TCP flags == F (0x01) without ACK)
    if int(tcp.flags) == 0x01:
        fin_scan_ports[src_ip].add(dport)
        if len(fin_scan_ports[src_ip]) >= 10:
            count = len(fin_scan_ports[src_ip])
            fin_scan_ports[src_ip].clear()
            evt = SecurityEvent(
                event_type="TCP_FIN_SCAN",
                source_ip=src_ip,
                target_ip=target_ip,
                unique_ports=count,
                service_port=dport,
                failed_attempts=count,
                window_seconds=5.0,
                confidence=0.94,
                protocol="TCP",
                evidence={"unique_fin_ports": count},
                process_details=f"Stealth TCP FIN Scan detected across {count} ports from {src_ip}",
                timestamp=now,
            )
            print("\n[ALERT] STEALTH TCP FIN SCAN DETECTED")
            print(evt.to_json())
            commander.publish_event(evt)
        return

    # 3. Detect HTTP Request Smuggling (`Attacks/http_smug.py`) & Slow HTTP (`Attacks/slow_http.py`)
    if packet.haslayer(Raw) and dport in (80, 8080):
        payload = packet[Raw].load.decode("utf-8", errors="ignore")
        low = payload.lower()

        # Check conflicting Content-Length + Transfer-Encoding: chunked (`http_smug.py`)
        if "content-length:" in low and "transfer-encoding: chunked" in low:
            evt = SecurityEvent(
                event_type="HTTP_SMUGGLING",
                source_ip=src_ip,
                target_ip=target_ip,
                service_port=dport,
                failed_attempts=1,
                window_seconds=1.0,
                confidence=0.98,
                protocol="TCP",
                evidence={"conflicting_headers": ["Content-Length", "Transfer-Encoding: chunked"]},
                process_details=f"HTTP Request Smuggling (CL.TE conflicting headers) detected on port {dport} from {src_ip}",
                timestamp=now,
            )
            print("\n[ALERT] HTTP REQUEST SMUGGLING DETECTED")
            print(evt.to_json())
            commander.publish_event(evt)
            return

        # Check incomplete Slow HTTP header drip (`slow_http.py`: `X-Test-` or missing `\r\n\r\n`)
        if "x-test-" in low or "x-slowloris" in low or (payload.startswith("GET ") and not payload.endswith("\r\n\r\n")):
            sq = slow_http_conns[src_ip]
            while sq and (now - sq[0] > 15.0):
                sq.popleft()
            sq.append(now)
            if len(sq) >= 4:
                sq.clear()
                evt = SecurityEvent(
                    event_type="SLOW_HTTP",
                    source_ip=src_ip,
                    target_ip=target_ip,
                    service_port=dport,
                    connection_count=4,
                    window_seconds=15.0,
                    confidence=0.95,
                    protocol="TCP",
                    evidence={"incomplete_headers": True, "sample": payload[:60]},
                    process_details=f"Slow HTTP (Slowloris incomplete header hold) detected on port {dport} from {src_ip}",
                    timestamp=now,
                )
                print("\n[ALERT] SLOW HTTP (SLOWLORIS) ATTACK DETECTED")
                print(evt.to_json())
                commander.publish_event(evt)


def start_detector(commander):
    target_ip = getattr(commander, "protected_ip", TARGET_IP)
    iface = getattr(commander, "primary_iface", INTERFACE)
    print("[+] Slow HTTP, Request Smuggling, FIN Scan & Fragmentation Detector started.")
    if HAS_SCAPY and hasattr(os, "geteuid") and os.geteuid() == 0:
        try:
            sniff(
                iface=iface,
                filter="ip",
                prn=lambda pkt: inspect_advanced_packet(pkt, commander, target_ip),
                store=False,
            )
        except Exception:
            pass

#!/usr/bin/env python3
"""
target_effect_monitor.py — Target System Simulated Impact & Recovery Monitor (v4.3)
Autonomous AI Cyber Commander

How It Works with `cyber_commander.py` (v4.3):
  1. BEFORE Cyber Commander USB is inserted:
     Displays the simulated degradation on the target system (CPU 84%-97%, Socket Pool saturation,
     Latency >1,800 ms, and plain-English service impact).
  2. THE MOMENT Cyber Commander USB is inserted (`cyber_commander.py` running):
     Receives live `CYBER_CMD_SHIELD` broadcasts on UDP:9090 (and checks `/tmp/cyber_commander_shield.json`
     + `/proc` + `active_firewall_rules.json`) and immediately stops all simulated attack effects,
     dropping CPU load to 6% and latency to 3 ms (HEALTHY)!
"""

import os
import sys
import glob
import time
import json
import socket
import argparse
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Dict, Any, Optional, Tuple

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
CYAN = "\033[36m"
GREEN = "\033[32m"
AMBER = "\033[33m"
RED = "\033[31m"

SHIELD_STATE_FILE = "/tmp/cyber_commander_shield.json"

ACTION_BY_ATTACK: Dict[str, str] = {
    "SQL_INJECTION": "WAF_AND_FIREWALL_SQLI_DROP",
    "XSS_AND_WEB_INJECTION": "WAF_AND_FIREWALL_RCE_DROP",
    "PATH_TRAVERSAL_LFI": "WAF_AND_FIREWALL_LFI_DROP",
    "SLOW_HTTP": "FIREWALL_CONN_LIMIT_AND_DROP",
    "BRUTE_FORCE": "FIREWALL_AUTH_DROP",
    "ICMP_PING_FLOOD": "FIREWALL_ICMP_ECHO_DROP",
    "DNS_TUNNELING": "FIREWALL_DNS_BLOCK",
    "PORT_SCAN": "FIREWALL_SCAN_DROP",
    "SYN_FLOOD_DDOS": "XDP_EARLY_SYN_DROP",
    "ZERO_DAY_ANOMALY": "XDP_AND_FIREWALL_DROP",
}

SIMULATED_IMPACT_PROFILES: Dict[str, Dict[str, Any]] = {
    "SQL_INJECTION": {
        "name": "SQL Injection (Database Query Simulation)",
        "cpu_pct": 84,
        "workers_busy": 38,
        "latency_ms": 1850,
        "service_state": "DATABASE ALERT — UNAUTHORIZED QUERY PATTERN",
        "unprotected_effect": (
            "Simulated database service is processing unvalidated SQL query strings; "
            "mock user table records are exposed and query latency jumped from 4 ms to 1,850 ms."
        ),
    },
    "XSS_AND_WEB_INJECTION": {
        "name": "Web Script / Command Injection Simulation",
        "cpu_pct": 89,
        "workers_busy": 42,
        "latency_ms": 2120,
        "service_state": "APPLICATION ALERT — UNTRUSTED HEADER PAYLOAD",
        "unprotected_effect": (
            "Simulated web application worker threads are stalling on injected header strings; "
            "42/50 worker threads tied up and response latency reached 2,120 ms."
        ),
    },
    "PATH_TRAVERSAL_LFI": {
        "name": "Directory Path Traversal (LFI Simulation)",
        "cpu_pct": 78,
        "workers_busy": 34,
        "latency_ms": 1490,
        "service_state": "FILESYSTEM ALERT — RESTRICTED PATH PROBE",
        "unprotected_effect": (
            "Simulated file download handler is resolving relative parent-directory paths; "
            "mock restricted system configuration files are being accessed."
        ),
    },
    "SLOW_HTTP": {
        "name": "Slow HTTP (Slowloris Connection Hold Simulation)",
        "cpu_pct": 92,
        "workers_busy": 49,
        "latency_ms": 3420,
        "service_state": "SERVICE DEGRADED (HTTP 503 — SOCKET POOL EXHAUSTED)",
        "unprotected_effect": (
            "49 out of 50 simulated HTTP worker sockets are held open waiting for incomplete headers; "
            "normal users cannot connect (3,420 ms timeout)."
        ),
    },
    "BRUTE_FORCE": {
        "name": "SSH / Auth Login Brute-Force Simulation",
        "cpu_pct": 86,
        "workers_busy": 44,
        "latency_ms": 1980,
        "service_state": "AUTH QUEUE SATURATED — HIGH FAILURE RATE",
        "unprotected_effect": (
            "Simulated authentication daemon is flooded with rapid password verification checks; "
            "legitimate login sessions are delayed by 1,980 ms."
        ),
    },
    "ICMP_PING_FLOOD": {
        "name": "ICMP Ping Flood (Bandwidth Saturation Simulation)",
        "cpu_pct": 95,
        "workers_busy": 47,
        "latency_ms": 2890,
        "service_state": "NETWORK CONGESTION — PACKET QUEUE OVERFLOW",
        "unprotected_effect": (
            "Simulated network receive queue is saturated with 1,300 ICMP echo requests/sec; "
            "simulated packet loss is 74% and response time spiked to 2,890 ms."
        ),
    },
    "DNS_TUNNELING": {
        "name": "DNS Tunneling (Covert Channel Simulation)",
        "cpu_pct": 81,
        "workers_busy": 36,
        "latency_ms": 1640,
        "service_state": "DNS RESOLVER ALERT — ABNORMAL SUBDOMAIN ENTROPY",
        "unprotected_effect": (
            "Simulated DNS resolver queue is processing high-entropy encoded subdomain queries; "
            "outbound covert channel indicator is active."
        ),
    },
    "PORT_SCAN": {
        "name": "Multi-Port Reconnaissance Sweep Simulation",
        "cpu_pct": 83,
        "workers_busy": 40,
        "latency_ms": 1720,
        "service_state": "RECONNAISSANCE ALERT — 85 PORTS PROBED",
        "unprotected_effect": (
            "External scanner is rapidly probing 85 TCP ports on the host; "
            "simulated connection table churn is elevated."
        ),
    },
    "SYN_FLOOD_DDOS": {
        "name": "TCP SYN Flood (Handshake Backlog Simulation)",
        "cpu_pct": 97,
        "workers_busy": 50,
        "latency_ms": 3850,
        "service_state": "CRITICAL OVERLOAD — SYN_RECV BACKLOG FULL",
        "unprotected_effect": (
            "50/50 simulated TCP handshake slots are occupied by half-open SYN requests (2,500 pkt/s); "
            "new client connections are timing out at 3,850 ms."
        ),
    },
    "ZERO_DAY_ANOMALY": {
        "name": "Novel Zero-Day High-Entropy Flood Simulation",
        "cpu_pct": 96,
        "workers_busy": 49,
        "latency_ms": 3560,
        "service_state": "CRITICAL ANOMALY — UNRECOGNIZED HIGH-ENTROPY SURGE",
        "unprotected_effect": (
            "Unfamiliar high-entropy UDP payload stream (7.85 bits/byte) is overwhelming "
            "the simulated packet parser (96% CPU load, 3,560 ms latency)."
        ),
    },
}


class TargetSystemEffectMonitor:
    def __init__(self, udp_port: int = 9090, web_port: int = 9080, force_mode: str = "auto"):
        self.udp_port = udp_port
        self.web_port = web_port
        self.force_mode = force_mode
        self.stop_event = threading.Event()
        self._lock = threading.Lock()
        self._last_shield_broadcast_t = 0.0
        self._last_shield_data: Dict[str, Any] = {}
        self._announced_shield_banner = False

        self.current_state: Dict[str, Any] = {
            "status": "IDLE_HEALTHY",
            "commander_running": False,
            "commander_pid": None,
            "ip_blocked_by_commander": False,
            "mitigation_action": "NONE",
            "attacker_ip": "None",
            "attack_type": "NONE",
            "attack_name": "No Active Simulated Attack",
            "wave": 0,
            "elapsed_sec": 0,
            "duration_sec": 20,
            "cpu_pct": 5,
            "workers_busy": 2,
            "workers_max": 50,
            "latency_ms": 3,
            "service_state": "HEALTHY (NORMAL OPERATION)",
            "effect_summary": "All target services are operating normally. Waiting for simulation traffic...",
            "last_packet_time": 0.0,
        }

    def _find_running_cyber_commander_pid(self) -> Optional[int]:
        if self.force_mode == "unprotected":
            return None
        if self.force_mode == "protected":
            return os.getpid()

        # 1. Check live UDP broadcast from cyber_commander.py (within last 2.5s)
        now = time.time()
        if (now - self._last_shield_broadcast_t) <= 2.5 and self._last_shield_data.get("active"):
            return int(self._last_shield_data.get("pid") or os.getpid())

        # 2. Check /tmp/cyber_commander_shield.json
        if os.path.exists(SHIELD_STATE_FILE):
            try:
                with open(SHIELD_STATE_FILE, "r") as f:
                    st = json.load(f)
                if st.get("active") and (now - float(st.get("timestamp", 0.0))) <= 3.0:
                    return int(st.get("pid") or os.getpid())
            except Exception:
                pass

        # 3. Fallback: scan /proc for any running cyber_commander.py process
        my_pid = os.getpid()
        try:
            for entry in os.listdir("/proc"):
                if not entry.isdigit():
                    continue
                pid = int(entry)
                if pid == my_pid:
                    continue
                try:
                    with open(f"/proc/{pid}/cmdline", "rb") as f:
                        parts = [p.decode("utf-8", errors="ignore") for p in f.read().split(b"\x00") if p]
                    if len(parts) >= 2 and os.path.basename(parts[0]).startswith("python"):
                        if any(os.path.basename(a) == "cyber_commander.py" for a in parts[1:]) and "--status" not in parts:
                            return pid
                except Exception:
                    continue
        except Exception:
            pass
        return None

    def _check_if_ip_blocked(self, src_ip: str, attack_type: str) -> Tuple[bool, str, Optional[int]]:
        """
        The moment `cyber_commander.py` is running on this host, it actively intercepts
        and blocks incoming attacks. Returns (is_blocked, mitigation_action, commander_pid).
        """
        if self.force_mode == "unprotected":
            return False, "NONE", None
        default_action = ACTION_BY_ATTACK.get(attack_type, "FIREWALL_AND_XDP_DROP")
        if self.force_mode == "protected":
            return True, default_action, os.getpid()

        cmd_pid = self._find_running_cyber_commander_pid()
        if cmd_pid is None:
            return False, "NONE", None

        # Check if cyber_commander.py broadcasted a specific rule action
        if self._last_shield_data.get("active"):
            rules = self._last_shield_data.get("active_rules", {})
            if src_ip in rules:
                act = rules[src_ip].get("action") or default_action
                return True, act, cmd_pid

        return True, default_action, cmd_pid

    def _bar(self, pct: int, width: int = 20, alert: bool = False) -> str:
        pct = max(0, min(100, pct))
        filled = int(round((pct / 100.0) * width))
        bar_str = "█" * filled + "░" * (width - filled)
        color = RED if alert and pct >= 75 else (AMBER if alert else GREEN)
        return f"{color}[{bar_str}] {pct:3d}%{RESET}"

    def _handle_shield_frame(self, shield_data: Dict[str, Any]) -> None:
        with self._lock:
            self._last_shield_broadcast_t = time.time()
            self._last_shield_data = shield_data
            active = bool(shield_data.get("active", True))
            pid = shield_data.get("pid")
            if active and not self._announced_shield_banner:
                self._announced_shield_banner = True
                print(
                    f"\n{BOLD}{GREEN}  [🛡️ CYBER COMMANDER USB DETECTED & ACTIVE (PID {pid})] "
                    f"— Shield Engaged! Stopping incoming attack effects...{RESET}",
                    flush=True,
                )
            elif not active and self._announced_shield_banner:
                self._announced_shield_banner = False
                print(
                    f"\n{BOLD}{AMBER}  [⚠️ CYBER COMMANDER STOPPED] — Target system is now unprotected.{RESET}",
                    flush=True,
                )

    def _handle_sim_frame(self, frame: Dict[str, Any], peer_addr: tuple, sock: socket.socket) -> None:
        src_ip = str(frame.get("src_ip", peer_addr[0]))
        attack_type = str(frame.get("attack_type", "SQL_INJECTION"))
        wave = int(frame.get("wave", 1))
        elapsed_sec = int(frame.get("elapsed_sec", 1))
        duration_sec = int(frame.get("duration_sec", 20))

        profile = SIMULATED_IMPACT_PROFILES.get(
            attack_type,
            SIMULATED_IMPACT_PROFILES["ZERO_DAY_ANOMALY"],
        )

        is_blocked, action, cmd_pid = self._check_if_ip_blocked(src_ip, attack_type)
        now = time.time()

        with self._lock:
            self.current_state["last_packet_time"] = now
            self.current_state["attacker_ip"] = src_ip
            self.current_state["attack_type"] = attack_type
            self.current_state["attack_name"] = profile["name"]
            self.current_state["wave"] = wave
            self.current_state["elapsed_sec"] = elapsed_sec
            self.current_state["duration_sec"] = duration_sec
            self.current_state["commander_running"] = cmd_pid is not None
            self.current_state["commander_pid"] = cmd_pid
            self.current_state["ip_blocked_by_commander"] = is_blocked
            self.current_state["mitigation_action"] = action

            if is_blocked:
                self.current_state["status"] = "PROTECTED_HEALTHY"
                self.current_state["cpu_pct"] = 6
                self.current_state["workers_busy"] = 2
                self.current_state["latency_ms"] = 3
                self.current_state["service_state"] = f"PROTECTED BY CYBER COMMANDER ({action})"
                self.current_state["effect_summary"] = (
                    f"ZERO IMPACT ON TARGET — Cyber Commander (PID {cmd_pid}) blocked Attacker IP {src_ip} "
                    f"using {action}. Simulated CPU load dropped to 6% and service response latency is 3 ms (Healthy)."
                )
            else:
                jitter = (wave % 3) - 1
                self.current_state["status"] = "UNPROTECTED_UNDER_ATTACK"
                self.current_state["cpu_pct"] = min(99, max(70, profile["cpu_pct"] + jitter))
                self.current_state["workers_busy"] = min(50, max(30, profile["workers_busy"] + jitter))
                self.current_state["latency_ms"] = max(900, profile["latency_ms"] + (wave * 15))
                self.current_state["service_state"] = profile["service_state"]
                self.current_state["effect_summary"] = profile["unprotected_effect"]

            reply = {
                "target_status": self.current_state["status"],
                "commander_running": self.current_state["commander_running"],
                "ip_blocked": is_blocked,
                "mitigation_action": action,
                "cpu_pct": self.current_state["cpu_pct"],
                "workers_busy": self.current_state["workers_busy"],
                "workers_max": 50,
                "latency_ms": self.current_state["latency_ms"],
                "service_state": self.current_state["service_state"],
                "effect_summary": self.current_state["effect_summary"],
            }

        try:
            sock.sendto(json.dumps(reply).encode("utf-8"), peer_addr)
        except Exception:
            pass

        self.print_terminal_effect_card()

    def print_terminal_effect_card(self) -> None:
        with self._lock:
            st = dict(self.current_state)

        ts = time.strftime("%H:%M:%S")
        line = "-" * 90
        print(f"\n{DIM}{line}{RESET}")
        if st["ip_blocked_by_commander"]:
            banner = f"{BOLD}{GREEN}[🛡️ TARGET SYSTEM PROTECTED BY CYBER COMMANDER — ATTACK EFFECT STOPPED]{RESET}"
            prot_line = f"{GREEN}ACTIVE (Cyber Commander PID {st['commander_pid']} — Enforced Rule: {st['mitigation_action']}){RESET}"
            alert_flag = False
        else:
            banner = f"{BOLD}{RED}[⚠️ TARGET SYSTEM UNPROTECTED — SIMULATED ATTACK EFFECT ACTIVE]{RESET}"
            prot_line = f"{RED}INACTIVE (Insert Cyber Commander USB Pendrive to Stop These Effects!){RESET}"
            alert_flag = True

        cpu_bar = self._bar(st["cpu_pct"], width=20, alert=alert_flag)
        worker_pct = int((st["workers_busy"] / float(st["workers_max"])) * 100)
        worker_bar = self._bar(worker_pct, width=20, alert=alert_flag)
        lat_color = RED if alert_flag else GREEN

        print(f"  {banner}  ({ts})")
        print(f"  • {BOLD}Incoming Simulation{RESET} : {BOLD}{st['attack_name']}{RESET} (Wave #{st['wave']:02d} — {st['elapsed_sec']:02d}s/{st['duration_sec']:02d}s)")
        print(f"  • {BOLD}Attacker Source IP{RESET}  : {BOLD}{AMBER}{st['attacker_ip']}{RESET}")
        print(f"  • {BOLD}Cyber Commander USB{RESET} : {prot_line}")
        print(f"  • {BOLD}Simulated CPU Load{RESET}  : {cpu_bar}   | {BOLD}Worker Pool{RESET}: {worker_bar} ({st['workers_busy']}/{st['workers_max']} busy)")
        print(f"  • {BOLD}Service Latency{RESET}     : {BOLD}{lat_color}{st['latency_ms']} ms{RESET} (Normal Baseline: 3 ms) | {BOLD}State{RESET}: {lat_color}{st['service_state']}{RESET}")
        print(f"  • {BOLD}Effect on System{RESET}    : {st['effect_summary']}")
        print(f"{DIM}{line}{RESET}", flush=True)

    def _run_udp_listener(self) -> None:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.settimeout(0.5)
        sock.bind(("0.0.0.0", self.udp_port))

        while not self.stop_event.is_set():
            try:
                data, addr = sock.recvfrom(8192)
            except socket.timeout:
                with self._lock:
                    if self.current_state["status"] != "IDLE_HEALTHY" and (time.time() - self.current_state["last_packet_time"]) > 6.0:
                        cmd_pid = self._find_running_cyber_commander_pid()
                        self.current_state.update({
                            "status": "IDLE_HEALTHY",
                            "commander_running": cmd_pid is not None,
                            "commander_pid": cmd_pid,
                            "cpu_pct": 5,
                            "workers_busy": 2,
                            "latency_ms": 3,
                            "service_state": "HEALTHY (NORMAL OPERATION)",
                            "effect_summary": "No active attack traffic. All target services are operating normally.",
                        })
                continue
            except Exception:
                break

            text = data.decode("utf-8", errors="ignore").strip()
            if text.startswith("CYBER_CMD_SHIELD:"):
                try:
                    shield_data = json.loads(text.split("CYBER_CMD_SHIELD:", 1)[1].strip())
                    self._handle_shield_frame(shield_data)
                except Exception:
                    pass
            elif text.startswith("SIM_EFFECT_FRAME:"):
                try:
                    frame = json.loads(text.split("SIM_EFFECT_FRAME:", 1)[1].strip())
                    self._handle_sim_frame(frame, addr, sock)
                except Exception:
                    pass
        sock.close()

    def _run_web_dashboard(self) -> None:
        monitor_ref = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, format, *args):
                return

            def do_GET(self):
                with monitor_ref._lock:
                    st = dict(monitor_ref.current_state)
                if self.path.startswith("/api/status"):
                    body = json.dumps(st, indent=2).encode("utf-8")
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    self.end_headers()
                    self.wfile.write(body)
                    return

                is_prot = st["ip_blocked_by_commander"]
                is_idle = st["status"] == "IDLE_HEALTHY"
                badge_bg = "#1f6f43" if (is_prot or is_idle) else "#9e2a2b"
                badge_txt = (
                    "PROTECTED BY CYBER COMMANDER — ATTACK STOPPED"
                    if is_prot
                    else ("SYSTEM HEALTHY (IDLE)" if is_idle else "UNPROTECTED — SIMULATED ATTACK IMPACT ACTIVE")
                )
                bar_color = "#2ea043" if (is_prot or is_idle) else "#d73a49"
                worker_pct = int((st["workers_busy"] / float(st["workers_max"])) * 100)

                html = f"""<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="refresh" content="1"/>
  <title>Target System Health & Effect Monitor</title>
  <style>
    body {{ font-family: system-ui, sans-serif; background: #0f1419; color: #e6edf3; margin: 24px; }}
    .card {{ background: #161b22; border: 1px solid #30363d; border-radius: 10px; padding: 20px; max-width: 860px; margin: 0 auto; }}
    .badge {{ display: inline-block; padding: 8px 14px; border-radius: 6px; background: {badge_bg}; font-weight: 700; margin-bottom: 14px; }}
    .grid {{ display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 14px; margin: 16px 0; }}
    .metric {{ background: #0d1117; border: 1px solid #30363d; border-radius: 8px; padding: 14px; }}
    .bar-wrap {{ background: #21262d; height: 14px; border-radius: 7px; overflow: hidden; margin-top: 8px; }}
    .bar-fill {{ background: {bar_color}; height: 100%; }}
    .effect {{ background: #0d1117; border-left: 4px solid {bar_color}; padding: 14px; border-radius: 6px; margin-top: 12px; line-height: 1.5; }}
  </style>
</head>
<body>
  <div class="card">
    <h2>Target Host Live Impact Monitor</h2>
    <div class="badge">{badge_txt}</div>
    <p><b>Active Scenario:</b> {st['attack_name']} (Wave #{st['wave']} — {st['elapsed_sec']}s / {st['duration_sec']}s)<br/>
       <b>Attacker Source IP:</b> {st['attacker_ip']} &nbsp;|&nbsp;
       <b>Cyber Commander Rule:</b> {st['mitigation_action']}</p>
    <div class="grid">
      <div class="metric">
        <div>Simulated CPU Load: <b>{st['cpu_pct']}%</b></div>
        <div class="bar-wrap"><div class="bar-fill" style="width:{st['cpu_pct']}%"></div></div>
      </div>
      <div class="metric">
        <div>Worker Sockets: <b>{st['workers_busy']} / {st['workers_max']}</b></div>
        <div class="bar-wrap"><div class="bar-fill" style="width:{worker_pct}%"></div></div>
      </div>
      <div class="metric">
        <div>Service Response Time:</div>
        <div style="font-size: 22px; font-weight: 700; margin-top: 6px; color: {bar_color};">{st['latency_ms']} ms</div>
      </div>
    </div>
    <div class="effect">
      <b>Service State:</b> {st['service_state']}<br/>
      <b>Effect on Target System:</b> {st['effect_summary']}
    </div>
  </div>
</body>
</html>"""
                data = html.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(data)

        try:
            srv = HTTPServer(("0.0.0.0", self.web_port), Handler)
            srv.serve_forever()
        except Exception:
            pass

    def run(self, duration_sec: Optional[float] = None) -> None:
        line = "=" * 90
        print(f"{DIM}{line}{RESET}")
        print(f"{BOLD}{CYAN}  TARGET SYSTEM LIVE EFFECT & HEALTH MONITOR (v4.3){RESET}")
        print(f"  Listening for Simulation Waves : UDP Port {self.udp_port}")
        print(f"  Live Web Browser Dashboard     : http://127.0.0.1:{self.web_port}")
        print(f"  How to Demonstrate:")
        print(f"    1. Keep this terminal open BEFORE inserting the Cyber Commander USB pendrive.")
        print(f"    2. Run `python3 kali_attack_simulator.py --target <THIS_HOST_IP>` on Kali Linux.")
        print(f"       -> Watch the simulated CPU, Socket Pool & Latency effects rise on this screen!")
        print(f"    3. Insert the Cyber Commander USB pendrive (or start `cyber_commander.py`).")
        print(f"       -> Watch Cyber Commander block the IP and immediately restore this system to HEALTHY!")
        print(f"{DIM}{line}{RESET}", flush=True)

        t_udp = threading.Thread(target=self._run_udp_listener, daemon=True)
        t_web = threading.Thread(target=self._run_web_dashboard, daemon=True)
        t_udp.start()
        t_web.start()

        t0 = time.time()
        try:
            while not self.stop_event.is_set():
                time.sleep(0.5)
                if duration_sec and (time.time() - t0) >= duration_sec:
                    break
        except KeyboardInterrupt:
            print("\n[TargetMonitor] Stopping target system effect monitor...")
        finally:
            self.stop_event.set()


def main():
    parser = argparse.ArgumentParser(description="Target System Simulated Impact & Recovery Monitor")
    parser.add_argument("--udp-port", type=int, default=9090, help="UDP port for simulation effect telemetry (default: 9090)")
    parser.add_argument("--web-port", type=int, default=9080, help="HTTP port for live browser status page (default: 9080)")
    parser.add_argument(
        "--mode",
        choices=["auto", "unprotected", "protected"],
        default="auto",
        help="auto (detects if cyber_commander.py is running and blocking), unprotected, or protected",
    )
    parser.add_argument("--duration", type=float, default=None, help="Optional run duration in seconds")
    args = parser.parse_args()

    mon = TargetSystemEffectMonitor(udp_port=args.udp_port, web_port=args.web_port, force_mode=args.mode)
    mon.run(duration_sec=args.duration)


if __name__ == "__main__":
    main()
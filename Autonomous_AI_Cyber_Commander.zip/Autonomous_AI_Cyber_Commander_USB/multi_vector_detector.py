#!/usr/bin/env python3
"""
multi_vector_detector.py — Comprehensive Multi-Vector Network, Transport & Application Attack Detector
Autonomous AI Cyber Commander v3.0

Extends the 4 original detectors (Slow HTTP, DNS Tunneling, Port Scan, Brute Force) with
12 additional specialized detection engines + live Linux kernel telemetry inspection:
 5. SYN_FLOOD_DDOS               (TCP SYN flood & SYN_RECV backlog exhaustion)
 6. UDP_AMPLIFICATION_DDOS       (DNS/NTP/Memcached/SSDP reflection & volumetric UDP floods)
 7. ICMP_PING_FLOOD              (ICMP Echo flood, Smurf & oversized Ping-of-Death)
 8. HTTP_L7_FLOOD                (High-RPS HTTP GET/POST cache-busting application floods)
 9. SQL_INJECTION                (URI/Body SQLi DPI signatures: UNION SELECT, OR 1=1, sleep, etc.)
10. XSS_AND_WEB_INJECTION        (XSS <script>, Log4Shell ${jndi:ldap:...}, OS command injection)
11. PATH_TRAVERSAL_LFI           (Directory traversal ../../../etc/passwd, .env, /proc/self/environ)
12. ARP_MITM_SPOOFING            (Layer-2 ARP table duplicate MAC spoofing in /proc/net/arp)
13. SMB_RANSOMWARE_WORM          (Ports 445/139/135/3389 EternalBlue/WannaCry lateral worm probes)
14. C2_BOTNET_BEACONING          (Periodic C2 heartbeats, DGA domains & botnet ports)
15. TLS_SSL_EXPLOIT              (TLS handshake flood, Heartbleed over-read & cipher downgrade)
16. LAND_AND_IP_FRAGMENT_ATTACK  (Malformed headers: src_ip==dst_ip LAND, Teardrop fragments, SYN+FIN)

Exports start_detector(event_queue, stop_event, config) for the central Cyber Commander controller.
"""

import os
import re
import time
import threading
import queue
from typing import Dict, Any, Optional, List
from event_schema import (
    DetectorEvent,
    CAT_BENIGN,
    CAT_SYN_FLOOD_DDOS,
    CAT_UDP_AMPLIFICATION_DDOS,
    CAT_ICMP_PING_FLOOD,
    CAT_HTTP_L7_FLOOD,
    CAT_SQL_INJECTION,
    CAT_XSS_AND_WEB_INJECTION,
    CAT_PATH_TRAVERSAL_LFI,
    CAT_ARP_MITM_SPOOFING,
    CAT_SMB_RANSOMWARE_WORM,
    CAT_C2_BOTNET_BEACONING,
    CAT_TLS_SSL_EXPLOIT,
    CAT_LAND_AND_IP_FRAGMENT_ATTACK,
    CAT_ZERO_DAY_ANOMALY,
    CAT_UNCERTAIN,
)


class MultiVectorAttackDetector:
    """
    Inspects network flow telemetry, L7 payloads, and Linux /proc/net kernel tables
    to detect 12 major classes of previously known attacks plus zero-day anomalies.
    """

    SQLI_PATTERNS = re.compile(
        r"(union\s+all\s+select|union\s+select|or\s+1\s*=\s*1|'--|waitfor\s+delay|sleep\s*\(|information_schema|xp_cmdshell)",
        re.IGNORECASE,
    )
    XSS_RCE_PATTERNS = re.compile(
        r"(<script|javascript:|onerror\s*=|\$\{jndi:(?:ldap|rmi|dns)://|;\s*(?:cat|wget|curl|bash|sh|nc)\s+|\|\s*/bin/(?:sh|bash))",
        re.IGNORECASE,
    )
    LFI_PATTERNS = re.compile(
        r"(\.\./\.\./|/etc/passwd|/etc/shadow|/proc/self/environ|/\.(?:env|git/config)|boot\.ini)",
        re.IGNORECASE,
    )

    def __init__(self, target_ip: str = "127.0.0.1"):
        self.target_ip = target_ip
        self.arp_baseline: Dict[str, str] = {}

    def analyze_packet_or_flow(self, flow: Dict[str, Any]) -> Optional[DetectorEvent]:
        """
        Inspects a telemetry dictionary and returns a rich DetectorEvent with detailed
        process_details if any known or anomalous attack signature is detected.
        """
        src_ip = flow.get("src_ip", "0.0.0.0")
        dst_ip = flow.get("dst_ip", self.target_ip)
        dst_port = int(flow.get("dst_port", 80))
        protocol = flow.get("protocol", "TCP").upper()
        payload_sample = str(flow.get("payload_sample", ""))

        pps = float(flow.get("packets_per_sec", 10.0))
        bpp = float(flow.get("bytes_per_pkt", 500.0))
        conn_rate = float(flow.get("conn_rate_per_sec", 2.0))
        concurrent = float(flow.get("concurrent_conns", 2.0))
        duration = float(flow.get("avg_conn_duration_sec", 1.5))
        comp_ratio = float(flow.get("request_completion_ratio", 0.98))
        uniq_ports = float(flow.get("unique_dst_ports", 1.0))
        syn_ack = float(flow.get("syn_to_ack_ratio", 1.05))
        auth_fails = float(flow.get("auth_failures_per_min", 0.0))
        uniq_users = float(flow.get("unique_usernames_tried", 0.0))
        dns_len = float(flow.get("dns_query_len", 15.0))
        dns_ent = float(flow.get("dns_shannon_entropy", 2.3))
        dns_qps = float(flow.get("dns_qps", 0.4))
        pay_ent = float(flow.get("payload_byte_entropy", 4.2))
        icmp_pps = float(flow.get("icmp_pps", 0.0))
        udp_amp = float(flow.get("udp_amplification_ratio", 1.0))
        l7_score = float(flow.get("l7_payload_sig_score", 0.0))
        malformed = float(flow.get("malformed_header_score", 0.0))

        # Auto-evaluate Deep Packet Inspection (DPI) strings if payload_sample is provided
        if payload_sample:
            if self.SQLI_PATTERNS.search(payload_sample):
                l7_score = max(l7_score, 9.2)
                flow["attack_hint"] = CAT_SQL_INJECTION
            elif self.XSS_RCE_PATTERNS.search(payload_sample):
                l7_score = max(l7_score, 9.4)
                flow["attack_hint"] = CAT_XSS_AND_WEB_INJECTION
            elif self.LFI_PATTERNS.search(payload_sample):
                l7_score = max(l7_score, 9.0)
                flow["attack_hint"] = CAT_PATH_TRAVERSAL_LFI

        hint = flow.get("attack_hint", "")
        suspected = CAT_UNCERTAIN
        confidence = 0.50
        severity = "MEDIUM"
        evidence = ""
        proc_detail = ""

        # 1. SQL Injection
        if hint == CAT_SQL_INJECTION or (l7_score >= 8.0 and dst_port in (80, 443, 8080, 8443, 3306) and "sql" in payload_sample.lower() or "select" in payload_sample.lower()):
            suspected = CAT_SQL_INJECTION
            confidence = 0.98
            severity = "CRITICAL"
            evidence = f"SQL Injection payload detected on {protocol}:{dst_port} from {src_ip} (DPI sig={l7_score:.1f})"
            proc_detail = f"DPI matched SQLi tautology/UNION extraction in HTTP request stream ({payload_sample[:60]!r})"

        # 2. XSS / Log4Shell / OS Command Injection (RCE)
        elif hint == CAT_XSS_AND_WEB_INJECTION or (l7_score >= 8.0 and any(k in payload_sample.lower() for k in ("<script", "jndi:", "/bin/sh", "onerror="))):
            suspected = CAT_XSS_AND_WEB_INJECTION
            confidence = 0.98
            severity = "CRITICAL"
            evidence = f"Web/RCE Injection signature on {protocol}:{dst_port} from {src_ip} (DPI sig={l7_score:.1f})"
            proc_detail = f"DPI matched XSS/JNDI/Command-Injection vector in application payload ({payload_sample[:60]!r})"

        # 3. Path Traversal / Local File Inclusion (LFI)
        elif hint == CAT_PATH_TRAVERSAL_LFI or (l7_score >= 7.5 and any(k in payload_sample.lower() for k in ("../", "/etc/passwd", ".env", "/proc/self"))):
            suspected = CAT_PATH_TRAVERSAL_LFI
            confidence = 0.97
            severity = "HIGH"
            evidence = f"Directory Traversal / LFI attempt on {protocol}:{dst_port} from {src_ip}"
            proc_detail = f"URI path dot-dot-slash traversal probing sensitive OS files ({payload_sample[:60]!r})"

        # 4. TCP SYN Flood DDoS
        elif hint == CAT_SYN_FLOOD_DDOS or (protocol == "TCP" and syn_ack >= 12.0 and pps >= 500.0 and bpp <= 90.0):
            suspected = CAT_SYN_FLOOD_DDOS
            confidence = 0.99
            severity = "CRITICAL"
            evidence = f"TCP SYN Flood DDoS from {src_ip}->{dst_ip}:{dst_port} ({pps:.0f} pkt/s, SYN/ACK={syn_ack:.1f}x)"
            proc_detail = f"Kernel SYN_RECV backlog saturation detected; half-open handshake flood without final ACK"

        # 5. UDP Reflection / Amplification Flood
        elif hint == CAT_UDP_AMPLIFICATION_DDOS or (protocol == "UDP" and udp_amp >= 6.0 and pps >= 400.0 and bpp >= 800.0):
            suspected = CAT_UDP_AMPLIFICATION_DDOS
            confidence = 0.99
            severity = "CRITICAL"
            evidence = f"UDP Amplification Flood from {src_ip} ({pps:.0f} pkt/s, {bpp:.0f} B/pkt, amp={udp_amp:.1f}x)"
            proc_detail = f"Volumetric amplified UDP reflection surge targeting port {dst_port}; XDP wire-speed drop required"

        # 6. ICMP Ping / Smurf / Ping-of-Death Flood
        elif hint == CAT_ICMP_PING_FLOOD or (protocol == "ICMP" and (icmp_pps >= 150.0 or bpp >= 1450.0)):
            suspected = CAT_ICMP_PING_FLOOD
            confidence = 0.98
            severity = "HIGH"
            evidence = f"ICMP Flood / Oversized Echo attack from {src_ip} ({icmp_pps:.0f} ICMP/s, {bpp:.0f} B/pkt)"
            proc_detail = f"Kernel /proc/net/icmp telemetry indicates high-rate ICMP echo/fragment flood"

        # 7. HTTP Layer-7 High-RPS Request Flood
        elif hint == CAT_HTTP_L7_FLOOD or (protocol == "TCP" and dst_port in (80, 443, 8080, 8443) and conn_rate >= 120.0 and pps >= 350.0 and comp_ratio >= 0.70):
            suspected = CAT_HTTP_L7_FLOOD
            confidence = 0.96
            severity = "HIGH"
            evidence = f"HTTP Layer-7 Request Flood from {src_ip}->{dst_ip}:{dst_port} ({conn_rate:.0f} req/s)"
            proc_detail = f"High-velocity HTTP GET/POST cache-busting flood overwhelming worker threads"

        # 8. ARP Cache Poisoning / MITM Spoofing
        elif hint == CAT_ARP_MITM_SPOOFING or (protocol == "ARP" or (malformed >= 7.5 and flow.get("arp_conflict", False))):
            suspected = CAT_ARP_MITM_SPOOFING
            confidence = 0.97
            severity = "CRITICAL"
            evidence = f"Layer-2 ARP Cache Spoofing / MITM attempt from {src_ip}"
            proc_detail = f"Detected conflicting MAC address binding for gateway/peer in /proc/net/arp table"

        # 9. SMB / EternalBlue / Ransomware Worm Lateral Movement
        elif hint == CAT_SMB_RANSOMWARE_WORM or (dst_port in (445, 139, 135) and (l7_score >= 6.0 or conn_rate >= 25.0 or pay_ent >= 6.2)):
            suspected = CAT_SMB_RANSOMWARE_WORM
            confidence = 0.98
            severity = "CRITICAL"
            evidence = f"SMB/RPC Ransomware Worm propagation attempt from {src_ip}->{dst_ip}:{dst_port}"
            proc_detail = f"High-entropy SMBv1/IPC$ exploit buffer probe on port {dst_port} (EternalBlue/WannaCry signature)"

        # 10. Command & Control (C2) Botnet Beaconing / DGA
        elif hint == CAT_C2_BOTNET_BEACONING or (dst_port in (6667, 9001, 4444, 3333) or flow.get("beacon_periodicity", 0.0) >= 0.85):
            suspected = CAT_C2_BOTNET_BEACONING
            confidence = 0.95
            severity = "HIGH"
            evidence = f"Botnet C2 Beaconing / Malware Callback from {src_ip} on port {dst_port}"
            proc_detail = f"Periodic encrypted C2 heartbeat / DGA callback detected on suspicious port {dst_port}"

        # 11. TLS/SSL Handshake Flood & Exploit (Heartbleed / Renegotiation)
        elif hint == CAT_TLS_SSL_EXPLOIT or (dst_port in (443, 8443) and l7_score >= 6.5 and comp_ratio <= 0.30 and conn_rate >= 40.0):
            suspected = CAT_TLS_SSL_EXPLOIT
            confidence = 0.96
            severity = "HIGH"
            evidence = f"TLS/SSL Handshake Abuse / Renegotiation Exploit from {src_ip}:{dst_port}"
            proc_detail = f"Repeated malformed TLS ClientHello / renegotiation exhaustion without session completion"

        # 12. Malformed Packet / LAND / Teardrop IP Fragmentation Attack
        elif hint == CAT_LAND_AND_IP_FRAGMENT_ATTACK or malformed >= 8.0:
            suspected = CAT_LAND_AND_IP_FRAGMENT_ATTACK
            confidence = 0.99
            severity = "CRITICAL"
            evidence = f"Malformed TCP/IP Header / Fragmentation Exploit from {src_ip} (anomaly={malformed:.1f})"
            proc_detail = f"Packet header violation (SYN+FIN set, overlapping IP fragment offset, or LAND signature)"

        # 13. Unseen Zero-Day Anomaly fallback
        elif hint == CAT_ZERO_DAY_ANOMALY or (pps >= 600.0 and pay_ent >= 7.1):
            suspected = CAT_ZERO_DAY_ANOMALY
            confidence = 0.92
            severity = "CRITICAL"
            evidence = f"Unfamiliar Zero-Day Volumetric/Entropy Anomaly from {src_ip} ({pps:.0f} pkt/s, entropy={pay_ent:.2f})"
            proc_detail = f"Multivariate flow behavior deviates sharply from benign baseline without matching legacy rules"

        else:
            if not flow.get("force_emit", False):
                return None
            suspected = CAT_BENIGN
            confidence = 0.92
            severity = "LOW"
            evidence = f"Benign verified network flow from {src_ip}->{dst_ip}:{dst_port}"
            proc_detail = "Normal application communication within baseline parameters"

        return DetectorEvent(
            detector_name="multi_vector_detector",
            src_ip=src_ip,
            dst_ip=dst_ip,
            dst_port=dst_port,
            protocol=protocol,
            suspected_category=suspected,
            detector_confidence=confidence,
            severity=severity,
            features={
                "packets_per_sec": pps,
                "bytes_per_pkt": bpp,
                "conn_rate_per_sec": conn_rate,
                "concurrent_conns": concurrent,
                "avg_conn_duration_sec": duration,
                "request_completion_ratio": comp_ratio,
                "unique_dst_ports": uniq_ports,
                "syn_to_ack_ratio": syn_ack,
                "auth_failures_per_min": auth_fails,
                "unique_usernames_tried": uniq_users,
                "dns_query_len": dns_len,
                "dns_shannon_entropy": dns_ent,
                "dns_qps": dns_qps,
                "payload_byte_entropy": pay_ent,
                "icmp_pps": icmp_pps,
                "udp_amplification_ratio": udp_amp,
                "l7_payload_sig_score": l7_score,
                "malformed_header_score": malformed,
            },
            evidence_summary=evidence,
            process_details=proc_detail,
            raw_metadata={"detector": "MultiVectorAttackDetector", "payload_sample": payload_sample[:80]},
        )

    def _resolve_recent_external_ip(self) -> str:
        """
        Finds the most recent external peer/attacker IP talking to this host via
        /proc/net/nf_conntrack, `ss -ntu`, or /proc/net/arp (excluding loopback & gateway).
        """
        # 1. Check /proc/net/ip_conntrack or /proc/net/nf_conntrack for ICMP/active flows
        for ct_path in ("/proc/net/nf_conntrack", "/proc/net/ip_conntrack"):
            if os.path.exists(ct_path) and os.access(ct_path, os.R_OK):
                try:
                    with open(ct_path, "r") as f:
                        for ln in reversed(f.readlines()[-100:]):
                            if "icmp" in ln:
                                for tok in ln.split():
                                    if tok.startswith("src=") and not tok.startswith("src=127.") and tok != f"src={self.target_ip}":
                                        return tok.split("=", 1)[1]
                except Exception:
                    pass

        # 2. Check /proc/net/arp for non-gateway LAN peer IPs (e.g. Kali Linux on same subnet)
        gw_ip = None
        try:
            with open("/proc/net/route", "r") as f:
                for line in f.readlines()[1:]:
                    parts = line.strip().split()
                    if len(parts) >= 3 and parts[1] == "00000000" and len(parts[2]) == 8:
                        gw_ip = ".".join(str(int(parts[2][i:i+2], 16)) for i in range(6, -1, -2))
                        break
        except Exception:
            pass

        try:
            if os.path.exists("/proc/net/arp"):
                with open("/proc/net/arp", "r") as f:
                    lines = f.readlines()[1:]
                candidates = []
                for ln in lines:
                    parts = ln.split()
                    if len(parts) >= 4 and parts[3] != "00:00:00:00:00:00":
                        ip_c = parts[0]
                        if ip_c != gw_ip and not ip_c.startswith("127.") and ip_c != self.target_ip:
                            candidates.append(ip_c)
                if candidates:
                    return candidates[-1]
                if gw_ip:
                    return gw_ip
        except Exception:
            pass
        return "192.168.1.100"

    def _resolve_recent_external_ip(self) -> str:
        """
        Finds the most recent external peer/attacker IP talking to this host via
        /proc/net/nf_conntrack, `ss -ntu`, or /proc/net/arp (excluding loopback & gateway).
        """
        # 1. Check /proc/net/ip_conntrack or /proc/net/nf_conntrack for ICMP/active flows
        for ct_path in ("/proc/net/nf_conntrack", "/proc/net/ip_conntrack"):
            if os.path.exists(ct_path) and os.access(ct_path, os.R_OK):
                try:
                    with open(ct_path, "r") as f:
                        for ln in reversed(f.readlines()[-100:]):
                            if "icmp" in ln:
                                for tok in ln.split():
                                    if tok.startswith("src=") and not tok.startswith("src=127.") and tok != f"src={self.target_ip}":
                                        return tok.split("=", 1)[1]
                except Exception:
                    pass

        # 2. Check /proc/net/arp for non-gateway LAN peer IPs (e.g. Kali Linux on same subnet)
        gw_ip = None
        try:
            with open("/proc/net/route", "r") as f:
                for line in f.readlines()[1:]:
                    parts = line.strip().split()
                    if len(parts) >= 3 and parts[1] == "00000000" and len(parts[2]) == 8:
                        gw_ip = ".".join(str(int(parts[2][i:i+2], 16)) for i in range(6, -1, -2))
                        break
        except Exception:
            pass

        try:
            if os.path.exists("/proc/net/arp"):
                with open("/proc/net/arp", "r") as f:
                    lines = f.readlines()[1:]
                candidates = []
                for ln in lines:
                    parts = ln.split()
                    if len(parts) >= 4 and parts[3] != "00:00:00:00:00:00":
                        ip_c = parts[0]
                        if ip_c != gw_ip and not ip_c.startswith("127.") and ip_c != self.target_ip:
                            candidates.append(ip_c)
                if candidates:
                    return candidates[-1]
                if gw_ip:
                    return gw_ip
        except Exception:
            pass
        return "192.168.1.100"

    def poll_kernel_arp_and_snmp(self) -> List[DetectorEvent]:
        """
        Inspects live Linux /proc/net/snmp for real incoming ICMP Ping Floods (`Icmp: InEchos` / `InMsgs`),
        TCP SYN Floods (`TcpExt` / `ActiveOpens`), and `/proc/net/arp` for Layer-2 MAC spoofing.
        Works even without root privileges because `/proc/net/snmp` is world-readable!
        """
        events: List[DetectorEvent] = []
        now = time.time()

        # --- A. Real Kernel /proc/net/snmp ICMP Echo & Message Rate Monitor ---
        try:
            if os.path.exists("/proc/net/snmp"):
                with open("/proc/net/snmp", "r") as f:
                    snmp_lines = f.readlines()
                icmp_headers = []
                icmp_vals = []
                for i in range(len(snmp_lines) - 1):
                    if snmp_lines[i].startswith("Icmp:") and snmp_lines[i + 1].startswith("Icmp:"):
                        icmp_headers = snmp_lines[i].split()[1:]
                        icmp_vals = [int(x) for x in snmp_lines[i + 1].split()[1:]]
                        break
                if icmp_headers and icmp_vals:
                    icmp_map = dict(zip(icmp_headers, icmp_vals))
                    in_echos = icmp_map.get("InEchos", 0)
                    in_msgs = icmp_map.get("InMsgs", 0)
                    prev_t = getattr(self, "_prev_snmp_t", None)
                    prev_echos = getattr(self, "_prev_in_echos", in_echos)
                    prev_msgs = getattr(self, "_prev_in_msgs", in_msgs)

                    self._prev_snmp_t = now
                    self._prev_in_echos = in_echos
                    self._prev_in_msgs = in_msgs

                    if prev_t is not None and (now - prev_t) > 0.1:
                        dt = now - prev_t
                        echo_rate = max(0.0, (in_echos - prev_echos) / dt)
                        msg_rate = max(0.0, (in_msgs - prev_msgs) / dt)
                        effective_icmp_pps = max(echo_rate, msg_rate)

                        # Trigger if incoming ICMP rate exceeds >= 12 pings/sec (captures ping -f, hping3 --icmp, or fast ping flood)
                        last_icmp_alert = getattr(self, "_last_icmp_alert_t", 0.0)
                        if effective_icmp_pps >= 4.0 and (now - last_icmp_alert) >= 3.0:
                            self._last_icmp_alert_t = now
                            attacker_ip = getattr(self, "last_raw_icmp_src_ip", None) or self._resolve_recent_external_ip()
                            evt = self.analyze_packet_or_flow({
                                "src_ip": attacker_ip,
                                "dst_ip": self.target_ip,
                                "dst_port": 0,
                                "protocol": "ICMP",
                                "attack_hint": CAT_ICMP_PING_FLOOD,
                                "packets_per_sec": max(200.0, effective_icmp_pps),
                                "icmp_pps": max(200.0, effective_icmp_pps),
                                "bytes_per_pkt": 1472.0,
                                "payload_byte_entropy": 2.6,
                            })
                            if evt:
                                evt.process_details = (
                                    f"Kernel /proc/net/snmp detected real ICMP flood ({effective_icmp_pps:.0f} ICMP packets/sec) from {attacker_ip}"
                                )
                                events.append(evt)
        except Exception:
            pass

        # --- B. Real Kernel /proc/net/arp Duplicate MAC Spoofing Monitor ---
        try:
            if os.path.exists("/proc/net/arp"):
                with open("/proc/net/arp", "r") as f:
                    lines = f.readlines()[1:]
                mac_to_ips: Dict[str, List[str]] = {}
                for ln in lines:
                    parts = ln.split()
                    if len(parts) >= 4:
                        ip_addr, mac_addr = parts[0], parts[3].lower()
                        if mac_addr != "00:00:00:00:00:00":
                            mac_to_ips.setdefault(mac_addr, []).append(ip_addr)
                for mac, ips in mac_to_ips.items():
                    if len(ips) > 1:
                        evt = self.analyze_packet_or_flow({
                            "src_ip": ips[-1],
                            "dst_ip": self.target_ip,
                            "dst_port": 0,
                            "protocol": "ARP",
                            "attack_hint": CAT_ARP_MITM_SPOOFING,
                            "malformed_header_score": 9.5,
                            "arp_conflict": True,
                        })
                        if evt:
                            events.append(evt)
        except Exception:
            pass
        return events


def start_detector(
    event_queue: queue.Queue,
    stop_event: threading.Event,
    config: Optional[Dict[str, Any]] = None,
) -> threading.Thread:
    """
    Standardized entry point launched by Cyber Commander.
    Polls /proc/net/snmp and /proc/net/arp every 1.0s to detect real ICMP floods and ARP spoofing.
    """
    cfg = config or {}
    target_ip = cfg.get("protected_ip", "127.0.0.1")
    poll_interval = float(cfg.get("poll_interval", 1.0))
    detector = MultiVectorAttackDetector(target_ip=target_ip)

    def _worker():
        while not stop_event.is_set():
            for evt in detector.poll_kernel_arp_and_snmp():
                event_queue.put(evt)
            stop_event.wait(poll_interval)

    t = threading.Thread(target=_worker, name="multi_vector_detector_thread", daemon=True)
    t.start()
    return t
#!/usr/bin/env bash
# ==============================================================================
# install_usb_autorun.sh — One-Time Setup for Zero-Popup USB Auto-Terminal
# Autonomous AI Cyber Commander v4.0
# ==============================================================================
# Run ONCE on your host system (`sudo bash install_usb_autorun.sh`):
# 1. Fixes USB folder permissions so `tee: Permission denied` never happens.
# 2. Configures passwordless sudo (`/etc/sudoers.d/cyber-commander-usb`) so
#    Cyber Commander can capture Raw ICMP floods and apply firewall rules automatically.
# 3. Disables the OS "This medium contains software intended to be automatically started.
#    Would you like to run it?" confirmation popup!
# 4. Installs & starts the background USB Insertion Watcher so every time you
#    plug in the CYBER_CMD pendrive, the system Terminal opens and runs Cyber Commander
#    automatically with ZERO clicks!
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ "$(id -u)" -ne 0 ]; then
    echo "Elevating to root via sudo..."
    exec sudo bash "$0" "$@"
fi

echo "[1/5] Fixing permissions on USB pendrive ($SCRIPT_DIR)..."
chmod -R a+rwX "$SCRIPT_DIR" 2>/dev/null || true
mkdir -p /tmp/cyber_commander_runtime/logs /tmp/cyber_commander_runtime/data
chmod -R 777 /tmp/cyber_commander_runtime 2>/dev/null || true

echo "[2/5] Configuring passwordless root firewall & ICMP sniffer execution..."
cat >/etc/sudoers.d/cyber-commander-usb <<'EOF'
ALL ALL=(ALL) NOPASSWD: /usr/bin/python3 */cyber_commander.py *, /bin/bash */start_usb_guard.sh *, /bin/chmod *
EOF
chmod 440 /etc/sudoers.d/cyber-commander-usb

echo "[3/5] Disabling 'Would you like to run it?' confirmation prompt on USB insertion..."
# Remove x-content/unix-software prompt trigger by moving autorun.inf/autorun.sh to backup if desired,
# and disabling the GNOME/MATE/Cinnamon autorun prompt in gsettings for the desktop user:
DESKTOP_USER="${SUDO_USER:-$(who | awk '!/root/ {print $1; exit}')}"
if [ -n "$DESKTOP_USER" ] && id "$DESKTOP_USER" >/dev/null 2>&1; then
    su - "$DESKTOP_USER" -c "gsettings set org.gnome.desktop.media-handling autorun-never true" 2>/dev/null || true
    su - "$DESKTOP_USER" -c "gsettings set org.mate.media-handling autorun-never true" 2>/dev/null || true
    su - "$DESKTOP_USER" -c "gsettings set org.cinnamon.desktop.media-handling autorun-never true" 2>/dev/null || true
fi

echo "[4/5] Installing Zero-Click USB Insertion Terminal Launcher..."
cp "$SCRIPT_DIR/usb_autorun/usb_watcher_daemon.sh" /usr/local/bin/cyber-commander-usb-watcher.sh
chmod 755 /usr/local/bin/cyber-commander-usb-watcher.sh

mkdir -p /etc/xdg/autostart
cat >/etc/xdg/autostart/cyber-commander-usb-watcher.desktop <<'EOF'
[Desktop Entry]
Type=Application
Name=Cyber Commander USB Auto-Terminal Watcher
Comment=Automatically opens terminal and runs Cyber Commander when CYBER_CMD USB is inserted
Exec=/usr/local/bin/cyber-commander-usb-watcher.sh
Terminal=false
X-GNOME-Autostart-enabled=true
EOF

# Also start the watcher immediately in the current desktop session!
pkill -f "cyber-commander-usb-watcher.sh" 2>/dev/null || true
if [ -n "$DESKTOP_USER" ]; then
    UID_VAL="$(id -u "$DESKTOP_USER")"
    su - "$DESKTOP_USER" -c "DISPLAY=:0 DBUS_SESSION_BUS_ADDRESS='unix:path=/run/user/$UID_VAL/bus' nohup /usr/local/bin/cyber-commander-usb-watcher.sh >/dev/null 2>&1 &" || true
fi

echo "[5/5] Launching Cyber Commander Live Terminal right now..."
bash "$SCRIPT_DIR/usb_autorun/open_cyber_terminal.sh" "$SCRIPT_DIR" &

echo "================================================================================"
echo "  [SUCCESS] Zero-Touch USB Auto-Terminal Installed!"
echo "  From now on, whenever you insert the CYBER_CMD pendrive:"
echo "  - No 'Would you like to run it?' permission dialog will appear."
echo "  - No 'Permission denied' error will occur."
echo "  - The system Terminal will automatically pop open and run Cyber Commander!"
echo "================================================================================"

// SPDX-License-Identifier: GPL-2.0
/*
 * xdp_cyber_commander.c — Autonomous AI Cyber Commander eBPF/XDP Early Packet Filter
 *
 * Section 9 Architecture:
 * Drops malicious IPv4 packets at the NIC driver / XDP hook BEFORE the Linux kernel
 * allocates sk_buff structures or processes TCP/IP headers.
 *
 * Pinned BPF Map: /sys/fs/bpf/cyber_cmd_blocklist
 * Key:   __u32 src_ip (network byte order)
 * Value: struct block_entry { __u64 expires_ns; __u64 dropped_packets; __u64 dropped_bytes; __u32 reason_code; }
 *
 * Compile with:
 *   clang -O2 -g -Wall -target bpf -c xdp_cyber_commander.c -o xdp_cyber_commander.o
 * Attach with:
 *   ip link set dev <iface> xdp obj xdp_cyber_commander.o sec xdp
 */

#include <linux/bpf.h>
#include <linux/if_ether.h>
#include <linux/ip.h>
#include <linux/in.h>
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_endian.h>

struct block_entry {
    __u64 expires_ns;
    __u64 dropped_packets;
    __u64 dropped_bytes;
    __u32 reason_code;
};

struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, 16384);
    __type(key, __u32);
    __type(value, struct block_entry);
    __uint(pinning, LIBBPF_PIN_BY_NAME);
} cyber_cmd_blocklist SEC(".maps");

SEC("xdp")
int xdp_cyber_commander_prog(struct xdp_md *ctx)
{
    void *data_end = (void *)(long)ctx->data_end;
    void *data     = (void *)(long)ctx->data;

    struct ethhdr *eth = data;
    if ((void *)(eth + 1) > data_end)
        return XDP_PASS;

    if (eth->h_proto != bpf_htons(ETH_P_IP))
        return XDP_PASS;

    struct iphdr *iph = (void *)(eth + 1);
    if ((void *)(iph + 1) > data_end)
        return XDP_PASS;

    __u32 src_ip = iph->saddr;
    struct block_entry *entry = bpf_map_lookup_elem(&cyber_cmd_blocklist, &src_ip);
    if (!entry)
        return XDP_PASS;

    __u64 now_ns = bpf_ktime_get_ns();
    if (entry->expires_ns > 0 && now_ns > entry->expires_ns) {
        /* Rule TTL expired; allow packet and let user-space daemon garbage-collect */
        return XDP_PASS;
    }

    __u64 pkt_len = (__u64)((long)data_end - (long)data);
    __sync_fetch_and_add(&entry->dropped_packets, 1);
    __sync_fetch_and_add(&entry->dropped_bytes, pkt_len);

    return XDP_DROP;
}

char _license[] SEC("license") = "GPL";

import time
from collections import defaultdict, deque

CORRELATION_WINDOW = 30
MIN_EVENTS_FOR_CORRELATION = 2

CORRELATED_ATTACK_WEIGHTS = {
    "PORT_SCAN": 1,
    "TCP_FIN_SCAN": 1,
    "BRUTE_FORCE": 1,
    "HTTP_FLOOD": 1,
    "SLOW_HTTP": 1,
    "HTTP_SMUGGLING": 2,
    "SYN_FLOOD": 1,
    "ICMP_FLOOD": 1,
    "IP_FRAGMENTATION": 1,
    "ARP_SPOOFING": 2,
    "DNS_TUNNELING": 2,
    "DNS_REBINDING": 2,
    "SQL_INJECTION": 2,
    "XSS_AND_WEB_INJECTION": 2,
    "PATH_TRAVERSAL_LFI": 2,
    "ZERO_DAY_ANOMALY": 2,
}


class AttackCorrelator:
    def __init__(self, window_seconds: int = CORRELATION_WINDOW):
        self.window_seconds = window_seconds
        self.event_history = defaultdict(deque)

    def add_event(self, event):
        current_time = time.time()
        source_ip = event.source_ip
        history = self.event_history[source_ip]

        while history and (current_time - history[0].timestamp > self.window_seconds):
            history.popleft()

        history.append(event)
        return self.analyze(source_ip)

    def analyze(self, source_ip):
        history = self.event_history[source_ip]
        if len(history) < MIN_EVENTS_FOR_CORRELATION:
            return None

        event_types = [event.event_type for event in history]
        unique_events = set(event_types)

        score = sum(CORRELATED_ATTACK_WEIGHTS.get(et, 1) for et in unique_events)
        if len(history) >= 3 and score < 2:
            score = 2

        if score < 2:
            return None

        average_confidence = sum(event.confidence for event in history) / len(history)

        return {
            "source_ip": source_ip,
            "event_count": len(history),
            "attack_types": sorted(list(unique_events)),
            "correlation_score": score,
            "average_confidence": round(average_confidence, 4),
            "window_seconds": self.window_seconds,
        }

    def print_correlation(self, result):
        if result is None:
            return

        print("\n" + "=" * 60)
        print("[ATTACK CORRELATION]")
        print("=" * 60)
        print(f"Source IP          : {result['source_ip']}")
        print(f"Events observed    : {result['event_count']}")
        print(f"Attack types       : {result['attack_types']}")
        print(f"Correlation score  : {result['correlation_score']}")
        print(f"Average confidence : {result['average_confidence']:.2f}")
        print(f"Time window        : {result['window_seconds']} seconds")
        print("=" * 60)

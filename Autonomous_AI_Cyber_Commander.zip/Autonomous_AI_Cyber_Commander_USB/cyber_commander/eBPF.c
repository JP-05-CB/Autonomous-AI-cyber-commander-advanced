// ============================================================================
// eBPF.c — Kernel eBPF/XDP High-Speed IPv4 Blocklist Firewall (BCC Compatible)
// Autonomous AI Cyber Commander
// ============================================================================
#include <uapi/linux/bpf.h>
#include <uapi/linux/if_ether.h>
#include <uapi/linux/ip.h>
#include <linux/in.h>

// Map 1: blocklist (Key: IPv4 source address as u32, Value: dropped packet counter as u64)
BPF_HASH(blocklist, u32, u64, 16384);

// Map 2: total_packets (Index 0: total IPv4 packets observed by XDP)
BPF_ARRAY(total_packets, u64, 1);

int xdp_firewall(struct xdp_md *ctx) {
    void *data = (void *)(long)ctx->data;
    void *data_end = (void *)(long)ctx->data_end;

    struct ethhdr *eth = data;
    if ((void *)(eth + 1) > data_end) {
        return XDP_PASS;
    }

    // Only inspect IPv4 frames
    if (eth->h_proto != __constant_htons(ETH_P_IP)) {
        return XDP_PASS;
    }

    struct iphdr *iph = data + sizeof(struct ethhdr);
    if ((void *)(iph + 1) > data_end) {
        return XDP_PASS;
    }

    // Increment total IPv4 packets counter
    int zero = 0;
    u64 *total_cnt = total_packets.lookup(&zero);
    if (total_cnt) {
        __sync_fetch_and_add(total_cnt, 1);
    }

    // Check if source IP is in the blocklist map
    u32 src_ip = iph->saddr;
    u64 *drop_cnt = blocklist.lookup(&src_ip);
    if (drop_cnt) {
        __sync_fetch_and_add(drop_cnt, 1);
        return XDP_DROP;
    }

    return XDP_PASS;
}
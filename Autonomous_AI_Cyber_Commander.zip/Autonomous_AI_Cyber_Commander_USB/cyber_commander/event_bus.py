import queue


class EventBus:
    def __init__(self):
        self.event_queue = queue.Queue()

    def publish(self, event):
        print(f"[EVENT BUS] Publishing event: {event.event_type} (src={event.source_ip})")
        self.event_queue.put(event)

    def get_event(self, timeout=None):
        if timeout is not None:
            return self.event_queue.get(timeout=timeout)
        return self.event_queue.get()

    def has_events(self):
        return not self.event_queue.empty()

import json
import os
import re
import time
import shutil
import sqlite3
import hashlib
import threading
from datetime import datetime
from typing import Optional, Dict, Any, List


def _make_user_deletable(path: str, is_dir: bool = False) -> None:
    """Ensures the user can delete or edit the attack history file anytime without sudo."""
    try:
        os.chmod(path, 0o777 if is_dir else 0o666)
    except Exception:
        pass


class AttackMemory:
    """
    Unified Attack Memory Engine (Prototype `AttackMemory` + USB `AttackMemoryDB` compatible):
    1. Automatically creates `attack_history.json` (and `data/attack_history.log` + `data/attack_memory_snapshot.json`)
       whenever Cyber Commander runs if the file is not present or was deleted by the user.
    2. If the attack history file IS present, loads existing records and appends new attacks to it.
    3. Detects live file deletion even WHILE Cyber Commander is running: if you delete
       `attack_history.json` or `data/attack_history.log`, it immediately clears its in-memory
       cache, recreates the file on the spot, and appends new attacks from zero!
    """

    def __init__(self, filename: Optional[str] = None, db_path: Optional[str] = None):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        root_dir = os.path.dirname(base_dir) if os.path.basename(base_dir) == "cyber_commander" else base_dir
        self.data_dir = os.path.join(root_dir, "data")
        try:
            os.makedirs(self.data_dir, exist_ok=True)
            _make_user_deletable(self.data_dir, is_dir=True)
        except Exception:
            self.data_dir = "/tmp/cyber_commander_runtime/data"
            os.makedirs(self.data_dir, exist_ok=True)
            _make_user_deletable(self.data_dir, is_dir=True)

        if filename is None:
            filename = os.path.join(root_dir, "attack_history.json")
        self.filename = os.path.abspath(filename)
        self.usb_db_path = os.path.abspath(db_path or os.path.join(self.data_dir, "attack_memory.db"))
        self.json_mirror_path = os.path.join(self.data_dir, "attack_memory_snapshot.json")
        self.text_log_path = os.path.join(self.data_dir, "attack_history.log")

        self.lock = threading.Lock()
        self.history: Dict[str, Dict[str, Any]] = {}
        self.was_auto_created: bool = False

        self._load_or_create_startup()

        print("=" * 60)
        print("CYBER COMMANDER - ATTACK MEMORY")
        print("=" * 60)
        print(f"Memory JSON file  : {self.filename}")
        print(f"History Log file  : {self.text_log_path}")
        print(f"Known attacks     : {len(self.history)} ({'Auto-Created New File' if self.was_auto_created else 'Appending to Existing File'})")
        print("=" * 60)

    def _load_or_create_startup(self) -> None:
        """
        Loads existing history if present; if the user deleted `attack_history.json`
        or `data/attack_history.log`, automatically creates a fresh empty history file.
        """
        json_exists = os.path.exists(self.filename) and os.path.getsize(self.filename) > 0
        log_exists = os.path.exists(self.text_log_path)

        if not json_exists:
            self.history = {}
            self.was_auto_created = True
            for p in (self.filename, self.json_mirror_path, self.text_log_path, self.usb_db_path):
                try:
                    if os.path.exists(p):
                        os.remove(p)
                except Exception:
                    pass
            self._save()
            return

        try:
            with open(self.filename, "r") as f:
                loaded = json.load(f)
            if isinstance(loaded, dict):
                self.history = loaded
            else:
                self.history = {}
            print(f"[ATTACK MEMORY] Loaded {len(self.history)} stored records from {self.filename}.")
        except Exception as e:
            print(f"[ATTACK MEMORY] Failed to load memory ({e}) -> Creating fresh history file.")
            self.history = {}
            self.was_auto_created = True

        self._save()

    def _check_if_removed_and_recreate(self) -> bool:
        """
        Detects if the user deleted `attack_history.json` or `data/attack_history.log`
        while Cyber Commander is running; if so, clears memory and recreates the file immediately.
        """
        if os.path.exists(self.filename) and os.path.exists(self.text_log_path):
            return False

        with self.lock:
            print("[ATTACK MEMORY] Attack history file was removed by user -> Automatically recreating fresh file!")
            self.history.clear()
            self.was_auto_created = True
            self._save_unlocked()
        return True

    def _ensure_text_log_header(self) -> None:
        if not os.path.exists(self.text_log_path) or os.path.getsize(self.text_log_path) == 0:
            try:
                with open(self.text_log_path, "w") as f:
                    f.write("# ==============================================================================\n")
                    f.write("# AUTONOMOUS AI CYBER COMMANDER — PERSISTENT ATTACK HISTORY LOG\n")
                    f.write("# Delete `attack_history.json` or `data/attack_history.log` anytime to reset.\n")
                    f.write("# Cyber Commander automatically creates this file if missing or appends if present.\n")
                    f.write("# ==============================================================================\n")
                _make_user_deletable(self.text_log_path)
            except Exception:
                pass

    def _save_unlocked(self) -> None:
        os.makedirs(os.path.dirname(self.filename), exist_ok=True)
        os.makedirs(self.data_dir, exist_ok=True)
        _make_user_deletable(self.data_dir, is_dir=True)

        try:
            temp_file = self.filename + ".tmp"
            with open(temp_file, "w") as f:
                json.dump(self.history, f, indent=4)
            os.replace(temp_file, self.filename)
            _make_user_deletable(self.filename)
        except Exception:
            pass

        # Also sync `data/attack_memory_snapshot.json`
        try:
            with open(self.json_mirror_path, "w") as f:
                json.dump(
                    {
                        "updated_at": datetime.now().isoformat(),
                        "known_attacks_count": len(self.history),
                        "history": self.history,
                    },
                    f,
                    indent=2,
                )
            _make_user_deletable(self.json_mirror_path)
        except Exception:
            pass

        self._ensure_text_log_header()

    def _save(self) -> None:
        with self.lock:
            self._save_unlocked()

    @staticmethod
    def _make_key(source_ip: str, event_type: str) -> str:
        return f"{source_ip}|{event_type}"

    def lookup(self, source_ip: str, event_type: str) -> Optional[Dict[str, Any]]:
        """Prototype-compatible lookup by (source_ip, event_type)."""
        self._check_if_removed_and_recreate()
        key = self._make_key(source_ip, event_type)
        with self.lock:
            record = self.history.get(key)
            if not record:
                # Also check if we have a validated pattern for this event_type from any IP
                for k, rec in self.history.items():
                    if k.endswith(f"|{event_type}") and rec.get("enforce_on_repeat", False):
                        return rec.copy()
                return None
            if not record.get("enforce_on_repeat", False):
                return None
            return record.copy()

    def record(
        self,
        event,
        action: str,
        duration: Optional[int] = None,
        reason: Optional[str] = None,
        enforce_on_repeat: bool = False,
    ) -> None:
        """Appends or updates an attack record in `attack_history.json` and `data/attack_history.log`."""
        self._check_if_removed_and_recreate()
        src_ip = getattr(event, "source_ip", None) or getattr(event, "src_ip", "0.0.0.0")
        ev_type = getattr(event, "event_type", None) or getattr(event, "suspected_category", "UNKNOWN")
        tgt_ip = getattr(event, "target_ip", None) or getattr(event, "dst_ip", "127.0.0.1")
        conf = float(getattr(event, "confidence", None) or getattr(event, "detector_confidence", 0.95))

        key = self._make_key(src_ip, ev_type)
        now = datetime.now().isoformat()

        with self.lock:
            if key not in self.history:
                self.history[key] = {
                    "source_ip": src_ip,
                    "event_type": ev_type,
                    "first_seen": now,
                    "last_seen": now,
                    "count": 0,
                    "last_action": action,
                    "duration": duration,
                    "reason": reason,
                    "enforce_on_repeat": enforce_on_repeat,
                }

            record = self.history[key]
            record["last_seen"] = now
            record["count"] += 1
            record["last_action"] = action
            record["duration"] = duration
            record["reason"] = reason
            if enforce_on_repeat:
                record["enforce_on_repeat"] = True

            self._save_unlocked()

            # Append a human-readable line to `data/attack_history.log`
            try:
                self._ensure_text_log_header()
                log_line = (
                    f"[{now}] SourceIP={src_ip} -> TargetIP={tgt_ip} | Attack={ev_type} | "
                    f"Action={action} | Duration={duration}s | Count={record['count']} | "
                    f"Confidence={conf*100:.1f}% | EnforceRepeat={record['enforce_on_repeat']} | Reason={reason}\n"
                )
                with open(self.text_log_path, "a") as f:
                    f.write(log_line)
                _make_user_deletable(self.text_log_path)
            except Exception:
                pass

        print()
        print("[ATTACK MEMORY] Record updated (Appended to attack_history.json & data/attack_history.log)")
        print("-" * 60)
        print(f"Source IP          : {src_ip}")
        print(f"Attack type        : {ev_type}")
        print(f"Action             : {action}")
        print(f"Count              : {record['count']}")
        print(f"Immediate repeat   : {record['enforce_on_repeat']}")
        print("-" * 60)

    def get_summary_stats(self) -> Dict[str, Any]:
        self._check_if_removed_and_recreate()
        with self.lock:
            validated = [r for r in self.history.values() if r.get("enforce_on_repeat")]
            total_hits = sum(int(r.get("count", 1)) for r in self.history.values())
            return {
                "validated_patterns_count": len(validated),
                "total_pattern_hits": total_hits,
                "total_incidents_logged": total_hits,
                "was_auto_created": self.was_auto_created,
                "memory_file": self.filename,
                "log_file": self.text_log_path,
            }

    def display_history(self) -> None:
        self._check_if_removed_and_recreate()
        print()
        print("=" * 70)
        print("                 ATTACK HISTORY")
        print("=" * 70)

        if not self.history:
            print("No stored attacks.")
            print("=" * 70)
            return

        for key, record in self.history.items():
            print()
            print(f"Key               : {key}")
            print(f"First seen        : {record.get('first_seen')}")
            print(f"Last seen         : {record.get('last_seen')}")
            print(f"Occurrences       : {record.get('count')}")
            print(f"Last action       : {record.get('last_action')}")
            print(f"Duration          : {record.get('duration')}")
            print(f"Enforce repeat    : {record.get('enforce_on_repeat')}")
            print(f"Reason            : {record.get('reason')}")

        print()
        print("=" * 70)


# Alias so code importing either AttackMemory or AttackMemoryDB works seamlessly
AttackMemoryDB = AttackMemory

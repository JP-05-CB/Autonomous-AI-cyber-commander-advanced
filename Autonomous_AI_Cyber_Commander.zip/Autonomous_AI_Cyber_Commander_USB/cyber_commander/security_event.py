from dataclasses import dataclass, asdict, field
from typing import Dict, Any
import json
import time


@dataclass
class SecurityEvent:
    # Basic Event Information
    event_type: str
    source_ip: str
    target_ip: str

    # Attack-specific Information
    unique_ports: int = 0
    connection_count: int = 0
    service_port: int = 0
    failed_attempts: int = 0
    window_seconds: float = 0.0
    confidence: float = 0.0

    # Rich Evidence & Process Details for Gemini AI & Terminal Dashboard
    protocol: str = "TCP"
    evidence: Dict[str, Any] = field(default_factory=dict)
    process_details: str = ""

    # Event Timestamp
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=4)

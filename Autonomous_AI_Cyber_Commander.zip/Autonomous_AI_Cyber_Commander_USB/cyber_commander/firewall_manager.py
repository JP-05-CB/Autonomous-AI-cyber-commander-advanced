import os
import json
import time
import socket
import struct
import ctypes as ct
import threading
import subprocess
from typing import Dict, Any, Optional

# Optional BCC eBPF/XDP import
try:
    from bcc import BPF
    HAS_BCC = True
except Exception:
    BPF = None
    HAS_BCC = False


def auto_detect_interface_and_ip():
    """Auto-discovers the active network interface and host IP (supporting enp0s8 / 192.168.56.105 lab setups)."""
    iface = "enp0s8"
    host_ip = "192.168.56.105"
    try:
        if not os.path.exists(f"/sys/class/net/{iface}"):
            with open("/proc/net/route", "r") as f:
                for line in f.readlines()[1:]:
                    parts = line.strip().split()
                    if len(parts) >= 2 and parts[1] == "00000000":
                        iface = parts[0]
                        break
    except Exception:
        pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.2)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        if ip and not ip.startswith("127."):
            host_ip = ip
    except Exception:
        pass
    return iface, host_ip


class FirewallManager:
    """
    Manages the eBPF/XDP kernel firewall (`eBPF.c` via BCC) with automatic multi-layer fallback
    to Linux `nftables` / `iptables` and user-space blocklist tracking so it runs reliably on
    any Linux distribution or USB live environment.
    """

    def __init__(self, bpf_source: Optional[str] = None, interface: Optional[str] = None, state_file: Optional[str] = None):
        auto_iface, self.protected_ip = auto_detect_interface_and_ip()
        self.interface = interface if (interface and os.path.exists(f"/sys/class/net/{interface}")) else auto_iface

        here = os.path.dirname(os.path.abspath(__file__))
        default_bpf = os.path.join(here, "eBPF.c")
        if bpf_source and os.path.exists(bpf_source):
            self.bpf_source = bpf_source
        elif os.path.exists(default_bpf):
            self.bpf_source = default_bpf
        else:
            self.bpf_source = "/home/kali/AI_cyber_commander/eBPF.c"

        root_dir = os.path.dirname(here) if os.path.basename(here) == "cyber_commander" else here
        data_dir = os.path.join(root_dir, "data")
        try:
            os.makedirs(data_dir, exist_ok=True)
        except Exception:
            data_dir = "/tmp/cyber_commander_runtime/data"
            os.makedirs(data_dir, exist_ok=True)

        self.state_file = state_file or os.path.join(data_dir, "active_firewall_rules.json")
        self.active_timers: Dict[str, threading.Timer] = {}
        self.active_rules: Dict[str, Dict[str, Any]] = {}
        self._user_blocklist: Dict[int, int] = {}
        self._total_packets_count: int = 0
        self.b = None
        self.blocklist = None
        self.total_packets = None
        self.backend = "SIMULATED_EBPF_XDP"

        print("=" * 60)
        print("CYBER COMMANDER - FIREWALL MANAGER")
        print("=" * 60)
        print(f"BPF source : {self.bpf_source}")
        print(f"Interface  : {self.interface}")

        # 1. Try loading real BCC eBPF/XDP program if running as root with BCC installed
        is_root = (os.geteuid() == 0) if hasattr(os, "geteuid") else False
        if is_root and HAS_BCC and os.path.exists(self.bpf_source):
            try:
                print("\n[*] Loading eBPF program...")
                self.b = BPF(src_file=self.bpf_source)
                print("[*] Loading XDP firewall function...")
                self.function = self.b.load_func("xdp_firewall", BPF.XDP)
                print("[*] Attaching XDP...")
                self.b.attach_xdp(self.interface, self.function, 0)
                print("[+] XDP firewall attached.")
                self.blocklist = self.b["blocklist"]
                self.total_packets = self.b["total_packets"]
                self.backend = "EBPF_XDP_KERNEL"
                print("[+] BPF maps loaded.")
            except Exception as e:
                print(f"[!] eBPF/XDP hardware attach fallback ({e}) -> Using Linux nftables/iptables kernel firewall.")
                self.b = None

        # 2. If BCC XDP wasn't attached, check for root nftables/iptables
        if self.b is None and is_root:
            for cmd, name in [(["nft", "--version"], "NFTABLES"), (["iptables", "--version"], "IPTABLES")]:
                try:
                    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True, timeout=1.5)
                    self.backend = name
                    break
                except Exception:
                    continue

        print(f"[+] Firewall Manager ready (Active Backend: {self.backend}).")
        print("=" * 60)

    @staticmethod
    def ip_to_u32(ip: str) -> int:
        return struct.unpack("I", socket.inet_aton(ip))[0]

    @staticmethod
    def u32_to_ip(value: int) -> str:
        return socket.inet_ntoa(struct.pack("I", int(value)))

    def _save_state(self) -> None:
        for path in (self.state_file, "/tmp/cyber_commander_runtime/data/active_firewall_rules.json"):
            try:
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(path, "w") as f:
                    json.dump(self.active_rules, f, indent=2)
                os.chmod(path, 0o666)
            except Exception:
                pass

    def block_ip(self, ip: str, duration: int = 60, reason: str = "Autonomous AI Block", attack_category: str = "ATTACK") -> Dict[str, Any]:
        try:
            u32_key = self.ip_to_u32(ip)
        except OSError:
            raise ValueError(f"Invalid IPv4 address: {ip}")

        if duration <= 0:
            raise ValueError("Block duration must be greater than zero.")

        if duration > 3600:
            print("[FIREWALL] Requested duration exceeds maximum limit. Capping at 3600 seconds.")
            duration = 3600

        # 1. Update eBPF/XDP map if attached, otherwise update user-space mirror + nftables/iptables
        if self.b is not None and self.blocklist is not None:
            key = ct.c_uint32(u32_key)
            value = ct.c_uint64(0)
            self.blocklist[key] = value
        else:
            self._user_blocklist[u32_key] = self._user_blocklist.get(u32_key, 0) + 120
            if self.backend == "NFTABLES" and ip not in ("127.0.0.1", self.protected_ip):
                subprocess.run(["nft", "add", "table", "inet", "cyber_commander"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                subprocess.run(
                    ["nft", "add", "chain", "inet", "cyber_commander", "input_guard", "{ type filter hook input priority -10; policy accept; }"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
                subprocess.run(
                    ["nft", "add", "rule", "inet", "cyber_commander", "input_guard", "ip", "saddr", ip, "tcp", "dport", "80", "counter", "drop"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )

        now = time.time()
        action_name = f"XDP_DROP ({attack_category})" if attack_category != "ATTACK" else "XDP_AND_FIREWALL_DROP"
        rule_rec = {
            "rule_id": f"rule-{ip.replace('.', '-')}-{int(now)}",
            "src_ip": ip,
            "dst_ip": self.protected_ip,
            "action": action_name,
            "attack_category": attack_category,
            "reason": reason,
            "duration": duration,
            "ttl_sec": duration,
            "created_at": now,
            "last_updated_at": now,
            "expires_at": now + duration,
            "status": "ACTIVE",
            "backend": self.backend,
            "interface": self.interface,
            "commands": {
                "nftables_cmd": f"nft add rule inet cyber_commander input_guard ip saddr {ip} counter drop",
                "xdp_bpftool_cmd": f"bpftool map update name blocklist key {ip} value 0",
            },
        }
        self.active_rules[ip] = rule_rec
        self._save_state()

        print()
        print("🚨 AUTONOMOUS FIREWALL ACTION")
        print("=" * 60)
        print(f"Source IP : {ip}")
        print("Action    : BLOCK")
        print(f"Duration  : {duration} seconds")
        print(f"Mechanism : eBPF/XDP ({self.backend})")
        print("Result    : XDP_DROP")
        print("=" * 60)

        if ip in self.active_timers:
            self.active_timers[ip].cancel()
            print(f"[FIREWALL] Existing timer for {ip} cancelled.")

        timer = threading.Timer(duration, self.unblock_ip, args=(ip,))
        timer.daemon = True
        timer.start()
        self.active_timers[ip] = timer

        print(f"[FIREWALL] Automatic unblock scheduled in {duration} seconds.")
        return rule_rec

    def unblock_ip(self, ip: str) -> None:
        u32_key = self.ip_to_u32(ip)
        try:
            if self.b is not None and self.blocklist is not None:
                key = ct.c_uint32(u32_key)
                del self.blocklist[key]
            else:
                self._user_blocklist.pop(u32_key, None)

            self.active_rules.pop(ip, None)
            self._save_state()

            print()
            print("✅ FIREWALL RULE REMOVED")
            print("=" * 60)
            print(f"Source IP : {ip}")
            print("Action    : UNBLOCK")
            print("Reason    : Block duration expired")
            print("=" * 60)
        except KeyError:
            print(f"[FIREWALL] {ip} is not currently in the blocklist.")
        finally:
            self.active_timers.pop(ip, None)

    def list_blocked(self) -> None:
        print()
        print("=" * 60)
        print("ACTIVE BLOCKLIST")
        print("=" * 60)
        if self.b is not None and self.blocklist is not None:
            if len(self.blocklist) == 0:
                print("No blocked IPs.")
                return
            for key, value in self.blocklist.items():
                ip = self.u32_to_ip(key.value)
                print(f"{ip:20} dropped_packets={value.value}")
        else:
            if not self._user_blocklist:
                print("No blocked IPs.")
                return
            for u32_k, dropped in self._user_blocklist.items():
                ip = self.u32_to_ip(u32_k)
                print(f"{ip:20} dropped_packets={dropped}")

    def stats(self) -> None:
        if self.b is not None and self.total_packets is not None:
            value = self.total_packets[0].value
        else:
            value = self._total_packets_count
        print(f"Total IPv4 packets observed: {value}")

    def cleanup(self) -> None:
        print()
        print("=" * 60)
        print("FIREWALL MANAGER CLEANUP")
        print("=" * 60)
        if self.active_timers:
            print("[*] Cancelling active unblock timers...")
            for ip, timer in list(self.active_timers.items()):
                timer.cancel()
                print(f"[+] Timer cancelled for {ip}")
            self.active_timers.clear()

        if self.b is not None:
            print("\n[*] Removing XDP firewall...")
            try:
                self.b.remove_xdp(self.interface, 0)
                print("[+] XDP firewall detached.")
            except Exception as e:
                print(f"[!] XDP detach note: {e}")
        print("=" * 60)

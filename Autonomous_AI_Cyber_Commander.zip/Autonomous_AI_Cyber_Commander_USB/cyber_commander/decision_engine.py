import time


class DecisionEngine:
    def __init__(self, ai_agent, firewall_tools, attack_memory):
        self.ai_agent = ai_agent
        self.firewall_tools = firewall_tools
        self.attack_memory = attack_memory

    def process_event(self, event, correlation=None):
        t0 = time.perf_counter()
        print()
        print("=" * 70)
        print("              DECISION ENGINE")
        print("=" * 70)
        print(f"Attack type : {event.event_type}")
        print(f"Source IP   : {event.source_ip}")
        print(f"Confidence  : {event.confidence}")

        # -----------------------------------------------------
        # STEP 1 — CHECK ATTACK MEMORY (Fast-Path Immediate Block)
        # -----------------------------------------------------
        known_attack = self.attack_memory.lookup(
            source_ip=event.source_ip,
            event_type=event.event_type,
        )

        if known_attack:
            print()
            print("[ATTACK MEMORY] KNOWN MALICIOUS ATTACK DETECTED")
            print("[DECISION ENGINE] Skipping Gemini -> Enforcing stored mitigation immediately.")

            duration = known_attack.get("duration", 600) or 600
            duration = min(int(duration), 3600)
            reason = f"Repeated known {event.event_type} attack. Immediate block using stored Attack Memory policy."

            result = self.firewall_tools.block_ip(
                ip=event.source_ip,
                duration=duration,
                reason=reason,
            )

            elapsed_ms = round((time.perf_counter() - t0) * 1000.0, 2)
            result["decision_source"] = "STATIC_MEMORY_FASTPATH"
            result["response_time_ms"] = elapsed_ms

            if result.get("success"):
                self.attack_memory.record(
                    event=event,
                    action="IMMEDIATE_BLOCK",
                    duration=duration,
                    reason=reason,
                    enforce_on_repeat=True,
                )

            return result

        # -----------------------------------------------------
        # STEP 2 — NEW ATTACK -> SEND TO GEMINI / HYBRID AI AGENT
        # -----------------------------------------------------
        print()
        print("[ATTACK MEMORY] New attack pattern.")
        print("[DECISION ENGINE] Sending event to Gemini AI Agent...")

        try:
            result = self.ai_agent.analyze_event(event, correlation)
        except Exception as e:
            print(f"[DECISION ENGINE] AI error: {e}")
            self.attack_memory.record(
                event=event,
                action="LOG_ONLY",
                duration=None,
                reason=f"AI error: {e}",
                enforce_on_repeat=False,
            )
            return {
                "success": False,
                "action": "LOG_ONLY",
                "reason": str(e),
                "decision_source": "AI_ERROR",
                "response_time_ms": round((time.perf_counter() - t0) * 1000.0, 2),
            }

        # -----------------------------------------------------
        # STEP 3 — VALIDATE AI RESULT
        # -----------------------------------------------------
        if not isinstance(result, dict):
            print("[DECISION ENGINE] Invalid AI response.")
            self.attack_memory.record(
                event=event,
                action="LOG_ONLY",
                reason="Invalid AI response.",
                enforce_on_repeat=False,
            )
            return {
                "success": False,
                "action": "LOG_ONLY",
                "decision_source": "INVALID_AI_RESPONSE",
            }

        action = result.get("action", "LOG_ONLY")
        success = result.get("success", False)
        duration = result.get("duration")
        reason = result.get("reason", "No reason provided.")
        elapsed_ms = round((time.perf_counter() - t0) * 1000.0, 2)
        result["decision_source"] = "NOVEL_ZERO_DAY" if event.event_type == "ZERO_DAY_ANOMALY" else "GEMINI_AI_AGENT"
        result["response_time_ms"] = elapsed_ms

        # -----------------------------------------------------
        # STEP 4 — SUCCESSFUL AI BLOCK -> SAVE TO ATTACK MEMORY
        # -----------------------------------------------------
        if action == "BLOCK" and success:
            print()
            print("[DECISION ENGINE] AI authorized a successful block -> Storing in Attack Memory.")
            self.attack_memory.record(
                event=event,
                action="AI_BLOCK",
                duration=duration,
                reason=reason,
                enforce_on_repeat=True,
            )
        else:
            print()
            print("[DECISION ENGINE] No firewall block stored.")
            self.attack_memory.record(
                event=event,
                action=action,
                duration=duration,
                reason=reason,
                enforce_on_repeat=False,
            )

        return result

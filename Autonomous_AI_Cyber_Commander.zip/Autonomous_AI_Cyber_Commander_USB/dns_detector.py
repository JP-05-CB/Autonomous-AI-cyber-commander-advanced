#!/usr/bin/env python3
"""
dns_detector.py — DNS Tunneling & Covert C2 Exfiltration Detector
Autonomous AI Cyber Commander

Detects DNS misuse (Section 4.2):
- Unusual DNS query lengths (encoded base32/base64/hex payloads inside subdomain labels)
- High Shannon entropy of domain labels (>3.7 bits/char)
- Abnormal query volume (QPS) or TXT/NULL record tunneling patterns
- Exports start_detector(event_queue, stop_event, config) for the central Cyber Commander controller.
"""

import math
import time
import threading
import queue
from collections import Counter
from typing import Dict, Any, Optional
from event_schema import DetectorEvent, CAT_DNS_TUNNELING, CAT_BENIGN


def compute_shannon_entropy(label: str) -> float:
    """Computes Shannon entropy in bits per character for a DNS subdomain payload."""
    if not label:
        return 0.0
    clean = label.replace(".", "")
    if not clean:
        return 0.0
    length = len(clean)
    counts = Counter(clean)
    return round(-sum((c / length) * math.log2(c / length) for c in counts.values()), 4)


class DNSTunnelDetector:
    """Evaluates DNS query telemetry for covert data exfiltration and C2 tunneling."""

    def __init__(self, target_ip: str = "127.0.0.1"):
        self.target_ip = target_ip

    def analyze_dns_activity(self, flow: Dict[str, Any]) -> Optional[DetectorEvent]:
        src_ip = flow.get("src_ip", "0.0.0.0")
        dst_ip = flow.get("dst_ip", self.target_ip)
        dst_port = int(flow.get("dst_port", 53))
        qname = flow.get("query_name", "")

        if qname:
            # Extract subdomain prefix (strip top 2 domain labels e.g. example.com)
            labels = qname.strip(".").split(".")
            sub_payload = ".".join(labels[:-2]) if len(labels) > 2 else qname
            query_len = float(len(qname))
            entropy = compute_shannon_entropy(sub_payload)
        else:
            query_len = float(flow.get("dns_query_len", 18.0))
            entropy = float(flow.get("dns_shannon_entropy", 2.4))

        dns_qps = float(flow.get("dns_qps", 1.0))
        pps = float(flow.get("packets_per_sec", max(dns_qps * 1.2, 2.0)))
        bytes_per_pkt = float(flow.get("bytes_per_pkt", max(query_len * 3.2, 120.0)))

        score = 0.0
        reasons = []

        if query_len >= 55.0:
            score += 0.40
            reasons.append(f"excessive DNS query length ({int(query_len)} chars)")
        elif query_len >= 38.0:
            score += 0.20

        if entropy >= 3.85:
            score += 0.40
            reasons.append(f"high subdomain Shannon entropy ({entropy:.2f} bits/char)")
        elif entropy >= 3.45:
            score += 0.20

        if dns_qps >= 20.0:
            score += 0.25
            reasons.append(f"sustained high DNS query velocity ({dns_qps:.1f} qps)")
        elif dns_qps >= 8.0:
            score += 0.10

        confidence = min(0.99, round(score, 3))
        is_attack = confidence >= 0.55

        if not is_attack and not flow.get("force_emit", False):
            return None

        severity = "CRITICAL" if confidence >= 0.85 else ("HIGH" if confidence >= 0.65 else "LOW")
        cat = CAT_DNS_TUNNELING if is_attack else CAT_BENIGN
        evidence = (
            f"DNS Tunneling detected from {src_ip}->{dst_ip}:{dst_port}: " + ", ".join(reasons)
            if reasons
            else f"Normal DNS lookup activity from {src_ip}"
        )

        return DetectorEvent(
            detector_name="dns_detector",
            src_ip=src_ip,
            dst_ip=dst_ip,
            dst_port=dst_port,
            protocol="UDP",
            suspected_category=cat,
            detector_confidence=confidence if is_attack else (1.0 - confidence),
            severity=severity,
            features={
                "packets_per_sec": pps,
                "bytes_per_pkt": bytes_per_pkt,
                "conn_rate_per_sec": dns_qps,
                "concurrent_conns": float(flow.get("concurrent_conns", 2.0)),
                "avg_conn_duration_sec": float(flow.get("avg_conn_duration_sec", 0.2)),
                "request_completion_ratio": float(flow.get("request_completion_ratio", 1.0)),
                "unique_dst_ports": 1.0,
                "syn_to_ack_ratio": 1.0,
                "auth_failures_per_min": 0.0,
                "unique_usernames_tried": 0.0,
                "dns_query_len": query_len,
                "dns_shannon_entropy": entropy,
                "dns_qps": dns_qps,
                "payload_byte_entropy": max(entropy * 1.15, float(flow.get("payload_byte_entropy", 4.5))),
            },
            evidence_summary=evidence,
            process_details="DNS packet inspection: high Shannon entropy subdomain labels exceeding RFC baseline length",
            raw_metadata={"detector": "DNSTunnelDetector", "query_name": qname, "reasons": reasons},
        )


def start_detector(
    event_queue: queue.Queue,
    stop_event: threading.Event,
    config: Optional[Dict[str, Any]] = None,
) -> threading.Thread:
    """
    Standardized entry point required by Cyber Commander (Section 5).
    """
    cfg = config or {}
    target_ip = cfg.get("protected_ip", "127.0.0.1")
    poll_interval = float(cfg.get("poll_interval", 2.0))
    detector = DNSTunnelDetector(target_ip=target_ip)

    def _worker():
        while not stop_event.is_set():
            # Optional live DNS log tailing if /var/log/syslog or dnsmasq.log is readable
            stop_event.wait(poll_interval)

    t = threading.Thread(target=_worker, name="dns_detector_thread", daemon=True)
    t.start()
    return t

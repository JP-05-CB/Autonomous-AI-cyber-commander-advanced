#!/usr/bin/env python3
"""
brute_force_detector.py — Authentication Brute-Force & Credential Stuffing Detector
Autonomous AI Cyber Commander

Detects credential abuse across SSH, HTTP Auth, FTP, and system logins (Section 4.4):
- High frequency of failed authentication attempts (auth_failures_per_min)
- Multiple distinct usernames tried from a single source IP (dictionary / credential stuffing)
- Inspects live /var/log/auth.log or /var/log/secure when available, plus structured telemetry.
- Exports start_detector(event_queue, stop_event, config) for the central Cyber Commander controller.
"""

import os
import re
import time
import threading
import queue
from typing import Dict, Any, Optional
from event_schema import DetectorEvent, CAT_BRUTE_FORCE, CAT_BENIGN


class BruteForceDetector:
    """Evaluates authentication failure telemetry for brute-force & credential stuffing."""

    def __init__(self, target_ip: str = "127.0.0.1"):
        self.target_ip = target_ip

    def analyze_auth_window(self, flow: Dict[str, Any]) -> Optional[DetectorEvent]:
        src_ip = flow.get("src_ip", "0.0.0.0")
        dst_ip = flow.get("dst_ip", self.target_ip)
        dst_port = int(flow.get("dst_port", 22))
        failures_per_min = float(flow.get("auth_failures_per_min", 0.0))
        unique_users = float(flow.get("unique_usernames_tried", 1.0))
        conn_rate = float(flow.get("conn_rate_per_sec", max(failures_per_min / 15.0, 1.0)))
        pps = float(flow.get("packets_per_sec", max(failures_per_min * 0.8, 6.0)))

        score = 0.0
        reasons = []

        if failures_per_min >= 15.0:
            score += 0.50
            reasons.append(f"{int(failures_per_min)} failed logins/min")
        elif failures_per_min >= 6.0:
            score += 0.30
            reasons.append(f"{int(failures_per_min)} failed logins/min")

        if unique_users >= 5.0:
            score += 0.35
            reasons.append(f"dictionary enumeration across {int(unique_users)} usernames")
        elif unique_users >= 2.0 and failures_per_min >= 6.0:
            score += 0.20

        if dst_port in (22, 21, 23, 3389, 80, 443, 8080) and failures_per_min >= 8.0:
            score += 0.15
            reasons.append(f"targeted auth service port {dst_port}")

        confidence = min(0.99, round(score, 3))
        is_attack = confidence >= 0.55

        if not is_attack and not flow.get("force_emit", False):
            return None

        severity = "CRITICAL" if confidence >= 0.85 else ("HIGH" if confidence >= 0.65 else "MEDIUM")
        cat = CAT_BRUTE_FORCE if is_attack else CAT_BENIGN
        evidence = (
            f"Credential Brute-Force from {src_ip}->{dst_ip}:{dst_port}: " + ", ".join(reasons)
            if reasons
            else f"Normal authentication activity from {src_ip}"
        )

        return DetectorEvent(
            detector_name="brute_force_detector",
            src_ip=src_ip,
            dst_ip=dst_ip,
            dst_port=dst_port,
            protocol="TCP",
            suspected_category=cat,
            detector_confidence=confidence if is_attack else (1.0 - confidence),
            severity=severity,
            features={
                "packets_per_sec": pps,
                "bytes_per_pkt": float(flow.get("bytes_per_pkt", 320.0)),
                "conn_rate_per_sec": conn_rate,
                "concurrent_conns": float(flow.get("concurrent_conns", 4.0)),
                "avg_conn_duration_sec": float(flow.get("avg_conn_duration_sec", 2.2)),
                "request_completion_ratio": float(flow.get("request_completion_ratio", 0.9)),
                "unique_dst_ports": 1.0,
                "syn_to_ack_ratio": 1.1,
                "auth_failures_per_min": failures_per_min,
                "unique_usernames_tried": unique_users,
                "dns_query_len": 14.0,
                "dns_shannon_entropy": 2.1,
                "dns_qps": 0.1,
                "payload_byte_entropy": float(flow.get("payload_byte_entropy", 4.8)),
            },
            evidence_summary=evidence,
            process_details="PAM/SSH authentication log & socket monitor: high-frequency credential dictionary failures",
            raw_metadata={"detector": "BruteForceDetector", "reasons": reasons},
        )


def start_detector(
    event_queue: queue.Queue,
    stop_event: threading.Event,
    config: Optional[Dict[str, Any]] = None,
) -> threading.Thread:
    """
    Standardized entry point required by Cyber Commander (Section 5).
    Monitors /var/log/auth.log or /var/log/secure for SSH/PAM authentication failures.
    """
    cfg = config or {}
    target_ip = cfg.get("protected_ip", "127.0.0.1")
    poll_interval = float(cfg.get("poll_interval", 2.0))
    detector = BruteForceDetector(target_ip=target_ip)
    auth_logs = ["/var/log/auth.log", "/var/log/secure"]
    failed_re = re.compile(r"Failed password for (?:invalid user )?(\S+) from (\d+\.\d+\.\d+\.\d+)")

    def _worker():
        seen_lines = 0
        active_log = next((p for p in auth_logs if os.path.exists(p) and os.access(p, os.R_OK)), None)
        while not stop_event.is_set():
            if active_log:
                try:
                    with open(active_log, "r", errors="ignore") as f:
                        lines = f.readlines()
                    new_lines = lines[seen_lines:]
                    seen_lines = len(lines)
                    per_ip_fails: Dict[str, list] = {}
                    for ln in new_lines:
                        m = failed_re.search(ln)
                        if m:
                            user, sip = m.group(1), m.group(2)
                            per_ip_fails.setdefault(sip, []).append(user)
                    for sip, users in per_ip_fails.items():
                        if len(users) >= 5:
                            evt = detector.analyze_auth_window({
                                "src_ip": sip,
                                "dst_ip": target_ip,
                                "dst_port": 22,
                                "auth_failures_per_min": len(users) * 4.0,
                                "unique_usernames_tried": len(set(users)),
                            })
                            if evt:
                                event_queue.put(evt)
                except Exception:
                    pass
            stop_event.wait(poll_interval)

    t = threading.Thread(target=_worker, name="brute_force_detector_thread", daemon=True)
    t.start()
    return t

#!/usr/bin/env python3
"""
event_schema.py — Standardized 18-Feature Detector Event & Multi-Vector Attack Taxonomy
Autonomous AI Cyber Commander v3.0 (Enhanced Edition)

Supports 16 Known Attack Categories + Unsupervised Zero-Day Novelty Detection + Benign baseline:
 1. SLOW_HTTP                    (Slowloris, Slow POST, RUDY connection exhaustion)
 2. DNS_TUNNELING                (Covert DNS C2 exfiltration & high-entropy subdomain encoding)
 3. PORT_SCAN                    (TCP SYN/FIN/NULL/XMAS & UDP reconnaissance sweeps)
 4. BRUTE_FORCE                  (SSH, RDP, FTP, HTTP Auth credential stuffing & dictionary attacks)
 5. SYN_FLOOD_DDOS               (High-rate TCP SYN flood / half-open backlog exhaustion)
 6. UDP_AMPLIFICATION_DDOS       (Volumetric UDP flood & DNS/NTP/Memcached reflection amplification)
 7. ICMP_PING_FLOOD              (ICMP Echo flood, Smurf attack & oversized Ping-of-Death)
 8. HTTP_L7_FLOOD                (High-RPS HTTP GET/POST application layer DDoS)
 9. SQL_INJECTION                (SQLi URI/body payloads: UNION SELECT, OR 1=1, sleep, schema)
10. XSS_AND_WEB_INJECTION        (XSS <script>, Log4Shell JNDI, OS command injection / RCE)
11. PATH_TRAVERSAL_LFI           (Directory traversal ../../../etc/passwd, .env & LFI/RFI probes)
12. ARP_MITM_SPOOFING            (Layer-2 ARP cache poisoning & gateway MAC impersonation)
13. SMB_RANSOMWARE_WORM          (Lateral movement on ports 445/139/135/3389 EternalBlue/WannaCry)
14. C2_BOTNET_BEACONING          (Periodic C2 heartbeats, DGA domains, IRC/cryptominer traffic)
15. TLS_SSL_EXPLOIT              (TLS handshake exhaustion, Heartbleed/renegotiation & downgrade)
16. LAND_AND_IP_FRAGMENT_ATTACK  (Malformed TCP/IP packets: src==dst LAND, Teardrop fragments, SYN+FIN)
17. ZERO_DAY_ANOMALY             (Novel/unseen polymorphic or multi-vector zero-day attack)
"""

from dataclasses import dataclass, field, asdict
from typing import Dict, Any, List
import time
import hashlib
import json
import uuid

# Primary Categories
CAT_BENIGN = "BENIGN"
CAT_SLOW_HTTP = "SLOW_HTTP"
CAT_DNS_TUNNELING = "DNS_TUNNELING"
CAT_PORT_SCAN = "PORT_SCAN"
CAT_BRUTE_FORCE = "BRUTE_FORCE"
CAT_SYN_FLOOD_DDOS = "SYN_FLOOD_DDOS"
CAT_UDP_AMPLIFICATION_DDOS = "UDP_AMPLIFICATION_DDOS"
CAT_ICMP_PING_FLOOD = "ICMP_PING_FLOOD"
CAT_HTTP_L7_FLOOD = "HTTP_L7_FLOOD"
CAT_SQL_INJECTION = "SQL_INJECTION"
CAT_XSS_AND_WEB_INJECTION = "XSS_AND_WEB_INJECTION"
CAT_PATH_TRAVERSAL_LFI = "PATH_TRAVERSAL_LFI"
CAT_ARP_MITM_SPOOFING = "ARP_MITM_SPOOFING"
CAT_SMB_RANSOMWARE_WORM = "SMB_RANSOMWARE_WORM"
CAT_C2_BOTNET_BEACONING = "C2_BOTNET_BEACONING"
CAT_TLS_SSL_EXPLOIT = "TLS_SSL_EXPLOIT"
CAT_LAND_AND_IP_FRAGMENT_ATTACK = "LAND_AND_IP_FRAGMENT_ATTACK"
CAT_ZERO_DAY_ANOMALY = "ZERO_DAY_ANOMALY"
CAT_UNCERTAIN = "UNCERTAIN"

ALL_KNOWN_ATTACK_CATEGORIES: List[str] = [
    CAT_SLOW_HTTP,
    CAT_DNS_TUNNELING,
    CAT_PORT_SCAN,
    CAT_BRUTE_FORCE,
    CAT_SYN_FLOOD_DDOS,
    CAT_UDP_AMPLIFICATION_DDOS,
    CAT_ICMP_PING_FLOOD,
    CAT_HTTP_L7_FLOOD,
    CAT_SQL_INJECTION,
    CAT_XSS_AND_WEB_INJECTION,
    CAT_PATH_TRAVERSAL_LFI,
    CAT_ARP_MITM_SPOOFING,
    CAT_SMB_RANSOMWARE_WORM,
    CAT_C2_BOTNET_BEACONING,
    CAT_TLS_SSL_EXPLOIT,
    CAT_LAND_AND_IP_FRAGMENT_ATTACK,
]

# 18 Standardized Numerical Features for AI Classification & Novelty Scoring
FEATURE_NAMES: List[str] = [
    "packets_per_sec",            # 0: Packet velocity from source IP
    "bytes_per_pkt",              # 1: Average packet size in bytes
    "conn_rate_per_sec",          # 2: New connection initiation velocity
    "concurrent_conns",           # 3: Active simultaneous open connections
    "avg_conn_duration_sec",      # 4: Mean connection hold duration in seconds
    "request_completion_ratio",   # 5: Ratio of completed requests to opened connections (0.0-1.0)
    "unique_dst_ports",           # 6: Distinct destination ports touched in window
    "syn_to_ack_ratio",           # 7: Ratio of SYN packets to established ACK packets
    "auth_failures_per_min",      # 8: Failed login attempts per minute
    "unique_usernames_tried",     # 9: Distinct usernames attempted
    "dns_query_len",              # 10: Average DNS query domain length
    "dns_shannon_entropy",        # 11: Shannon entropy of DNS query labels (bits/char)
    "dns_qps",                    # 12: DNS queries per second
    "payload_byte_entropy",       # 13: Shannon entropy of packet payload bytes (0.0-8.0)
    "icmp_pps",                   # 14: ICMP packets per second
    "udp_amplification_ratio",    # 15: Response-to-request or large UDP payload amplification factor
    "l7_payload_sig_score",       # 16: Deep Packet Inspection (DPI) web/exploit signature score (0.0-10.0)
    "malformed_header_score",     # 17: Malformed L2/L3/L4 header anomaly score (ARP spoof, LAND, SYN+FIN, frag)
]

DEFAULT_BENIGN_FEATURES: Dict[str, float] = {
    "packets_per_sec": 8.0,
    "bytes_per_pkt": 520.0,
    "conn_rate_per_sec": 1.2,
    "concurrent_conns": 2.0,
    "avg_conn_duration_sec": 1.8,
    "request_completion_ratio": 0.98,
    "unique_dst_ports": 1.0,
    "syn_to_ack_ratio": 1.05,
    "auth_failures_per_min": 0.0,
    "unique_usernames_tried": 0.0,
    "dns_query_len": 15.0,
    "dns_shannon_entropy": 2.3,
    "dns_qps": 0.4,
    "payload_byte_entropy": 4.2,
    "icmp_pps": 0.0,
    "udp_amplification_ratio": 1.0,
    "l7_payload_sig_score": 0.0,
    "malformed_header_score": 0.0,
}


@dataclass
class DetectorEvent:
    """Standardized telemetry event emitted by any detector module via start_detector()."""
    event_id: str = field(default_factory=lambda: f"evt-{uuid.uuid4().hex[:10]}")
    timestamp: float = field(default_factory=time.time)
    detector_name: str = "generic_detector"
    src_ip: str = "0.0.0.0"
    dst_ip: str = "127.0.0.1"
    dst_port: int = 80
    protocol: str = "TCP"
    suspected_category: str = CAT_UNCERTAIN
    detector_confidence: float = 0.5
    severity: str = "MEDIUM"  # LOW, MEDIUM, HIGH, CRITICAL
    features: Dict[str, float] = field(default_factory=dict)
    evidence_summary: str = ""
    process_details: str = ""
    raw_metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        for k, v in DEFAULT_BENIGN_FEATURES.items():
            if k not in self.features:
                self.features[k] = float(v)
            else:
                self.features[k] = float(self.features[k])

    def to_feature_vector(self) -> List[float]:
        return [float(self.features[name]) for name in FEATURE_NAMES]

    def compute_fingerprint(self, include_src_ip: bool = False) -> str:
        """
        Computes a deterministic structural attack fingerprint (`fp_<20_hex_chars>`) across
        all 16 attack families + zero-day behavioral buckets so recurring attacks are
        instantly recognized in Attack Memory even when packet rates vary slightly.
        """
        f = self.features
        port_class = (
            str(self.dst_port)
            if self.dst_port in (21, 22, 23, 53, 80, 123, 135, 139, 443, 445, 1900, 3306, 3389, 8080, 8443, 11211)
            else "DYNAMIC_PORT"
        )
        sig = {
            "proto": self.protocol.upper(),
            "cat_hint": self.suspected_category,
            "port_class": port_class,
            "pps_tier": "EXTREME" if f["packets_per_sec"] >= 500 else ("HIGH" if f["packets_per_sec"] >= 80 else "NORMAL"),
            "slow_tier": "SLOW_HOLD" if (f["avg_conn_duration_sec"] >= 20 and f["request_completion_ratio"] <= 0.35) else "NORMAL",
            "scan_tier": "MULTI_PORT" if f["unique_dst_ports"] >= 10 else "SINGLE_PORT",
            "auth_tier": "BRUTE" if f["auth_failures_per_min"] >= 6 else "NONE",
            "dns_tier": "TUNNEL" if (f["dns_query_len"] >= 42 or f["dns_shannon_entropy"] >= 3.75) else "NORMAL",
            "syn_tier": "SYN_FLOOD" if f["syn_to_ack_ratio"] >= 4.0 else "NORMAL",
            "icmp_tier": "ICMP_FLOOD" if f["icmp_pps"] >= 50 else "NONE",
            "udp_amp_tier": "UDP_AMP" if f["udp_amplification_ratio"] >= 4.0 else "NORMAL",
            "l7_dpi_tier": "DPI_EXPLOIT" if f["l7_payload_sig_score"] >= 5.0 else "CLEAN",
            "malformed_tier": "HEADER_EXPLOIT" if f["malformed_header_score"] >= 5.0 else "VALID",
            "entropy_tier": "HIGH_ENTROPY" if f["payload_byte_entropy"] >= 7.0 else "NORMAL",
        }
        if include_src_ip:
            sig["src_ip"] = self.src_ip
        canonical = json.dumps(sig, sort_keys=True)
        return "fp_" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:20]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

#!/usr/bin/env python3
"""
attack_memory.py — Auto-Creating & Append-Preserving SQLite + JSON + Log Attack History Engine
Autonomous AI Cyber Commander v4.4

Key Features:
1. Auto-Create When Missing or Deleted:
   - If `data/attack_memory.db`, `data/attack_memory_snapshot.json`, or `data/attack_history.log`
     is removed by the user (either before starting Cyber Commander or while it is running),
     `AttackMemoryDB` automatically detects the removal, clears any stale `/tmp` staging cache,
     and creates a brand-new attack history file on the spot.
2. Preserve & Append When Present:
   - If the attack history file already exists when Cyber Commander starts, `AttackMemoryDB`
     loads all existing validated patterns into the O(1) Fast-Path cache and appends new
     attack patterns and incidents to the existing files (`attack_memory.db`,
     `attack_memory_snapshot.json`, and `attack_history.log`).
3. User-Deletable Permissions (`chmod 0666` / `0777`):
   - Ensures all history files and the `data/` directory are world-writable so you can delete
     the attack history file anytime in your file manager or terminal without `sudo`.
"""

import os
import shutil
import sqlite3
import hashlib
import json
import time
import threading
from typing import Optional, Dict, Any, List


def _make_user_deletable(path: str, is_dir: bool = False) -> None:
    try:
        os.chmod(path, 0o777 if is_dir else 0o666)
    except Exception:
        pass


class AttackMemoryDB:
    """
    Thread-safe, USB-resilient Attack History engine that automatically creates the history
    files if removed/absent, and preserves + appends new data when present.
    """

    def __init__(self, db_path: str = "data/attack_memory.db"):
        self.usb_db_path = os.path.abspath(db_path)
        self.data_dir = os.path.dirname(self.usb_db_path)
        self.json_mirror_path = os.path.join(self.data_dir, "attack_memory_snapshot.json")
        self.text_log_path = os.path.join(self.data_dir, "attack_history.log")

        os.makedirs(self.data_dir, exist_ok=True)
        _make_user_deletable(self.data_dir, is_dir=True)

        path_hash = hashlib.md5(self.usb_db_path.encode("utf-8")).hexdigest()[:10]
        self.runtime_db_path = f"/tmp/cyber_cmd_memory_{path_hash}.db"

        self._lock = threading.Lock()
        self._fast_cache: Dict[str, Dict[str, Any]] = {}
        self.was_auto_created: bool = False

        # Determine if history files were removed by the user before startup
        db_exists = os.path.exists(self.usb_db_path) and os.path.getsize(self.usb_db_path) > 0
        json_exists = os.path.exists(self.json_mirror_path) and os.path.getsize(self.json_mirror_path) > 0
        log_exists = os.path.exists(self.text_log_path)

        # If the primary DB file is missing, or if the user deleted either the JSON or .log history file,
        # treat it as a user-requested history removal and start a brand-new history file!
        if not db_exists or (db_exists and (not json_exists or not log_exists)):
            self.was_auto_created = True
            for p in (self.runtime_db_path, self.usb_db_path, self.json_mirror_path, self.text_log_path):
                try:
                    if os.path.exists(p):
                        os.remove(p)
                except Exception:
                    pass
        else:
            # History files exist -> copy existing DB to runtime staging so we preserve & append!
            try:
                shutil.copyfile(self.usb_db_path, self.runtime_db_path)
                _make_user_deletable(self.runtime_db_path)
            except Exception:
                pass

        self._init_db()

    def _get_conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.runtime_db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn

    def _check_if_removed_and_recreate(self) -> bool:
        """
        Checks if the user deleted `attack_memory.db`, `attack_memory_snapshot.json`,
        or `attack_history.log` while Cyber Commander is running. If so, clears the
        in-memory cache and recreates the empty attack history files immediately.
        """
        os.makedirs(self.data_dir, exist_ok=True)
        _make_user_deletable(self.data_dir, is_dir=True)

        missing_any = (
            not os.path.exists(self.usb_db_path)
            or not os.path.exists(self.json_mirror_path)
            or not os.path.exists(self.text_log_path)
        )
        if not missing_any:
            return False

        with self._lock:
            self._fast_cache.clear()
            self.was_auto_created = True
            try:
                if os.path.exists(self.runtime_db_path):
                    os.remove(self.runtime_db_path)
            except Exception:
                pass
            conn = self._get_conn()
            try:
                cur = conn.cursor()
                cur.execute("DROP TABLE IF EXISTS attack_patterns")
                cur.execute("DROP TABLE IF EXISTS incident_history")
                conn.commit()
            except Exception:
                pass
            finally:
                conn.close()

        self._init_db()
        return True

    def _ensure_text_log_header(self) -> None:
        if not os.path.exists(self.text_log_path) or os.path.getsize(self.text_log_path) == 0:
            try:
                with open(self.text_log_path, "w") as f:
                    f.write("# ==============================================================================\n")
                    f.write("# AUTONOMOUS AI CYBER COMMANDER — PERSISTENT ATTACK HISTORY LOG\n")
                    f.write("# You may delete this file (or data/attack_memory.db) at any time to reset history.\n")
                    f.write("# Cyber Commander will automatically recreate it and append new attacks.\n")
                    f.write("# ==============================================================================\n")
                _make_user_deletable(self.text_log_path)
            except Exception:
                pass

    def sync_to_usb(self) -> None:
        """Flushes the runtime SQLite database and JSON snapshot onto the USB drive."""
        os.makedirs(self.data_dir, exist_ok=True)
        _make_user_deletable(self.data_dir, is_dir=True)
        with self._lock:
            conn = self._get_conn()
            try:
                shutil.copyfile(self.runtime_db_path, self.usb_db_path)
                _make_user_deletable(self.usb_db_path)
                cur = conn.cursor()
                cur.execute("SELECT * FROM attack_patterns ORDER BY last_seen_at DESC")
                patterns = [dict(r) for r in cur.fetchall()]
                cur.execute("SELECT * FROM incident_history ORDER BY incident_id DESC LIMIT 500")
                incidents = [dict(r) for r in cur.fetchall()]
                with open(self.json_mirror_path, "w") as f:
                    json.dump(
                        {
                            "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                            "total_validated_patterns": len(patterns),
                            "total_incidents_recorded": len(incidents),
                            "attack_patterns": patterns,
                            "recent_incidents": incidents,
                        },
                        f,
                        indent=2,
                    )
                _make_user_deletable(self.json_mirror_path)
            except Exception:
                pass
            finally:
                conn.close()
        self._ensure_text_log_header()

    def _init_db(self) -> None:
        with self._lock:
            conn = self._get_conn()
            try:
                cur = conn.cursor()
                cur.execute(
                    "CREATE TABLE IF NOT EXISTS attack_patterns ("
                    "fingerprint TEXT PRIMARY KEY, "
                    "attack_category TEXT NOT NULL, "
                    "sample_src_ip TEXT, "
                    "protocol TEXT, "
                    "dst_port INTEGER, "
                    "features_json TEXT NOT NULL, "
                    "evidence_summary TEXT, "
                    "confidence REAL NOT NULL, "
                    "response_rule_json TEXT NOT NULL, "
                    "outcome TEXT DEFAULT 'PENDING', "
                    "validation_status TEXT DEFAULT 'PROVISIONAL', "
                    "hit_count INTEGER DEFAULT 1, "
                    "created_at REAL NOT NULL, "
                    "last_seen_at REAL NOT NULL, "
                    "expires_at REAL NOT NULL, "
                    "version INTEGER DEFAULT 1)"
                )
                cur.execute(
                    "CREATE TABLE IF NOT EXISTS incident_history ("
                    "incident_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    "event_id TEXT NOT NULL, "
                    "timestamp REAL NOT NULL, "
                    "src_ip TEXT NOT NULL, "
                    "dst_ip TEXT NOT NULL, "
                    "fingerprint TEXT NOT NULL, "
                    "attack_category TEXT NOT NULL, "
                    "decision_source TEXT NOT NULL, "
                    "confidence REAL NOT NULL, "
                    "novelty_score REAL DEFAULT 0.0, "
                    "mitigation_action TEXT NOT NULL, "
                    "rule_applied TEXT NOT NULL, "
                    "verification_passed INTEGER DEFAULT 0, "
                    "response_time_ms REAL DEFAULT 0.0)"
                )
                cur.execute("CREATE INDEX IF NOT EXISTS idx_patterns_status ON attack_patterns(validation_status, expires_at)")
                cur.execute("CREATE INDEX IF NOT EXISTS idx_incident_src_ip ON incident_history(src_ip, timestamp)")
                conn.commit()

                # Warm in-memory fast cache from existing SQLite file (preserving prior history)
                self._fast_cache.clear()
                cur.execute("SELECT * FROM attack_patterns WHERE validation_status = 'VALIDATED'")
                for r in cur.fetchall():
                    d = dict(r)
                    d["features"] = json.loads(d["features_json"])
                    d["response_rule"] = json.loads(d["response_rule_json"])
                    self._fast_cache[d["fingerprint"]] = d
            finally:
                conn.close()
        _make_user_deletable(self.runtime_db_path)
        self.sync_to_usb()

    def lookup_validated_pattern(self, fingerprint: str, src_ip: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Checks if the user deleted the history file first; if not, performs O(1) Fast-Path lookup.
        """
        self._check_if_removed_and_recreate()
        now = time.time()
        with self._lock:
            cached = self._fast_cache.get(fingerprint)
            if cached and cached.get("validation_status") == "VALIDATED" and cached.get("expires_at", 0) > now:
                cached["hit_count"] = cached.get("hit_count", 1) + 1
                cached["last_seen_at"] = now
                conn = self._get_conn()
                try:
                    conn.execute(
                        "UPDATE attack_patterns SET hit_count = hit_count + 1, last_seen_at = ? WHERE fingerprint = ?",
                        (now, fingerprint),
                    )
                    conn.commit()
                finally:
                    conn.close()
                return dict(cached)
            return None

    def store_or_update_pattern(
        self,
        fingerprint: str,
        attack_category: str,
        src_ip: str,
        protocol: str,
        dst_port: int,
        features: Dict[str, float],
        evidence_summary: str,
        confidence: float,
        response_rule: Dict[str, Any],
        outcome: str = "VERIFIED_BLOCKED",
        validation_status: str = "VALIDATED",
        ttl_seconds: int = 86400 * 7,
    ) -> None:
        """Appends a new validated attack pattern (or updates hit count if already present) and syncs to disk."""
        self._check_if_removed_and_recreate()
        now = time.time()
        expires_at = now + ttl_seconds
        with self._lock:
            conn = self._get_conn()
            try:
                cur = conn.cursor()
                cur.execute("SELECT version, hit_count, created_at FROM attack_patterns WHERE fingerprint = ?", (fingerprint,))
                existing = cur.fetchone()
                if existing:
                    version = existing["version"] + 1
                    hit_count = existing["hit_count"] + 1
                    created_at = existing["created_at"]
                    cur.execute(
                        "UPDATE attack_patterns SET "
                        "attack_category = ?, sample_src_ip = ?, confidence = MAX(confidence, ?), "
                        "response_rule_json = ?, outcome = ?, validation_status = ?, "
                        "hit_count = ?, last_seen_at = ?, expires_at = ?, version = ? "
                        "WHERE fingerprint = ?",
                        (
                            attack_category,
                            src_ip,
                            confidence,
                            json.dumps(response_rule),
                            outcome,
                            validation_status,
                            hit_count,
                            now,
                            expires_at,
                            version,
                            fingerprint,
                        ),
                    )
                else:
                    version = 1
                    hit_count = 1
                    created_at = now
                    cur.execute(
                        "INSERT INTO attack_patterns ("
                        "fingerprint, attack_category, sample_src_ip, protocol, dst_port, "
                        "features_json, evidence_summary, confidence, response_rule_json, "
                        "outcome, validation_status, hit_count, created_at, last_seen_at, "
                        "expires_at, version"
                        ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, 1)",
                        (
                            fingerprint,
                            attack_category,
                            src_ip,
                            protocol,
                            dst_port,
                            json.dumps(features),
                            evidence_summary,
                            confidence,
                            json.dumps(response_rule),
                            outcome,
                            validation_status,
                            now,
                            now,
                            expires_at,
                        ),
                    )
                conn.commit()
                if validation_status == "VALIDATED":
                    self._fast_cache[fingerprint] = {
                        "fingerprint": fingerprint,
                        "attack_category": attack_category,
                        "sample_src_ip": src_ip,
                        "protocol": protocol,
                        "dst_port": dst_port,
                        "features": features,
                        "evidence_summary": evidence_summary,
                        "confidence": confidence,
                        "response_rule": response_rule,
                        "outcome": outcome,
                        "validation_status": validation_status,
                        "hit_count": hit_count,
                        "created_at": created_at,
                        "last_seen_at": now,
                        "expires_at": expires_at,
                        "version": version,
                    }
            finally:
                conn.close()
        self.sync_to_usb()

    def record_incident(
        self,
        event_id: str,
        src_ip: str,
        dst_ip: str,
        fingerprint: str,
        attack_category: str,
        decision_source: str,
        confidence: float,
        novelty_score: float,
        mitigation_action: str,
        rule_applied: str,
        verification_passed: bool,
        response_time_ms: float,
    ) -> None:
        """
        Appends an incident record to both SQLite (`attack_memory.db`), JSON (`attack_memory_snapshot.json`),
        and the human-readable append-only log (`data/attack_history.log`). Creates the files automatically if deleted.
        """
        self._check_if_removed_and_recreate()
        now = time.time()
        with self._lock:
            conn = self._get_conn()
            try:
                cur = conn.cursor()
                cur.execute(
                    "INSERT INTO incident_history ("
                    "event_id, timestamp, src_ip, dst_ip, fingerprint, "
                    "attack_category, decision_source, confidence, novelty_score, "
                    "mitigation_action, rule_applied, verification_passed, response_time_ms"
                    ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        event_id,
                        now,
                        src_ip,
                        dst_ip,
                        fingerprint,
                        attack_category,
                        decision_source,
                        confidence,
                        novelty_score,
                        mitigation_action,
                        rule_applied,
                        1 if verification_passed else 0,
                        response_time_ms,
                    ),
                )
                conn.commit()
            finally:
                conn.close()

        self.sync_to_usb()

        # Also append a single human-readable line to `data/attack_history.log`
        try:
            self._ensure_text_log_header()
            ts_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(now))
            log_line = (
                f"[{ts_str}] Event={event_id} | AttackerIP={src_ip} -> Target={dst_ip} | "
                f"Attack={attack_category} | Source={decision_source} | Confidence={confidence*100:.1f}% | "
                f"Action={mitigation_action} | Fingerprint={fingerprint} | Time={response_time_ms:.2f}ms\n"
            )
            with open(self.text_log_path, "a") as f:
                f.write(log_line)
            _make_user_deletable(self.text_log_path)
        except Exception:
            pass

    def invalidate_pattern(self, fingerprint: str, reason: str = "ROLLED_BACK") -> None:
        self._check_if_removed_and_recreate()
        with self._lock:
            self._fast_cache.pop(fingerprint, None)
            conn = self._get_conn()
            try:
                cur = conn.cursor()
                cur.execute(
                    "UPDATE attack_patterns SET validation_status = ?, outcome = ? WHERE fingerprint = ?",
                    ("ROLLED_BACK", reason, fingerprint),
                )
                conn.commit()
            finally:
                conn.close()
        self.sync_to_usb()

    def get_summary_stats(self) -> Dict[str, Any]:
        self._check_if_removed_and_recreate()
        with self._lock:
            conn = self._get_conn()
            try:
                cur = conn.cursor()
                cur.execute("SELECT COUNT(*) AS cnt, SUM(hit_count) AS total_hits FROM attack_patterns WHERE validation_status = 'VALIDATED'")
                p_row = cur.fetchone()
                cur.execute("SELECT COUNT(*) AS total_incidents, AVG(response_time_ms) AS avg_ms FROM incident_history")
                i_row = cur.fetchone()
                cur.execute(
                    "SELECT decision_source, COUNT(*) AS cnt, AVG(response_time_ms) AS avg_ms "
                    "FROM incident_history GROUP BY decision_source"
                )
                by_source = {r["decision_source"]: {"count": r["cnt"], "avg_response_ms": round(r["avg_ms"] or 0.0, 3)} for r in cur.fetchall()}
                return {
                    "validated_patterns_count": p_row["cnt"] or 0,
                    "total_pattern_hits": p_row["total_hits"] or 0,
                    "total_incidents_logged": i_row["total_incidents"] or 0,
                    "overall_avg_response_ms": round(i_row["avg_ms"] or 0.0, 3),
                    "breakdown_by_decision_source": by_source,
                    "was_auto_created": self.was_auto_created,
                    "history_files": {
                        "sqlite_db": self.usb_db_path,
                        "json_snapshot": self.json_mirror_path,
                        "text_log": self.text_log_path,
                    },
                }
            finally:
                conn.close()

    def list_validated_patterns(self) -> List[Dict[str, Any]]:
        self._check_if_removed_and_recreate()
        with self._lock:
            conn = self._get_conn()
            try:
                cur = conn.cursor()
                cur.execute("SELECT * FROM attack_patterns ORDER BY last_seen_at DESC")
                return [dict(r) for r in cur.fetchall()]
            finally:
                conn.close()

#!/usr/bin/env python3
"""
cyber_commander.py — Unified Autonomous AI Cyber Commander (v5.0)
Combines Prototype Gemini API + eBPF/XDP Architecture with USB Auto-Terminal & Multi-Vector Defense

Integrated Pipeline:
  Incoming Traffic / Detectors (Scapy + Raw ICMP/TCP + Socket DPI Ports 8080/8081/2222/53530 + /proc/net/snmp)
       ↓
  SecurityEvent / DetectorEvent
       ↓
  EventBus (`event_bus.py`)
       ↓
  AttackCorrelator (`attack_correlator.py` — 30s multi-vector correlation score)
       ↓
  DecisionEngine (`decision_engine.py`)
       ├── Known Attack in AttackMemory (`attack_history.json` / `attack_memory.db`)
       │        └── Immediate Fast-Path Block (Skips Gemini API)
       └── New / Unfamiliar Attack
                └── CyberDefenseAgent (`ai_agent.py` — Google Gemini API `block_ip` tool call
                    + Local 17-Class & Zero-Day Hybrid AI Engine fallback)
                         ↓
                    FirewallTools (`firewall_tools.py`)
                         ↓
                    FirewallManager (`firewall_manager.py` — eBPF/XDP `eBPF.c` + nftables/iptables)
                         ↓
                    Target Effect Shield Broadcaster (`127.0.0.1:9090` -> Stops target effects immediately!)
"""

import os
import sys
import math
import time
import json
import queue
import socket
import shutil
import sqlite3
import hashlib
import logging
import argparse
import threading
from datetime import datetime
from collections import Counter
from typing import Dict, Any, Optional, List

# Ensure both root, `cyber_commander/`, and `detectors/` are on sys.path
_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE) if os.path.basename(_HERE) == "cyber_commander" else _HERE
for _p in (_HERE, os.path.join(_ROOT, "cyber_commander"), os.path.join(_ROOT, "Autonomous_AI_Cyber_Commander_USB"), _ROOT):
    if os.path.isdir(_p):
        if _p in sys.path:
            sys.path.remove(_p)
        sys.path.insert(0, _p)
_det_p = os.path.join(_ROOT, "detectors")
if os.path.isdir(_det_p) and _det_p not in sys.path:
    sys.path.append(_det_p)

from event_schema import (
    DetectorEvent,
    CAT_BENIGN,
    CAT_SLOW_HTTP,
    CAT_DNS_TUNNELING,
    CAT_PORT_SCAN,
    CAT_BRUTE_FORCE,
    CAT_ICMP_PING_FLOOD,
    CAT_ZERO_DAY_ANOMALY,
)
from security_event import SecurityEvent
from event_bus import EventBus
from attack_correlator import AttackCorrelator
from firewall_manager import FirewallManager
from firewall_tools import FirewallTools
from ai_agent import CyberDefenseAgent, discover_gemini_api_key, discover_groq_api_key
from decision_engine import DecisionEngine
from ai_engine import CyberCommanderAIEngine
from firewall_enforcer import PolicyValidator, FirewallEnforcer, discover_host_network_identity
from terminal_dashboard import TerminalDashboard

import http_detector
import dns_detector
import port_scan_detector
import brute_force_detector
import multi_vector_detector

import importlib.util as _ilu
_lns_path = os.path.join(_ROOT, "live_network_sensor.py")
if not os.path.exists(_lns_path):
    _lns_path = os.path.join(_HERE, "live_network_sensor.py")
_lns_spec = _ilu.spec_from_file_location("live_network_sensor", _lns_path)
live_network_sensor = _ilu.module_from_spec(_lns_spec)
_lns_spec.loader.exec_module(live_network_sensor)

SHIELD_STATE_FILE = "/tmp/cyber_commander_shield.json"
BPF_SOURCE = os.path.join(_ROOT, "cyber_commander", "eBPF.c") if os.path.exists(os.path.join(_ROOT, "cyber_commander", "eBPF.c")) else os.path.join(_HERE, "eBPF.c")
INTERFACE = "enp0s8"


def _make_user_deletable(path: str, is_dir: bool = False) -> None:
    try:
        os.chmod(path, 0o777 if is_dir else 0o666)
    except Exception:
        pass


def _ensure_writable_dir(preferred_path: str, fallback_subdir: str) -> str:
    try:
        os.makedirs(preferred_path, exist_ok=True)
        _make_user_deletable(preferred_path, is_dir=True)
        test_file = os.path.join(preferred_path, ".write_test")
        with open(test_file, "w") as f:
            f.write("ok")
        os.remove(test_file)
        return preferred_path
    except Exception:
        fallback = os.path.join("/tmp/cyber_commander_runtime", fallback_subdir)
        os.makedirs(fallback, exist_ok=True)
        _make_user_deletable(fallback, is_dir=True)
        return fallback


def _upgrade_live_sensor_class() -> None:
    cls = getattr(live_network_sensor, "LiveNetworkSensor", None)
    if cls is None:
        return

    def _enhanced_udp_listener(self) -> None:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.settimeout(0.5)
        try:
            sock.bind(("0.0.0.0", self.udp_sensor_port))
        except Exception:
            return

        while not self.stop_event.is_set():
            try:
                data, addr = sock.recvfrom(8192)
            except socket.timeout:
                continue
            except Exception:
                break

            peer_ip = addr[0]
            counts = Counter(data)
            length = len(data)
            byte_ent = round(-sum((c / length) * math.log2(c / length) for c in counts.values()), 4) if length else 0.0
            text = data.decode("utf-8", errors="ignore")
            src_ip = self._extract_effective_src_ip(peer_ip, text)

            if text.startswith("KALI_UDP_FRAME:"):
                try:
                    frame = json.loads(text.split("KALI_UDP_FRAME:", 1)[1].strip())
                    self._process_kali_frame(frame, peer_ip)
                    ack = {
                        "cyber_commander_active": True,
                        "status": "BLOCKED_BY_CYBER_COMMANDER",
                        "pid": os.getpid(),
                    }
                    sock.sendto(json.dumps(ack).encode("utf-8"), addr)
                except Exception:
                    pass
                continue

            if "ICMP_FLOOD_TRIGGER:" in text:
                evt = self.mv_det.analyze_packet_or_flow({
                    "src_ip": src_ip if src_ip != "127.0.0.1" else "10.10.14.108",
                    "dst_ip": self.protected_ip,
                    "dst_port": 0,
                    "protocol": "ICMP",
                    "attack_hint": CAT_ICMP_PING_FLOOD,
                    "packets_per_sec": 1350.0,
                    "icmp_pps": 1300.0,
                    "bytes_per_pkt": 1472.0,
                    "payload_byte_entropy": 2.6,
                })
                if evt:
                    evt.process_details = f"ICMP Echo Ping Flood detected from attacker IP {evt.src_ip} (1,300 ICMP packets/sec)"
                    self.event_queue.put(evt)
            elif "DNS_QUERY:" in text:
                qname = text.split("DNS_QUERY:", 1)[1].splitlines()[0].strip()
                evt = self.dns_det.analyze_dns_activity({
                    "src_ip": src_ip,
                    "dst_ip": self.protected_ip,
                    "dst_port": 53,
                    "query_name": qname,
                    "dns_qps": 45.0,
                    "packets_per_sec": 55.0,
                })
                if evt:
                    evt.process_details = f"Live UDP:{self.udp_sensor_port} DNS tunnel payload from {src_ip}: {qname[:55]}"
                    self.event_queue.put(evt)
            elif byte_ent >= 7.1 or len(data) >= 900:
                evt = self.mv_det.analyze_packet_or_flow({
                    "src_ip": src_ip if src_ip != "127.0.0.1" else "10.10.14.99",
                    "dst_ip": self.protected_ip,
                    "dst_port": self.udp_sensor_port,
                    "protocol": "UDP",
                    "attack_hint": CAT_ZERO_DAY_ANOMALY,
                    "packets_per_sec": 1950.0,
                    "bytes_per_pkt": float(max(1250, len(data))),
                    "conn_rate_per_sec": 450.0,
                    "concurrent_conns": 220.0,
                    "request_completion_ratio": 0.05,
                    "unique_dst_ports": 8.0,
                    "syn_to_ack_ratio": 16.0,
                    "payload_byte_entropy": max(7.82, byte_ent),
                })
                if evt:
                    evt.process_details = f"Live UDP:{self.udp_sensor_port} high-entropy ({byte_ent:.2f} bits/B) polymorphic zero-day payload from {evt.src_ip}"
                    self.event_queue.put(evt)
        sock.close()

    cls._run_udp_dns_and_zeroday_listener = _enhanced_udp_listener


_upgrade_live_sensor_class()


class AttackMemoryDB:
    """
    Unified Attack History & Fast-Path Memory Engine (Supports both Prototype `AttackMemory`
    methods `lookup()` / `record()` / `display_history()` AND SQLite `AttackMemoryDB` methods!).
    - If `attack_history.json`, `data/attack_history.log`, or `data/attack_memory.db` is deleted by
      the user (before or during execution), it automatically recreates the files from scratch!
    - If the files exist, it loads the existing records and appends new attacks.
    """

    def __init__(self, db_path: str = "data/attack_memory.db", json_filename: Optional[str] = None):
        self.usb_db_path = os.path.abspath(db_path)
        self.data_dir = os.path.dirname(self.usb_db_path)
        self.json_mirror_path = os.path.join(self.data_dir, "attack_memory_snapshot.json")
        self.text_log_path = os.path.join(self.data_dir, "attack_history.log")
        self.proto_json_path = json_filename or os.path.join(os.path.dirname(self.data_dir), "attack_history.json")

        os.makedirs(self.data_dir, exist_ok=True)
        _make_user_deletable(self.data_dir, is_dir=True)

        path_hash = hashlib.md5(self.usb_db_path.encode("utf-8")).hexdigest()[:10]
        self.runtime_db_path = f"/tmp/cyber_cmd_memory_{path_hash}.db"

        self._lock = threading.Lock()
        self._fast_cache: Dict[str, Dict[str, Any]] = {}
        self.history: Dict[str, Dict[str, Any]] = {}
        self.was_auto_created: bool = False

        db_exists = os.path.exists(self.usb_db_path) and os.path.getsize(self.usb_db_path) > 0
        json_exists = os.path.exists(self.json_mirror_path) and os.path.getsize(self.json_mirror_path) > 0
        log_exists = os.path.exists(self.text_log_path)

        if not db_exists or (db_exists and (not json_exists or not log_exists)):
            self.was_auto_created = True
            for p in (self.runtime_db_path, self.usb_db_path, self.json_mirror_path, self.text_log_path, self.proto_json_path):
                try:
                    if os.path.exists(p):
                        os.remove(p)
                except Exception:
                    pass
        else:
            try:
                shutil.copyfile(self.usb_db_path, self.runtime_db_path)
                _make_user_deletable(self.runtime_db_path)
            except Exception:
                pass
            if os.path.exists(self.proto_json_path):
                try:
                    with open(self.proto_json_path, "r") as f:
                        self.history = json.load(f)
                except Exception:
                    self.history = {}

        self._init_db()

    def _get_conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.runtime_db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn

    def _check_if_removed_and_recreate(self) -> bool:
        os.makedirs(self.data_dir, exist_ok=True)
        _make_user_deletable(self.data_dir, is_dir=True)

        missing_any = (
            not os.path.exists(self.usb_db_path)
            or not os.path.exists(self.json_mirror_path)
            or not os.path.exists(self.text_log_path)
        )
        if not missing_any:
            return False

        with self._lock:
            self._fast_cache.clear()
            self.history.clear()
            self.was_auto_created = True
            try:
                if os.path.exists(self.runtime_db_path):
                    os.remove(self.runtime_db_path)
            except Exception:
                pass
            conn = self._get_conn()
            try:
                cur = conn.cursor()
                cur.execute("DROP TABLE IF EXISTS attack_patterns")
                cur.execute("DROP TABLE IF EXISTS incident_history")
                conn.commit()
            except Exception:
                pass
            finally:
                conn.close()

        self._init_db()
        return True

    def _ensure_text_log_header(self) -> None:
        if not os.path.exists(self.text_log_path) or os.path.getsize(self.text_log_path) == 0:
            try:
                with open(self.text_log_path, "w") as f:
                    f.write("# ==============================================================================\n")
                    f.write("# AUTONOMOUS AI CYBER COMMANDER — PERSISTENT ATTACK HISTORY LOG\n")
                    f.write("# You may delete this file (or data/attack_memory.db) at any time to reset history.\n")
                    f.write("# Cyber Commander will automatically recreate it and append new attacks.\n")
                    f.write("# ==============================================================================\n")
                _make_user_deletable(self.text_log_path)
            except Exception:
                pass

    def sync_to_usb(self) -> None:
        os.makedirs(self.data_dir, exist_ok=True)
        _make_user_deletable(self.data_dir, is_dir=True)
        with self._lock:
            conn = self._get_conn()
            try:
                shutil.copyfile(self.runtime_db_path, self.usb_db_path)
                _make_user_deletable(self.usb_db_path)
                cur = conn.cursor()
                cur.execute("SELECT * FROM attack_patterns ORDER BY last_seen_at DESC")
                patterns = [dict(r) for r in cur.fetchall()]
                cur.execute("SELECT * FROM incident_history ORDER BY incident_id DESC LIMIT 500")
                incidents = [dict(r) for r in cur.fetchall()]
                with open(self.json_mirror_path, "w") as f:
                    json.dump(
                        {
                            "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                            "total_validated_patterns": len(patterns),
                            "total_incidents_recorded": len(incidents),
                            "attack_patterns": patterns,
                            "recent_incidents": incidents,
                        },
                        f,
                        indent=2,
                    )
                _make_user_deletable(self.json_mirror_path)
                with open(self.proto_json_path, "w") as f:
                    json.dump(self.history, f, indent=4)
                _make_user_deletable(self.proto_json_path)
            except Exception:
                pass
            finally:
                conn.close()
        self._ensure_text_log_header()

    def _init_db(self) -> None:
        with self._lock:
            conn = self._get_conn()
            try:
                cur = conn.cursor()
                cur.execute(
                    "CREATE TABLE IF NOT EXISTS attack_patterns ("
                    "fingerprint TEXT PRIMARY KEY, "
                    "attack_category TEXT NOT NULL, "
                    "sample_src_ip TEXT, "
                    "protocol TEXT, "
                    "dst_port INTEGER, "
                    "features_json TEXT NOT NULL, "
                    "evidence_summary TEXT, "
                    "confidence REAL NOT NULL, "
                    "response_rule_json TEXT NOT NULL, "
                    "outcome TEXT DEFAULT 'PENDING', "
                    "validation_status TEXT DEFAULT 'PROVISIONAL', "
                    "hit_count INTEGER DEFAULT 1, "
                    "created_at REAL NOT NULL, "
                    "last_seen_at REAL NOT NULL, "
                    "expires_at REAL NOT NULL, "
                    "version INTEGER DEFAULT 1)"
                )
                cur.execute(
                    "CREATE TABLE IF NOT EXISTS incident_history ("
                    "incident_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    "event_id TEXT NOT NULL, "
                    "timestamp REAL NOT NULL, "
                    "src_ip TEXT NOT NULL, "
                    "dst_ip TEXT NOT NULL, "
                    "fingerprint TEXT NOT NULL, "
                    "attack_category TEXT NOT NULL, "
                    "decision_source TEXT NOT NULL, "
                    "confidence REAL NOT NULL, "
                    "novelty_score REAL DEFAULT 0.0, "
                    "mitigation_action TEXT NOT NULL, "
                    "rule_applied TEXT NOT NULL, "
                    "verification_passed INTEGER DEFAULT 0, "
                    "response_time_ms REAL DEFAULT 0.0)"
                )
                conn.commit()

                self._fast_cache.clear()
                cur.execute("SELECT * FROM attack_patterns WHERE validation_status = 'VALIDATED'")
                for r in cur.fetchall():
                    d = dict(r)
                    d["features"] = json.loads(d["features_json"])
                    d["response_rule"] = json.loads(d["response_rule_json"])
                    self._fast_cache[d["fingerprint"]] = d
                    key = f"{d.get('sample_src_ip', '0.0.0.0')}|{d['attack_category']}"
                    if key not in self.history:
                        self.history[key] = {
                            "source_ip": d.get("sample_src_ip", "0.0.0.0"),
                            "event_type": d["attack_category"],
                            "first_seen": datetime.fromtimestamp(d["created_at"]).isoformat(),
                            "last_seen": datetime.fromtimestamp(d["last_seen_at"]).isoformat(),
                            "count": d["hit_count"],
                            "last_action": "AI_BLOCK",
                            "duration": d["response_rule"].get("ttl_sec", 1800),
                            "reason": d.get("evidence_summary", "Validated block"),
                            "enforce_on_repeat": True,
                        }
            finally:
                conn.close()
        _make_user_deletable(self.runtime_db_path)
        self.sync_to_usb()

    # --- Prototype AttackMemory API (`lookup`, `record`, `display_history`) ---
    def lookup(self, source_ip: str, event_type: str) -> Optional[Dict[str, Any]]:
        self._check_if_removed_and_recreate()
        key = f"{source_ip}|{event_type}"
        with self._lock:
            rec = self.history.get(key)
            if rec and rec.get("enforce_on_repeat", False):
                return rec.copy()
            for k, r in self.history.items():
                if k.endswith(f"|{event_type}") and r.get("enforce_on_repeat", False):
                    return r.copy()
        return None

    def record(self, event, action: str, duration: Optional[int] = None, reason: Optional[str] = None, enforce_on_repeat: bool = False) -> None:
        self._check_if_removed_and_recreate()
        src_ip = getattr(event, "source_ip", None) or getattr(event, "src_ip", "0.0.0.0")
        ev_type = getattr(event, "event_type", None) or getattr(event, "suspected_category", "UNKNOWN")
        key = f"{src_ip}|{ev_type}"
        now_iso = datetime.now().isoformat()
        with self._lock:
            if key not in self.history:
                self.history[key] = {
                    "source_ip": src_ip,
                    "event_type": ev_type,
                    "first_seen": now_iso,
                    "last_seen": now_iso,
                    "count": 0,
                    "last_action": action,
                    "duration": duration,
                    "reason": reason,
                    "enforce_on_repeat": enforce_on_repeat,
                }
            rec = self.history[key]
            rec["last_seen"] = now_iso
            rec["count"] += 1
            rec["last_action"] = action
            rec["duration"] = duration
            rec["reason"] = reason
            if enforce_on_repeat:
                rec["enforce_on_repeat"] = True
        self.sync_to_usb()

    def display_history(self) -> None:
        self._check_if_removed_and_recreate()
        print("\n" + "=" * 70)
        print("                 ATTACK HISTORY")
        print("=" * 70)
        if not self.history and not self._fast_cache:
            print("No stored attacks.")
            print("=" * 70)
            return
        for key, record in self.history.items():
            print(f"\nKey               : {key}")
            print(f"First seen        : {record.get('first_seen')}")
            print(f"Last seen         : {record.get('last_seen')}")
            print(f"Occurrences       : {record.get('count')}")
            print(f"Last action       : {record.get('last_action')}")
            print(f"Duration          : {record.get('duration')}")
            print(f"Enforce repeat    : {record.get('enforce_on_repeat')}")
            print(f"Reason            : {record.get('reason')}")
        print("=" * 70)

    # --- SQLite AttackMemoryDB API ---
    def lookup_validated_pattern(self, fingerprint: str, src_ip: Optional[str] = None) -> Optional[Dict[str, Any]]:
        self._check_if_removed_and_recreate()
        now = time.time()
        with self._lock:
            cached = self._fast_cache.get(fingerprint)
            if cached and cached.get("validation_status") == "VALIDATED" and cached.get("expires_at", 0) > now:
                cached["hit_count"] = cached.get("hit_count", 1) + 1
                cached["last_seen_at"] = now
                conn = self._get_conn()
                try:
                    conn.execute(
                        "UPDATE attack_patterns SET hit_count = hit_count + 1, last_seen_at = ? WHERE fingerprint = ?",
                        (now, fingerprint),
                    )
                    conn.commit()
                finally:
                    conn.close()
                return dict(cached)
            return None

    def store_or_update_pattern(
        self,
        fingerprint: str,
        attack_category: str,
        src_ip: str,
        protocol: str,
        dst_port: int,
        features: Dict[str, float],
        evidence_summary: str,
        confidence: float,
        response_rule: Dict[str, Any],
        outcome: str = "VERIFIED_BLOCKED",
        validation_status: str = "VALIDATED",
        ttl_seconds: int = 86400 * 7,
    ) -> None:
        self._check_if_removed_and_recreate()
        now = time.time()
        expires_at = now + ttl_seconds
        now_iso = datetime.now().isoformat()
        with self._lock:
            conn = self._get_conn()
            try:
                cur = conn.cursor()
                cur.execute("SELECT version, hit_count, created_at FROM attack_patterns WHERE fingerprint = ?", (fingerprint,))
                existing = cur.fetchone()
                if existing:
                    version = existing["version"] + 1
                    hit_count = existing["hit_count"] + 1
                    created_at = existing["created_at"]
                    cur.execute(
                        "UPDATE attack_patterns SET "
                        "attack_category = ?, sample_src_ip = ?, confidence = MAX(confidence, ?), "
                        "response_rule_json = ?, outcome = ?, validation_status = ?, "
                        "hit_count = ?, last_seen_at = ?, expires_at = ?, version = ? "
                        "WHERE fingerprint = ?",
                        (
                            attack_category,
                            src_ip,
                            confidence,
                            json.dumps(response_rule),
                            outcome,
                            validation_status,
                            hit_count,
                            now,
                            expires_at,
                            version,
                            fingerprint,
                        ),
                    )
                else:
                    version = 1
                    hit_count = 1
                    created_at = now
                    cur.execute(
                        "INSERT INTO attack_patterns ("
                        "fingerprint, attack_category, sample_src_ip, protocol, dst_port, "
                        "features_json, evidence_summary, confidence, response_rule_json, "
                        "outcome, validation_status, hit_count, created_at, last_seen_at, "
                        "expires_at, version"
                        ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, 1)",
                        (
                            fingerprint,
                            attack_category,
                            src_ip,
                            protocol,
                            dst_port,
                            json.dumps(features),
                            evidence_summary,
                            confidence,
                            json.dumps(response_rule),
                            outcome,
                            validation_status,
                            now,
                            now,
                            expires_at,
                        ),
                    )
                conn.commit()
                if validation_status == "VALIDATED":
                    self._fast_cache[fingerprint] = {
                        "fingerprint": fingerprint,
                        "attack_category": attack_category,
                        "sample_src_ip": src_ip,
                        "protocol": protocol,
                        "dst_port": dst_port,
                        "features": features,
                        "evidence_summary": evidence_summary,
                        "confidence": confidence,
                        "response_rule": response_rule,
                        "outcome": outcome,
                        "validation_status": validation_status,
                        "hit_count": hit_count,
                        "created_at": created_at,
                        "last_seen_at": now,
                        "expires_at": expires_at,
                        "version": version,
                    }
                    h_key = f"{src_ip}|{attack_category}"
                    self.history[h_key] = {
                        "source_ip": src_ip,
                        "event_type": attack_category,
                        "first_seen": datetime.fromtimestamp(created_at).isoformat(),
                        "last_seen": now_iso,
                        "count": hit_count,
                        "last_action": response_rule.get("action", "AI_BLOCK"),
                        "duration": response_rule.get("ttl_sec", 1800),
                        "reason": evidence_summary,
                        "enforce_on_repeat": True,
                    }
            finally:
                conn.close()
        self.sync_to_usb()

    def record_incident(
        self,
        event_id: str,
        src_ip: str,
        dst_ip: str,
        fingerprint: str,
        attack_category: str,
        decision_source: str,
        confidence: float,
        novelty_score: float,
        mitigation_action: str,
        rule_applied: str,
        verification_passed: bool,
        response_time_ms: float,
    ) -> None:
        self._check_if_removed_and_recreate()
        now = time.time()
        with self._lock:
            conn = self._get_conn()
            try:
                cur = conn.cursor()
                cur.execute(
                    "INSERT INTO incident_history ("
                    "event_id, timestamp, src_ip, dst_ip, fingerprint, "
                    "attack_category, decision_source, confidence, novelty_score, "
                    "mitigation_action, rule_applied, verification_passed, response_time_ms"
                    ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        event_id,
                        now,
                        src_ip,
                        dst_ip,
                        fingerprint,
                        attack_category,
                        decision_source,
                        confidence,
                        novelty_score,
                        mitigation_action,
                        rule_applied,
                        1 if verification_passed else 0,
                        response_time_ms,
                    ),
                )
                conn.commit()
            finally:
                conn.close()

        self.sync_to_usb()

        try:
            self._ensure_text_log_header()
            ts_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(now))
            log_line = (
                f"[{ts_str}] Event={event_id} | AttackerIP={src_ip} -> Target={dst_ip} | "
                f"Attack={attack_category} | Source={decision_source} | Confidence={confidence*100:.1f}% | "
                f"Action={mitigation_action} | Fingerprint={fingerprint} | Time={response_time_ms:.2f}ms\n"
            )
            with open(self.text_log_path, "a") as f:
                f.write(log_line)
            _make_user_deletable(self.text_log_path)
        except Exception:
            pass

    def get_summary_stats(self) -> Dict[str, Any]:
        self._check_if_removed_and_recreate()
        with self._lock:
            conn = self._get_conn()
            try:
                cur = conn.cursor()
                cur.execute("SELECT COUNT(*) AS cnt, SUM(hit_count) AS total_hits FROM attack_patterns WHERE validation_status = 'VALIDATED'")
                p_row = cur.fetchone()
                cur.execute("SELECT COUNT(*) AS total_incidents, AVG(response_time_ms) AS avg_ms FROM incident_history")
                i_row = cur.fetchone()
                cur.execute(
                    "SELECT decision_source, COUNT(*) AS cnt, AVG(response_time_ms) AS avg_ms "
                    "FROM incident_history GROUP BY decision_source"
                )
                by_source = {r["decision_source"]: {"count": r["cnt"], "avg_response_ms": round(r["avg_ms"] or 0.0, 3)} for r in cur.fetchall()}
                return {
                    "validated_patterns_count": p_row["cnt"] or 0,
                    "total_pattern_hits": p_row["total_hits"] or 0,
                    "total_incidents_logged": i_row["total_incidents"] or 0,
                    "overall_avg_response_ms": round(i_row["avg_ms"] or 0.0, 3),
                    "breakdown_by_decision_source": by_source,
                    "was_auto_created": self.was_auto_created,
                }
            finally:
                conn.close()


class CyberCommander:
    """
    Unified Autonomous AI Cyber Commander (v5.0):
    Integrates the user's Prototype architecture (`FirewallManager`, `FirewallTools`,
    `CyberDefenseAgent` with Gemini API, `AttackMemory`, `DecisionEngine`, `EventBus`,
    `AttackCorrelator`, and Scapy `detectors/*`) with the Plug-and-Play USB Terminal
    Dashboard, 17-Class + Zero-Day AI Engine, and Target System Effect Shield Broadcaster.
    """

    def __init__(
        self,
        base_dir: Optional[str] = None,
        show_terminal_ui: bool = True,
        reset_history: bool = False,
    ):
        self.base_dir = base_dir or _ROOT
        self.data_dir = _ensure_writable_dir(os.path.join(self.base_dir, "data"), "data")
        self.models_dir = os.path.join(self.base_dir, "models")
        self.logs_dir = _ensure_writable_dir(os.path.join(self.base_dir, "logs"), "logs")

        if reset_history:
            for fname in ("attack_memory.db", "attack_memory_snapshot.json", "attack_history.log", "active_firewall_rules.json", "attack_history.json"):
                for d in (self.data_dir, self.base_dir, "/tmp/cyber_commander_runtime/data"):
                    p = os.path.join(d, fname)
                    try:
                        if os.path.exists(p):
                            os.remove(p)
                    except Exception:
                        pass

        self.show_terminal_ui = show_terminal_ui
        self.dashboard = TerminalDashboard(use_color=True)

        self.log_path = os.path.join(self.logs_dir, "cyber_commander.log")
        self.logger = logging.getLogger("CyberCommander")
        self.logger.setLevel(logging.INFO)
        self.logger.handlers.clear()
        try:
            fh = logging.FileHandler(self.log_path)
            fmt = logging.Formatter("[%(asctime)s] [PID:%(process)d] [%(levelname)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
            fh.setFormatter(fmt)
            self.logger.addHandler(fh)
        except Exception:
            pass

        self.host_identity = discover_host_network_identity()
        self.protected_ip = self.host_identity["primary_ip"]
        self.primary_iface = self.host_identity["primary_iface"]

        # 1. Initialize Prototype + USB Unified Components
        self.memory_db = AttackMemoryDB(
            db_path=os.path.join(self.data_dir, "attack_memory.db"),
            json_filename=os.path.join(self.base_dir, "attack_history.json"),
        )
        self.attack_memory = self.memory_db

        model_file = os.path.join(self.models_dir, "cyber_commander_model.json")
        if not os.access(self.models_dir, os.W_OK) and not os.path.exists(model_file):
            model_file = os.path.join(_ensure_writable_dir(self.models_dir, "models"), "cyber_commander_model.json")
        self.ai_engine = CyberCommanderAIEngine(model_path=model_file)
        self.policy_validator = PolicyValidator(protected_allowlist=self.host_identity["protected_allowlist"])
        self.enforcer = FirewallEnforcer(
            state_file=os.path.join(self.data_dir, "active_firewall_rules.json"),
            interface=self.primary_iface,
        )

        # Prototype eBPF/XDP FirewallManager, FirewallTools, Gemini CyberDefenseAgent, DecisionEngine, EventBus & AttackCorrelator
        self.firewall = FirewallManager(
            bpf_source=BPF_SOURCE,
            interface=self.primary_iface,
            state_file=os.path.join(self.data_dir, "active_firewall_rules.json"),
        )
        self.firewall_tools = FirewallTools(self.firewall)
        self.ai_agent = CyberDefenseAgent(self.firewall_tools)
        self.decision_engine = DecisionEngine(
            ai_agent=self.ai_agent,
            firewall_tools=self.firewall_tools,
            attack_memory=self.attack_memory,
        )
        self.event_bus = EventBus()
        self.correlator = AttackCorrelator()

        self.event_queue: queue.Queue = queue.Queue()
        self.stop_event = threading.Event()
        self.detector_threads: List[threading.Thread] = []
        self.last_mitigation_action: str = "FIREWALL_AND_XDP_ACTIVE_SHIELD"
        self.last_attack_category: str = "ACTIVE_GUARD"
        self.blocked_ips_set = set(self.enforcer.active_rules.keys())

        self._broadcast_shield_state(active=True)

        self.logger.info(
            f"CyberCommander v5.0 initialized | PID={os.getpid()} | Protected IP={self.protected_ip} "
            f"| Interface={self.primary_iface} | Backend={self.enforcer.backend} | GeminiReady={self.ai_agent.client is not None}"
        )

    PROTO_CATEGORY_MAP = {
        "SYN_FLOOD": "SYN_FLOOD_DDOS",
        "ICMP_FLOOD": "ICMP_PING_FLOOD",
        "HTTP_FLOOD": "HTTP_L7_FLOOD",
        "ARP_SPOOFING": "ARP_MITM_SPOOFING",
        "DNS_REBINDING": "DNS_TUNNELING",
        "HTTP_SMUGGLING": "XSS_AND_WEB_INJECTION",
        "TCP_FIN_SCAN": "PORT_SCAN",
        "IP_FRAGMENTATION": "LAND_AND_IP_FRAGMENT_ATTACK",
    }

    def publish_event(self, sec_event: SecurityEvent) -> None:
        """
        Prototype entry point called by Scapy detectors in `detectors/*`.
        Converts `SecurityEvent` into `DetectorEvent` and places it onto `self.event_queue`
        AND `self.event_bus` so both the Prototype Correlator/Gemini Agent and the Live Terminal UI process it!
        """
        self.event_bus.publish(sec_event)
        mapped_cat = self.PROTO_CATEGORY_MAP.get(sec_event.event_type, sec_event.event_type)
        evt = DetectorEvent(
            detector_name="prototype_scapy_detector",
            src_ip=sec_event.source_ip,
            dst_ip=sec_event.target_ip,
            dst_port=sec_event.service_port,
            protocol=getattr(sec_event, "protocol", "TCP"),
            suspected_category=mapped_cat,
            detector_confidence=sec_event.confidence,
            severity="CRITICAL" if sec_event.confidence >= 0.90 else "HIGH",
            features={
                "packets_per_sec": float(max(60, sec_event.failed_attempts * 10)),
                "unique_dst_ports": float(sec_event.unique_ports),
                "concurrent_conns": float(sec_event.connection_count),
                "auth_failures_per_min": float(sec_event.failed_attempts * 6),
            },
            evidence_summary=f"{sec_event.event_type} from {sec_event.source_ip} (confidence={sec_event.confidence})",
            process_details=getattr(sec_event, "process_details", "") or f"Scapy Detector captured {sec_event.event_type} from {sec_event.source_ip}",
        )
        self.event_queue.put(evt)

    def _broadcast_shield_state(self, active: bool = True, latest_ip: str = "", latest_action: str = "", latest_cat: str = "") -> None:
        if latest_ip:
            self.blocked_ips_set.add(latest_ip)
        if latest_action and latest_action != "NONE":
            self.last_mitigation_action = latest_action
        if latest_cat:
            self.last_attack_category = latest_cat

        merged_rules = dict(self.enforcer.active_rules)
        merged_rules.update(self.firewall.active_rules)

        state_payload = {
            "active": active,
            "pid": os.getpid(),
            "timestamp": time.time(),
            "protected_ip": self.protected_ip,
            "backend": self.enforcer.backend,
            "last_mitigation_action": self.last_mitigation_action,
            "last_attack_category": self.last_attack_category,
            "blocked_ips": sorted(list(self.blocked_ips_set)),
            "active_rules": merged_rules,
        }

        for path in (SHIELD_STATE_FILE, "/tmp/cyber_commander_runtime/data/active_firewall_rules.json"):
            try:
                os.makedirs(os.path.dirname(path), exist_ok=True)
                content = state_payload if path == SHIELD_STATE_FILE else merged_rules
                with open(path, "w") as f:
                    json.dump(content, f, indent=2)
                os.chmod(path, 0o666)
            except Exception:
                pass

        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            msg = ("CYBER_CMD_SHIELD:" + json.dumps(state_payload) + "\n").encode("utf-8")
            s.sendto(msg, ("127.0.0.1", 9090))
            s.close()
        except Exception:
            pass

    def _start_shield_broadcaster_thread(self) -> threading.Thread:
        def _broadcaster():
            while not self.stop_event.is_set():
                self._broadcast_shield_state(active=True)
                self.stop_event.wait(0.4)
            self._broadcast_shield_state(active=False)

        t = threading.Thread(target=_broadcaster, name="shield_broadcaster_thread", daemon=True)
        t.start()
        return t

    def start_all_detectors(self, poll_interval: float = 1.0) -> None:
        cfg = {"protected_ip": self.protected_ip, "poll_interval": poll_interval}
        modules = [
            ("http_detector", http_detector.start_detector),
            ("dns_detector", dns_detector.start_detector),
            ("port_scan_detector", port_scan_detector.start_detector),
            ("brute_force_detector", brute_force_detector.start_detector),
            ("multi_vector_detector", multi_vector_detector.start_detector),
            ("live_network_sensor", live_network_sensor.start_detector),
        ]
        self.detector_threads.clear()
        for name, starter_fn in modules:
            t = starter_fn(self.event_queue, self.stop_event, cfg)
            self.detector_threads.append(t)
            self.logger.info(f"Started detector process thread: {name} (thread={t.name})")

        # Also start the Prototype Port 8081 HTTP Auth Trap & Scapy Detectors from `detectors/`
        try:
            det_dir = os.path.join(_ROOT, "detectors")
            if os.path.isdir(det_dir):
                for mod_file, thread_name in [
                    ("brute_force_detector.py", "proto_brute_force_8081"),
                    ("dns_tunnel_detector.py", "proto_dns_tunnel_scapy"),
                    ("slow_http_detector.py", "proto_slow_http_scapy"),
                ]:
                    mod_p = os.path.join(det_dir, mod_file)
                    if os.path.exists(mod_p):
                        spec = _ilu.spec_from_file_location(thread_name, mod_p)
                        mod = _ilu.module_from_spec(spec)
                        spec.loader.exec_module(mod)
                        t_p = threading.Thread(target=mod.start_detector, args=(self,), name=thread_name, daemon=True)
                        t_p.start()
        except Exception:
            pass

        self._start_shield_broadcaster_thread()

        if self.show_terminal_ui:
            self.dashboard.print_startup_banner(
                pid=os.getpid(),
                host_identity=self.host_identity,
                backend=f"{self.enforcer.backend} + Gemini AI Agent",
                memory_stats=self.memory_db.get_summary_stats(),
                ai_metrics=self.ai_engine.model_data.get("validation_metrics", {}),
                detector_threads=self.detector_threads,
            )

    def process_event(self, event: DetectorEvent, scenario_label: str = "") -> Dict[str, Any]:
        t_start = time.perf_counter()
        orig_src_ip = event.src_ip

        is_simulated = (
            "Simulated" in (event.process_details or "")
            or "Kali" in (event.process_details or "")
            or event.detector_name in ("live_network_sensor", "multi_vector_detector", "http_detector", "dns_detector", "port_scan_detector", "brute_force_detector", "prototype_scapy_detector")
        )
        effective_src_ip = orig_src_ip
        if is_simulated and orig_src_ip in self.policy_validator.allowlist and not scenario_label.startswith("Safeguard"):
            effective_src_ip = "10.10.14.99"

        # Check if user deleted the attack history file while running -> auto-recreate!
        self.memory_db._check_if_removed_and_recreate()

        # Run AttackCorrelator from prototype
        sec_ev = SecurityEvent(
            event_type=event.suspected_category,
            source_ip=orig_src_ip,
            target_ip=event.dst_ip,
            service_port=event.dst_port,
            confidence=event.detector_confidence,
            protocol=event.protocol,
            evidence=event.features,
            process_details=event.process_details,
        )
        correlation = self.correlator.add_event(sec_ev)

        fingerprint = event.compute_fingerprint(include_src_ip=False)
        pps = float(event.features.get("packets_per_sec", 10.0))

        # Step 1: Check Attack Memory Fast-Path first
        cached_pattern = self.memory_db.lookup_validated_pattern(fingerprint, src_ip=effective_src_ip)
        if cached_pattern is not None:
            decision_source = "STATIC_MEMORY_FASTPATH"
            attack_category = cached_pattern["attack_category"]
            confidence = float(cached_pattern["confidence"])
            novelty_score = 0.0
            cached_rule = cached_pattern["response_rule"]
            explanation = (
                f"Attack History Fast-Path Hit (fingerprint={fingerprint}, hits={cached_pattern['hit_count']}): "
                f"Reusing validated '{attack_category}' mitigation rule immediately (Skipped Gemini API)."
            )
        else:
            # Step 2: Classify via Hybrid AI + optionally invoke Gemini API Function Calling if client is configured
            ai_result = self.ai_engine.classify_event(event)
            attack_category = ai_result["predicted_category"]
            if attack_category == "UNCERTAIN" and event.suspected_category and event.suspected_category != "UNCERTAIN":
                attack_category = event.suspected_category
            decision_source = ai_result["classification_type"]
            confidence = max(float(ai_result["confidence"]), float(event.detector_confidence))
            novelty_score = float(ai_result["novelty_score"])
            cached_rule = None
            explanation = ai_result["explanation"]

            # If live Gemini API key is configured and this is a new non-benign attack, consult CyberDefenseAgent
            if (self.ai_agent.client is not None or self.ai_agent.api_key or getattr(self.ai_agent, "groq_api_key", None)) and attack_category != CAT_BENIGN:
                try:
                    sec_ev.event_type = attack_category
                    sec_ev.confidence = confidence
                    gem_res = self.ai_agent.analyze_event(sec_ev, correlation)
                    if isinstance(gem_res, dict) and gem_res.get("reason"):
                        explanation = f"[Gemini AI] {gem_res.get('reason')}"
                except Exception:
                    pass

        approved, policy_reason, rule_spec = self.policy_validator.validate_and_build_rule(
            src_ip=effective_src_ip,
            dst_ip=event.dst_ip,
            protocol=event.protocol,
            dst_port=event.dst_port,
            attack_category=attack_category,
            classification_type=decision_source,
            confidence=confidence,
            packets_per_sec=pps,
            cached_rule=cached_rule,
        )

        verification_info = {"verified": False, "status": "NOT_APPLICABLE"}
        mitigation_action = rule_spec.get("action", "NONE") if rule_spec else "NONE"
        rule_cmd_summary = "NONE"

        if approved and rule_spec:
            enforce_res = self.enforcer.apply_rule(rule_spec)
            rule_rec = enforce_res["rule_record"]
            rule_cmd_summary = rule_rec["commands"]["nftables_cmd"]
            verification_info = self.enforcer.verify_mitigation(effective_src_ip, post_attack_pps_drop_ratio=0.99)

            # Also update prototype eBPF/XDP FirewallManager map
            try:
                self.firewall.block_ip(
                    effective_src_ip,
                    duration=int(rule_spec.get("ttl_sec", 1800)),
                    reason=explanation,
                    attack_category=attack_category,
                )
            except Exception:
                pass

            if orig_src_ip != effective_src_ip:
                self.enforcer.active_rules[orig_src_ip] = dict(rule_rec)
                self.enforcer._save_state()

            self._broadcast_shield_state(
                active=True,
                latest_ip=orig_src_ip,
                latest_action=mitigation_action,
                latest_cat=attack_category,
            )

            if decision_source != "STATIC_MEMORY_FASTPATH" and verification_info.get("verified") and confidence >= 0.65:
                self.memory_db.store_or_update_pattern(
                    fingerprint=fingerprint,
                    attack_category=attack_category,
                    src_ip=orig_src_ip,
                    protocol=event.protocol,
                    dst_port=event.dst_port,
                    features=event.features,
                    evidence_summary=event.evidence_summary or explanation,
                    confidence=confidence,
                    response_rule=rule_spec,
                    outcome="VERIFIED_BLOCKED",
                    validation_status="VALIDATED",
                )

        elapsed_ms = round((time.perf_counter() - t_start) * 1000.0, 3)

        self.memory_db.record_incident(
            event_id=event.event_id,
            src_ip=orig_src_ip,
            dst_ip=event.dst_ip,
            fingerprint=fingerprint,
            attack_category=attack_category,
            decision_source=decision_source,
            confidence=confidence,
            novelty_score=novelty_score,
            mitigation_action=mitigation_action,
            rule_applied=rule_cmd_summary,
            verification_passed=bool(verification_info.get("verified", False)),
            response_time_ms=elapsed_ms,
        )

        self.logger.info(
            f"Event={event.event_id} | AttackerIP={orig_src_ip} | Attack={attack_category} "
            f"| Mode={decision_source} | Action={mitigation_action} | TimeToBlock={elapsed_ms:.3f}ms"
        )

        result = {
            "scenario": scenario_label,
            "event_id": event.event_id,
            "detector_name": event.detector_name,
            "src_ip": orig_src_ip,
            "dst_ip": event.dst_ip,
            "dst_port": event.dst_port,
            "protocol": event.protocol,
            "fingerprint": fingerprint,
            "attack_category": attack_category,
            "decision_source": decision_source,
            "confidence": confidence,
            "novelty_score": novelty_score,
            "policy_approved": approved,
            "policy_reason": policy_reason,
            "mitigation_action": mitigation_action,
            "rule_cmd": rule_cmd_summary,
            "rule_spec": rule_spec,
            "verification": verification_info,
            "explanation": explanation,
            "response_time_ms": elapsed_ms,
            "correlation": correlation,
        }

        if self.show_terminal_ui:
            self.dashboard.print_attack_process_card(event, result)

        return result

    def start(self) -> None:
        """Prototype-compatible `commander.start()` method."""
        self.run_daemon()

    def shutdown(self) -> None:
        """Prototype-compatible `commander.shutdown()` method."""
        self.stop_event.set()
        self._broadcast_shield_state(active=False)
        try:
            self.attack_memory.display_history()
        except Exception:
            pass
        try:
            self.firewall.cleanup()
        except Exception:
            pass

    def run_daemon(self, duration_sec: Optional[float] = None, heartbeat_interval: float = 8.0) -> None:
        self.start_all_detectors(poll_interval=1.0)
        start_t = time.time()
        last_hb = time.time()
        try:
            while not self.stop_event.is_set():
                try:
                    evt = self.event_queue.get(timeout=0.4)
                    self.process_event(evt)
                except queue.Empty:
                    pass

                expired = self.enforcer.expire_stale_rules()
                if expired:
                    self.logger.info(f"Expired temporary firewall rules for IPs: {expired}")

                now = time.time()
                if self.show_terminal_ui and (now - last_hb) >= heartbeat_interval:
                    fw_state = self.enforcer.get_active_rules_summary()
                    mem_stats = self.memory_db.get_summary_stats()
                    self.dashboard.print_heartbeat(
                        protected_ip=self.protected_ip,
                        active_rules_count=fw_state["active_rules_count"],
                        validated_patterns_count=mem_stats["validated_patterns_count"],
                    )
                    last_hb = now

                if duration_sec and (now - start_t) >= duration_sec:
                    break
        except KeyboardInterrupt:
            print("\n[CyberCommander] Stopping protection daemon cleanly...")
        finally:
            self.stop_event.set()
            self._broadcast_shield_state(active=False)

    def get_system_status(self) -> Dict[str, Any]:
        return {
            "pid": os.getpid(),
            "host_identity": self.host_identity,
            "firewall_state": self.enforcer.get_active_rules_summary(),
            "attack_memory_stats": self.memory_db.get_summary_stats(),
            "ai_model_validation": self.ai_engine.model_data.get("validation_metrics", {}),
        }


def main():
    parser = argparse.ArgumentParser(description="Autonomous AI Cyber Commander v5.0 — Unified Gemini + eBPF/XDP + USB Defense System")
    parser.add_argument("--daemon", action="store_true", help="Run continuous live terminal protection (default)")
    parser.add_argument("--fresh-history", action="store_true", help="Reset and start with a brand-new empty Attack History")
    parser.add_argument("--live-demo", action="store_true", help="Run simulated attack showcase then transition to daemon")
    parser.add_argument("--duration", type=float, default=None, help="Optional daemon runtime limit in seconds")
    parser.add_argument("--status", action="store_true", help="Print current protection status as JSON and exit")
    args = parser.parse_args()

    if args.status:
        commander = CyberCommander(show_terminal_ui=False, reset_history=False)
        print(json.dumps(commander.get_system_status(), indent=2))
        return

    if args.live_demo:
        import simulate_attacks
        simulate_attacks.run_complete_validation(show_terminal_ui=True)
        commander = CyberCommander(show_terminal_ui=True, reset_history=False)
        commander.run_daemon(duration_sec=args.duration)
    else:
        commander = CyberCommander(show_terminal_ui=True, reset_history=args.fresh_history)
        commander.run_daemon(duration_sec=args.duration)


if __name__ == "__main__":
    main()
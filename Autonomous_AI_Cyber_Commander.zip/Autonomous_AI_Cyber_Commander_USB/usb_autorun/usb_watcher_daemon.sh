#!/usr/bin/env bash
# ==============================================================================
# usb_autorun/usb_watcher_daemon.sh
# Runs silently in the user's desktop session after one-time installation.
# Watches /media and /run/media for the CYBER_CMD pendrive. The moment it is
# inserted, it automatically opens the system's Terminal window and starts
# Cyber Commander WITHOUT any "Would you like to run it?" confirmation popup!
# ==============================================================================

LAST_TRIGGERED_PATH=""

while true; do
    FOUND_USB=""
    for candidate in \
        "/media/$USER/CYBER_CMD" \
        "/run/media/$USER/CYBER_CMD" \
        "/media/CYBER_CMD" \
        "/mnt/cyber_commander_usb" \
        /media/*/CYBER_CMD \
        /run/media/*/CYBER_CMD; do
        if [ -f "$candidate/cyber_commander.py" ]; then
            FOUND_USB="$candidate"
            break
        fi
    done

    if [ -n "$FOUND_USB" ]; then
        if [ "$FOUND_USB" != "$LAST_TRIGGERED_PATH" ]; then
            LAST_TRIGGERED_PATH="$FOUND_USB"
            sleep 0.8
            bash "$FOUND_USB/usb_autorun/open_cyber_terminal.sh" "$FOUND_USB" >/dev/null 2>&1 &
        fi
    else
        # USB was unplugged; reset state so re-inserting it triggers the terminal again!
        LAST_TRIGGERED_PATH=""
    fi
    sleep 1.5
done

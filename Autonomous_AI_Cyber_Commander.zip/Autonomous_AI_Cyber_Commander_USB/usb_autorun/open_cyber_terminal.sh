#!/usr/bin/env bash
# ==============================================================================
# usb_autorun/open_cyber_terminal.sh
# Opens the system's native Terminal window and starts Cyber Commander v4.0
# immediately when the pendrive is inserted.
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
USB_ROOT="${1:-$(cd "$SCRIPT_DIR/.." && pwd)}"
GUARD_CMD="bash '$USB_ROOT/start_usb_guard.sh' --live-terminal"
TITLE="Autonomous AI Cyber Commander v4.0 — Live Protection"

# Prevent duplicate terminal windows if already running
if pgrep -f "cyber_commander.py --daemon" >/dev/null 2>&1; then
    exit 0
fi

# Discover active desktop user & DISPLAY if invoked by root/udev
if [ "$(id -u)" -eq 0 ] && [ -z "${DISPLAY:-}" ]; then
    DESKTOP_USER="$(who | awk '!/root/ {print $1; exit}')"
    [ -z "$DESKTOP_USER" ] && DESKTOP_USER="$(ls -1 /home 2>/dev/null | head -n 1)"
    if [ -n "$DESKTOP_USER" ] && id "$DESKTOP_USER" >/dev/null 2>&1; then
        UID_VAL="$(id -u "$DESKTOP_USER")"
        export DISPLAY=":0"
        export DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$UID_VAL/bus"
        su - "$DESKTOP_USER" -c "DISPLAY=:0 DBUS_SESSION_BUS_ADDRESS='unix:path=/run/user/$UID_VAL/bus' bash '$USB_ROOT/usb_autorun/open_cyber_terminal.sh' '$USB_ROOT'" &
        exit 0
    fi
fi

export DISPLAY="${DISPLAY:-:0}"

if command -v gnome-terminal >/dev/null 2>&1; then
    gnome-terminal --title="$TITLE" -- bash -c "$GUARD_CMD; exec bash" &
elif command -v mate-terminal >/dev/null 2>&1; then
    mate-terminal --title="$TITLE" -e "bash -c \"$GUARD_CMD; exec bash\"" &
elif command -v xfce4-terminal >/dev/null 2>&1; then
    xfce4-terminal --title="$TITLE" -x bash -c "$GUARD_CMD; exec bash" &
elif command -v konsole >/dev/null 2>&1; then
    konsole -p tabtitle="$TITLE" -e bash -c "$GUARD_CMD; exec bash" &
elif command -v x-terminal-emulator >/dev/null 2>&1; then
    x-terminal-emulator -e bash -c "$GUARD_CMD; exec bash" &
elif command -v xterm >/dev/null 2>&1; then
    xterm -T "$TITLE" -e bash -c "$GUARD_CMD; exec bash" &
else
    bash "$USB_ROOT/start_usb_guard.sh" --live-terminal
fi

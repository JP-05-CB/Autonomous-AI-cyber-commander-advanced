#!/usr/bin/env bash
# ==============================================================================
# start_usb_guard.sh — Autonomous AI Cyber Commander v4.4 Live Terminal Guard
# ==============================================================================
# Enhancements:
# 1. Preserves & appends to the Attack History files (`data/attack_memory.db`,
#    `data/attack_memory_snapshot.json`, `data/attack_history.log`) if they exist,
#    OR automatically creates them from scratch if you deleted them!
# 2. Makes `data/` and all attack history files user-writable (`chmod a+rwX`) so
#    you can delete the attack history file anytime without `Permission denied`.
# ==============================================================================

USB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$USB_DIR" || exit 1

export FORCE_COLOR=1

mkdir -p "/tmp/cyber_commander_runtime/logs" 2>/dev/null || true
if mkdir -p "$USB_DIR/logs" 2>/dev/null && touch "$USB_DIR/logs/usb_autoguard.log" 2>/dev/null; then
    LOG_FILE="$USB_DIR/logs/usb_autoguard.log"
else
    LOG_FILE="/tmp/cyber_commander_runtime/logs/usb_autoguard.log"
fi

# If invoked from a background hook without a terminal, pop open the desktop terminal window
if [ "${1:-}" != "--live-terminal" ] && [ ! -t 1 ] && [ -n "${DISPLAY:-}" ]; then
    exec bash "$USB_DIR/usb_autorun/open_cyber_terminal.sh"
fi

[ "${1:-}" = "--live-terminal" ] && shift || true

# Ensure `data/` and `logs/` are user-deletable/writable without sudo
mkdir -p "$USB_DIR/data" 2>/dev/null || true
chmod -R a+rwX "$USB_DIR/data" "$USB_DIR/logs" 2>/dev/null || true
if [ "$(id -u)" -ne 0 ] && sudo -n true 2>/dev/null; then
    sudo -n chmod -R a+rwX "$USB_DIR/data" "$USB_DIR/logs" 2>/dev/null || true
fi

clear 2>/dev/null || true
echo "----------------------------------------------------------------------------------------" | tee -a "$LOG_FILE" 2>/dev/null
echo "  [USB PENDRIVE CONNECTED] AUTONOMOUS AI CYBER COMMANDER v4.4" | tee -a "$LOG_FILE" 2>/dev/null
echo "  USB Path       : $USB_DIR" | tee -a "$LOG_FILE" 2>/dev/null
echo "  Attack History : $USB_DIR/data/attack_history.log (Auto-Created if Deleted, Appended if Present)" | tee -a "$LOG_FILE" 2>/dev/null
echo "  Host User      : $(whoami)@$(hostname) (Time: $(date '+%Y-%m-%d %H:%M:%S'))" | tee -a "$LOG_FILE" 2>/dev/null
echo "----------------------------------------------------------------------------------------" | tee -a "$LOG_FILE" 2>/dev/null

# Notice: We do NOT pass `--fresh-history` by default here so that:
# - If the attack history file exists, Cyber Commander appends new attacks to it.
# - If you deleted the attack history file, Cyber Commander automatically creates a new one!
if [ "$(id -u)" -eq 0 ]; then
    exec python3 "$USB_DIR/cyber_commander.py" --daemon "$@"
elif sudo -n true 2>/dev/null; then
    exec sudo -E -n python3 "$USB_DIR/cyber_commander.py" --daemon "$@"
else
    exec python3 "$USB_DIR/cyber_commander.py" --daemon "$@"
fi

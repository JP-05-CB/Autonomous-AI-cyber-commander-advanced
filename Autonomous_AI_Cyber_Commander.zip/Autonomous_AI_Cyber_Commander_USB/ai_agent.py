import os
import re
import glob
import json
import urllib.request
import urllib.error
from typing import Optional, Dict, Any, List

# Pre-configured Gemini API key provided by the user (can be overridden by env/.env/gemini_api_key.txt)
DEFAULT_GEMINI_API_KEY = "AQ.Ab8RN6Ile0RoR5gMozu-2U6R7bKYuFd0db_d0wtl_l2TIWS5jg"

# Optional import of Google GenAI SDK (`from google import genai`)
try:
    from google import genai
    from google.genai import types
    HAS_GENAI_SDK = True
except Exception:
    genai = None
    types = None
    HAS_GENAI_SDK = False


def _scan_key_from_files(env_names: List[str], txt_filename: str) -> Optional[str]:
    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.dirname(here)
    candidate_files = [
        os.path.join(here, ".env"),
        os.path.join(root, ".env"),
        os.path.join(here, txt_filename),
        os.path.join(root, txt_filename),
    ]
    candidate_files.extend(glob.glob("/media/*/*/.env"))
    candidate_files.extend(glob.glob(f"/media/*/*/{txt_filename}"))
    candidate_files.extend(glob.glob("/home/*/.bashrc"))
    candidate_files.extend(glob.glob("/home/*/.profile"))
    candidate_files.extend(glob.glob("/home/*/.zshrc"))

    names_pattern = "|".join(re.escape(n) for n in env_names)
    # Supports both classic AIza... keys, gsk_... Groq keys, and new AQ.... Google AI Studio auth keys (with dots)
    key_regex = re.compile(rf'(?:{names_pattern})\s*=\s*["\']?([A-Za-z0-9_\-\.]{{20,}})["\']?')

    for path in candidate_files:
        if not os.path.exists(path):
            continue
        try:
            with open(path, "r", errors="ignore") as f:
                content = f.read()
            m = key_regex.search(content)
            if m and m.group(1) not in ("YOUR_API_KEY", "YOUR_GROQ_API_KEY"):
                return m.group(1).strip()
            if path.endswith(txt_filename):
                for line in content.splitlines():
                    raw_k = line.strip()
                    if raw_k and not raw_k.startswith("#") and len(raw_k) >= 20 and " " not in raw_k:
                        return raw_k
        except Exception:
            continue
    return None


def discover_gemini_api_key() -> Optional[str]:
    """
    Discovers the user's Gemini API key across:
    1. Environment variables: `GEMINI_API_KEY` or `GOOGLE_API_KEY`
    2. Local `.env` or `gemini_api_key.txt` files in the project or USB drive
    3. The desktop user's `~/.bashrc`, `~/.profile`, `~/.zshrc` (even across `sudo`)
    4. Built-in merged project key (`DEFAULT_GEMINI_API_KEY`).
    """
    for env_name in ("GEMINI_API_KEY", "GOOGLE_API_KEY"):
        val = os.environ.get(env_name, "").strip()
        if val and val != "YOUR_API_KEY":
            return val

    found = _scan_key_from_files(["GEMINI_API_KEY", "GOOGLE_API_KEY"], "gemini_api_key.txt")
    if found:
        os.environ["GEMINI_API_KEY"] = found
        return found

    if DEFAULT_GEMINI_API_KEY and DEFAULT_GEMINI_API_KEY != "YOUR_API_KEY":
        os.environ["GEMINI_API_KEY"] = DEFAULT_GEMINI_API_KEY
        return DEFAULT_GEMINI_API_KEY

    return None


def discover_groq_api_key() -> Optional[str]:
    """
    Discovers an optional Groq Free Tier API key (`GROQ_API_KEY`) across:
    1. Environment variable `GROQ_API_KEY`
    2. Local `.env` or `groq_api_key.txt` files in the project or USB drive
    3. The desktop user's `~/.bashrc`, `~/.profile`, `~/.zshrc`.
    """
    val = os.environ.get("GROQ_API_KEY", "").strip()
    if val and val != "YOUR_GROQ_API_KEY":
        return val

    found = _scan_key_from_files(["GROQ_API_KEY"], "groq_api_key.txt")
    if found:
        os.environ["GROQ_API_KEY"] = found
        return found
    return None


class CyberDefenseAgent:
    """
    Multi-Provider Defensive AI Agent (Google Gemini API + Groq Free API + Local Hybrid AI Fallback).

    Architecture:
        1. Google Gemini API (`gemini-2.5-flash` / `gemini-2.0-flash` / `gemini-3.6-flash`)
           with pre-merged key `AQ.Ab8RN6Ile0RoR5gMozu-2U6R7bKYuFd0db_d0wtl_l2TIWS5jg`
           ↓ (if rate-limited or configured with GROQ_API_KEY)
        2. Groq Free Tier API (`llama-3.3-70b-versatile` / `llama-3.1-8b-instant`)
           ↓ (if offline in isolated VM lab)
        3. Built-in 17-Class & Zero-Day Local Hybrid AI Engine
           ↓
        function call: `block_ip(ip, duration, reason)`
           ↓
        Deterministic Security Validation (IP match, 1 <= duration <= 3600)
           ↓
        FirewallTools.block_ip() -> FirewallManager (eBPF/XDP + nftables/iptables)
    """

    RECOMMENDED_DURATIONS = {
        "SYN_FLOOD": 1800,
        "SYN_FLOOD_DDOS": 1800,
        "HTTP_FLOOD": 1200,
        "HTTP_L7_FLOOD": 1200,
        "SLOW_HTTP": 1800,
        "HTTP_SMUGGLING": 3600,
        "ICMP_FLOOD": 1200,
        "ICMP_PING_FLOOD": 1200,
        "IP_FRAGMENTATION": 1800,
        "LAND_AND_IP_FRAGMENT_ATTACK": 1800,
        "BRUTE_FORCE": 1800,
        "PORT_SCAN": 900,
        "TCP_FIN_SCAN": 1200,
        "ARP_SPOOFING": 3600,
        "ARP_MITM_SPOOFING": 3600,
        "DNS_TUNNELING": 2400,
        "DNS_REBINDING": 2400,
        "SQL_INJECTION": 3600,
        "XSS_AND_WEB_INJECTION": 3600,
        "PATH_TRAVERSAL_LFI": 3600,
        "ZERO_DAY_ANOMALY": 600,
    }

    def __init__(
        self,
        firewall_tools,
        api_key: Optional[str] = None,
        groq_api_key: Optional[str] = None,
        model: Optional[str] = None,
    ):
        self.firewall_tools = firewall_tools
        self.api_key = api_key or discover_gemini_api_key()
        self.groq_api_key = groq_api_key or discover_groq_api_key()
        self.model = model or os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")
        self.fallback_models = ["gemini-2.5-flash", "gemini-2.0-flash", "gemini-3.6-flash"]
        self.groq_models = ["llama-3.3-70b-versatile", "llama-3.1-8b-instant"]
        self.client = None

        if HAS_GENAI_SDK and self.api_key:
            try:
                self.client = genai.Client(api_key=self.api_key)
                print(f"[+] CyberDefenseAgent initialized with Gemini API key (Model: {self.model}).")
            except Exception as e:
                print(f"[!] Gemini SDK init note ({e}) -> REST & Hybrid AI Engine ready.")
        elif self.api_key:
            print(f"[+] CyberDefenseAgent initialized with Gemini REST API key (Model: {self.model}).")
        elif self.groq_api_key:
            print(f"[+] CyberDefenseAgent initialized with Groq Free Tier API (Model: {self.groq_models[0]}).")
        else:
            print("[+] CyberDefenseAgent initialized (Local Hybrid AI Engine active).")

    def analyze_event(self, event, correlation=None) -> Dict[str, Any]:
        print()
        print("=" * 60)
        print("[GEMINI / GROQ AI AGENT] ANALYZING SECURITY EVENT")
        print("=" * 60)
        print(f"Attack type : {event.event_type}")
        print(f"Source IP   : {event.source_ip}")
        print(f"Confidence  : {event.confidence}")

        prompt = self._build_prompt(event, correlation)

        block_ip_function = {
            "name": "block_ip",
            "description": "Block a malicious source IPv4 address using the defensive eBPF/XDP firewall.",
            "parameters": {
                "type": "object",
                "properties": {
                    "ip": {
                        "type": "string",
                        "description": "IPv4 address of the malicious source.",
                    },
                    "duration": {
                        "type": "integer",
                        "description": "Number of seconds to block the source IP. Maximum 3600.",
                    },
                    "reason": {
                        "type": "string",
                        "description": "Security reason for blocking the source IP.",
                    },
                },
                "required": ["ip", "duration", "reason"],
            },
        }

        # ------------------------------------------------------------------
        # PATH A1: Google Gemini API via `google-genai` SDK
        # ------------------------------------------------------------------
        if self.client is not None and HAS_GENAI_SDK:
            models_to_try = [self.model] + [m for m in self.fallback_models if m != self.model]
            for candidate_model in models_to_try:
                try:
                    chat = self.client.chats.create(
                        model=candidate_model,
                        config=types.GenerateContentConfig(
                            tools=[{"function_declarations": [block_ip_function]}]
                        ),
                    )
                    response = chat.send_message(prompt)

                    if response.function_calls:
                        for function_call in response.function_calls:
                            print()
                            print("=" * 60)
                            print(f"[GEMINI AGENT ({candidate_model})] FUNCTION CALL REQUESTED")
                            print("=" * 60)
                            print(f"Function : {function_call.name}")
                            print(f"Arguments: {function_call.args}")

                            if function_call.name != "block_ip":
                                print("[SECURITY] Unknown function rejected.")
                                return {
                                    "success": False,
                                    "action": "LOG_ONLY",
                                    "reason": "Unknown function requested.",
                                }

                            args = function_call.args
                            ip = args.get("ip")
                            duration = int(args.get("duration", 600))
                            reason = args.get("reason", f"Gemini blocked {event.event_type}")

                            return self._validate_and_execute_block(
                                event=event,
                                ip=ip,
                                duration=duration,
                                reason=reason,
                                chat=chat,
                                function_call_name=function_call.name,
                            )

                    print()
                    print("[GEMINI AGENT] No firewall action requested.")
                    print("[GEMINI AGENT] Response:")
                    print(response.text)
                    return {
                        "success": True,
                        "action": "LOG_ONLY",
                        "ip": event.source_ip,
                        "duration": None,
                        "reason": "Gemini did not request a firewall action.",
                        "ai_response": response.text,
                    }
                except Exception as api_err:
                    err_str = str(api_err)
                    if "NOT_FOUND" in err_str or "404" in err_str:
                        continue
                    print(f"[GEMINI SDK] Switching to REST/Groq/Hybrid fallback ({err_str[:75]}).")
                    break

        # ------------------------------------------------------------------
        # PATH A2: Google Gemini REST API (Zero-dependency fallback if google-genai isn't installed)
        # ------------------------------------------------------------------
        if self.api_key and not HAS_GENAI_SDK:
            rest_res = self._call_gemini_rest_api(event, prompt, block_ip_function)
            if rest_res is not None:
                return rest_res

        # ------------------------------------------------------------------
        # PATH B: Groq Free Tier API (`GROQ_API_KEY` — 14,400 req/day OpenAI-compatible Tool Use)
        # ------------------------------------------------------------------
        if self.groq_api_key:
            groq_res = self._call_groq_tool_api(event, prompt, block_ip_function)
            if groq_res is not None:
                return groq_res

        # ------------------------------------------------------------------
        # PATH C: Local Hybrid AI & Zero-Day Decision Fallback
        # (Guarantees 100% autonomous protection even offline in isolated VM labs)
        # ------------------------------------------------------------------
        return self._local_hybrid_ai_decision(event, correlation)

    def _call_gemini_rest_api(self, event, prompt: str, block_ip_function: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Calls the Google Gemini REST API directly via standard library urllib when google-genai SDK is absent."""
        models_to_try = [self.model] + [m for m in self.fallback_models if m != self.model]
        for candidate_model in models_to_try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{candidate_model}:generateContent"
            payload = {
                "contents": [{"role": "user", "parts": [{"text": prompt}]}],
                "tools": [{"functionDeclarations": [block_ip_function]}],
            }
            headers = {
                "Content-Type": "application/json",
                "x-goog-api-key": self.api_key,
            }
            req = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST")
            try:
                with urllib.request.urlopen(req, timeout=4.0) as resp:
                    data = json.loads(resp.read().decode("utf-8", errors="ignore"))
                candidates = data.get("candidates", [])
                if not candidates:
                    continue
                parts = candidates[0].get("content", {}).get("parts", [])
                for part in parts:
                    if "functionCall" in part:
                        fc = part["functionCall"]
                        fn_name = fc.get("name", "")
                        args = fc.get("args", {})
                        if fn_name == "block_ip":
                            ip = str(args.get("ip", event.source_ip))
                            duration = int(args.get("duration", 1200))
                            reason = str(args.get("reason", f"Gemini REST blocked {event.event_type}"))
                            return self._validate_and_execute_block(event, ip, duration, reason)
            except Exception:
                continue
        return None

    def _call_groq_tool_api(self, event, prompt: str, block_ip_function: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Calls Groq Cloud's Free Tier OpenAI-compatible Tool Use endpoint
        (`https://api.groq.com/openai/v1/chat/completions`) using standard library urllib.
        """
        url = "https://api.groq.com/openai/v1/chat/completions"
        for groq_model in self.groq_models:
            payload = {
                "model": groq_model,
                "messages": [
                    {
                        "role": "system",
                        "content": "You are the defensive AI decision agent of Autonomous AI Cyber Commander. Use the block_ip tool when blocking is justified.",
                    },
                    {"role": "user", "content": prompt},
                ],
                "tools": [{"type": "function", "function": block_ip_function}],
                "tool_choice": "auto",
                "temperature": 0.1,
            }
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.groq_api_key}",
                "User-Agent": "Autonomous-AI-Cyber-Commander/5.1",
            }
            req = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST")
            try:
                with urllib.request.urlopen(req, timeout=4.0) as resp:
                    data = json.loads(resp.read().decode("utf-8", errors="ignore"))
                choices = data.get("choices", [])
                if not choices:
                    continue
                msg = choices[0].get("message", {})
                tool_calls = msg.get("tool_calls", [])
                if tool_calls:
                    for tc in tool_calls:
                        fn = tc.get("function", {})
                        fn_name = fn.get("name", "")
                        raw_args = fn.get("arguments", "{}")
                        args = json.loads(raw_args) if isinstance(raw_args, str) else raw_args
                        print()
                        print("=" * 60)
                        print(f"[GROQ AGENT ({groq_model})] FUNCTION CALL REQUESTED")
                        print("=" * 60)
                        print(f"Function : {fn_name}")
                        print(f"Arguments: {args}")
                        if fn_name != "block_ip":
                            return {
                                "success": False,
                                "action": "LOG_ONLY",
                                "reason": "Unknown function requested.",
                            }
                        ip = str(args.get("ip", event.source_ip))
                        duration = int(args.get("duration", 1200))
                        reason = str(args.get("reason", f"Groq AI blocked {event.event_type}"))
                        return self._validate_and_execute_block(event, ip, duration, reason)
                content_txt = msg.get("content", "") or "Groq did not request a firewall action."
                return {
                    "success": True,
                    "action": "LOG_ONLY",
                    "ip": event.source_ip,
                    "duration": None,
                    "reason": content_txt,
                    "ai_response": content_txt,
                }
            except Exception as e:
                print(f"[GROQ AGENT] Fallback note ({str(e)[:70]}).")
                continue
        return None

    def _validate_and_execute_block(
        self,
        event,
        ip: str,
        duration: int,
        reason: str,
        chat=None,
        function_call_name: str = "block_ip",
    ) -> Dict[str, Any]:
        """Performs the deterministic security checks from the user's prototype before calling FirewallTools."""
        if ip != event.source_ip:
            print("[SECURITY] BLOCK REJECTED: AI attempted to block an IP different from the event source.")
            return {
                "success": False,
                "action": "LOG_ONLY",
                "reason": "Source IP validation failed.",
            }

        if not isinstance(duration, int) or duration <= 0:
            print("[SECURITY] BLOCK REJECTED: Invalid block duration.")
            return {
                "success": False,
                "action": "LOG_ONLY",
                "reason": "Invalid block duration.",
            }

        if duration > 3600:
            print("[SECURITY] Duration exceeds maximum. Capping duration at 3600 seconds.")
            duration = 3600

        result = self.firewall_tools.block_ip(
            ip=ip,
            duration=duration,
            reason=reason,
        )

        print()
        print("[FIREWALL TOOL RESULT]")
        print(result)

        ai_text = f"Blocked malicious source IP {ip} for {duration}s due to {event.event_type}: {reason}"
        if chat is not None and HAS_GENAI_SDK:
            try:
                final_response = chat.send_message(
                    types.Part.from_function_response(
                        name=function_call_name,
                        response=result,
                    )
                )
                if getattr(final_response, "text", None):
                    ai_text = final_response.text
            except Exception:
                pass

        print()
        print("[AI AGENT] Final response:")
        print(ai_text)

        return {
            "success": result.get("success", False),
            "action": "BLOCK" if result.get("success", False) else "LOG_ONLY",
            "ip": ip,
            "duration": duration,
            "reason": reason,
            "ai_response": ai_text,
        }

    def _local_hybrid_ai_decision(self, event, correlation=None) -> Dict[str, Any]:
        """
        Deterministic + Statistical Hybrid AI fallback when running offline in an isolated lab.
        """
        corr_score = correlation.get("correlation_score", 0) if isinstance(correlation, dict) else 0
        effective_conf = float(getattr(event, "confidence", 0.90))
        if corr_score >= 2:
            effective_conf = min(0.99, effective_conf + 0.08)

        if effective_conf < 0.70 and corr_score < 2:
            reason = f"Confidence ({effective_conf:.2f}) is below 0.70 threshold; monitoring traffic."
            print(f"[GEMINI/HYBRID AGENT] {reason}")
            return {
                "success": True,
                "action": "LOG_ONLY",
                "ip": event.source_ip,
                "duration": None,
                "reason": reason,
                "ai_response": reason,
            }

        base_dur = self.RECOMMENDED_DURATIONS.get(event.event_type, 1200)
        if corr_score >= 2:
            base_dur = min(3600, int(base_dur * 1.5))

        corr_note = (
            f" (Correlated multi-vector attack across {correlation['attack_types']})"
            if isinstance(correlation, dict) and correlation.get("attack_types")
            else ""
        )
        reason = (
            f"High-confidence ({effective_conf*100:.1f}%) {event.event_type} attack detected from {event.source_ip}"
            f"{corr_note}. Deploying eBPF/XDP + firewall block for {base_dur}s."
        )

        print()
        print("=" * 60)
        print("[GEMINI / HYBRID AI AGENT] FUNCTION CALL REQUESTED")
        print("=" * 60)
        print("Function : block_ip")
        print(f"Arguments: {{'ip': '{event.source_ip}', 'duration': {base_dur}, 'reason': '{reason}'}}")

        return self._validate_and_execute_block(
            event=event,
            ip=event.source_ip,
            duration=base_dur,
            reason=reason,
            chat=None,
            function_call_name="block_ip",
        )

    def _build_prompt(self, event, correlation=None) -> str:
        correlation_text = str(correlation) if correlation else "No correlation information."
        evidence = getattr(event, "evidence", None) or {
            "unique_ports": getattr(event, "unique_ports", 0),
            "connection_count": getattr(event, "connection_count", 0),
            "service_port": getattr(event, "service_port", 0),
            "failed_attempts": getattr(event, "failed_attempts", 0),
            "window_seconds": getattr(event, "window_seconds", 0),
            "process_details": getattr(event, "process_details", ""),
        }
        return f"""
You are the defensive AI decision agent of Autonomous AI Cyber Commander.
You operate only inside an authorized cybersecurity laboratory environment.
Your responsibility is to analyze detected security events and determine whether defensive firewall action is required.

AVAILABLE TOOL:
block_ip(ip, duration, reason)

SECURITY RULES:
1. Only block the source IP associated with the event.
2. Never invent an IP address.
3. Never block the target IP.
4. Never execute shell commands.
5. Never generate executable code.
6. Never modify the firewall directly.
7. Use the block_ip function when blocking is justified.
8. Confidence below 0.70 normally requires monitoring.
9. High-confidence malicious events normally require defensive blocking.
10. Correlated attacks should receive stronger consideration.
11. Block duration must be between 1 and 3600 seconds.
12. If blocking is justified, provide a concise reason.

SECURITY EVENT:
Attack type: {event.event_type}
Source IP: {event.source_ip}
Target IP: {event.target_ip}
Confidence: {event.confidence}
Evidence: {evidence}
Correlation: {correlation_text}

Analyze the event and determine the appropriate defensive action.
"""